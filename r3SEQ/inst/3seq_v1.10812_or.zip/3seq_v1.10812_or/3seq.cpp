//------------------------------------------------------
//
// Copyright (c) 2006-09 Maciej F. Boni.  All Rights Reserved.
//
// 3seq.cpp -- main source file for executable 3SEQ.  Contains
//             main() function, parsing of command line arguments
//             global variables, main loops which loop through
//             the sequences being analyzed.
//
//------------------------------------------------------

#define VERSION 1.10812

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <map>
#include <ctime>
#include <ctype.h>
#include <cstdlib>

#include "seq.h"
#include "readfile.h"
#include "gene.h"
#include "ProbTables.h"

#define HOGANSIEGMUND 1

using namespace std;






//
//
// STRUCT DEFINITIONS
//
//
struct breakpointranges
{
    int L1;  // left  boundary of range of first  breakpoint
    int R1;  // right boundary of range of first  breakpoint
    int L2;  // left  boundary of range of second breakpoint
    int R2;  // right boundary of range of second breakpoint
};
typedef struct breakpointranges BREAKPOINTRANGES;



//
//
// FUNCTION DECLARATIONS
//
//
MDTRIPLE Calculate_Maximum_Descent( seq* parent1, seq* parent2, seq* child );
MDTRIPLE Calculate_Maximum_Height( seq* parent1, seq* parent2, seq* child );
void DisplayInfo( seq* pSeq, int N, int origLen, int NDistinct );

void DoDryRun( seq* pSeq, int N, int maxMN, int maxK );
double DoFullRun( seq* pSeq, int N, double th, int memAllot, bool show, bool bYesNoMode );
double SingleBreakpointRun( seq* pSeq, int N, double th, int memAllot, bool bYesNoMode );
void DoXRun( seq* pSeq, int N );
void DoTripletRun( seq* pSeq, int N, string p_accnum, string q_accnum, string c_accnum );
void DoMatchRun( seq* pSeq, int N );

vector<BREAKPOINTRANGES>* GetBreakpoints( seq* parent1, seq* parent2, seq* child, int md, int *pnRecLength );
bool TryAddingToCurrentRanges( vector<BREAKPOINTRANGES>* pvBPR, int b1, int b2 );
void CalculateBestBreakpoints( seq* pSeq, int N );
//int GetMinRecombinantLength( vector<BREAKPOINTRANGES>* pvBPR, int len ); // must pass in full sequence length

int GetNumberNonGappedSites( seq* parent1, seq* parent2, seq* child, int b1, int b2 );

void MakePSFile(seq* pSeq, int N, int p_index, int q_index, int c_index );

void SendPValDistributionToOutfile( int* pn, int N ); 

// the two overloaded functions below allow the program to record a recombinant triplet to the output
// file 3s.rec; the first version of the function records a single p-value, either exact or approximated
// using the hogan-siegmund method; the default is that the p-value is exact, but if a 1 is passed in
// as the last argument the record will note that this triplet was approximated
// the second version takes a BOUNDS structure and it records the upper bound and lower bound for the
// p-value for that triplet
void RecordRecombinantTriplet( int p, int q, int c, MDTRIPLE mdt, double pvalue, seq* pSeq, int hs=0 );	
void RecordRecombinantTriplet( int p, int q, int c, MDTRIPLE mdt, BOUNDS bnds,   seq* pSeq  );	

void RecordSkippedTriplet( int p, int q, int c, MDTRIPLE mdt, seq* pSeq );  			
void DisplayResults( unsigned int num_computed_exactly, unsigned int num_bounded, unsigned int num_approximated_hs, unsigned int num_skipped, double min_pvalue, seq* pSeq, int N, int num_rec_triplets=-99 );
void OutputFormattedForPython( unsigned int num_computed_exactly, unsigned int num_bounded, unsigned int num_approximated_hs, unsigned int num_skipped, double min_pvalue, seq* pSeq, int N, int num_rec_triplets=-99 );

double DS( double pval );
void PrintUsageModes();
void PrintOptions();
void ParseArgs(int argc, char **argv, int* m, int* k);
void Bin(double p); // bins p-values in the histogram G_PV
bool ACGT( char c );

int GetMaxInformativeSites( seq* pSeq, int N );
unsigned int GetNumTriplesCalculated( seq* pSeq, int N, int maxMN, int maxK );
int GetMegsNeeded( int maxMN, int maxK );

double PValMaxHeight_1( int m, int n, int k ); // method uses floating-point multiplication
//double PValMaxHeight_2( int m, int n, int k ); // method uses gamma functions
//double PValMaxHeight_3( int m, int n, int k ); // method uses dynamic programming table

void CheckForDuplicateAccessionNumbers( seq* pSeq, int N );
int GetNumberDistinctSequences( seq* pSeq, int N );
seq* RemoveIdenticalSequences( seq* pSeq, int N, int NDistinct );
seq* RemoveNeighborSequences( seq* pSeq, int* pN, int dist );


//
//
// GLOBAL VARIABLES
//
//
enum runmode {None, Version, Help, Info, SingleBpRun, DryRun, QuickRun, FullRun, TripletRun, XRun, WriteRun, MatchRun}; 
typedef enum runmode RUNMODE;
RUNMODE G_RunMode = None;

//
// command line options (global variables)
//
bool   G_CLO_YESNO  = false;
bool   G_CLO_PYTHON = false;
bool   G_CLO_RECORD_SKIPPED_TRIPLES = false;
bool   G_CLO_WRITEPVALHIST = false;
bool   G_CLO_WRITELONGRECOMBINANTS = false;
bool   G_CLO_ALLSITES = false;	// WE NEED TO GET RID OF THIS COMMAND LINE OPTION SINCE IT IS NEVER USED
				// NOT EVEN IN THE TRIPLET RUN
				//
				// 11-22-2007: actually it is useful when using the -out option to create an
				//             output file of the some subsequences; and the -w mode as well 

bool   G_CLO_THIRD_POSITIONS_ONLY = false;
bool   G_CLO_FIRST_AND_SECOND_POSITIONS_ONLY = false;

double G_CLO_THRESHOLD = 0.05;
int    G_CLO_FIRST = 0;  	// these are indices of the first and last+1 nucleotides; you loop like you
int    G_CLO_LAST = -1;  	// would in a vector class: for(i=G_CLO_FIRST; i < G_CLO_LAST; i++)

int    G_CLO_MEMORY_ALLOTMENT = -1;  // this is for full-run mode

bool   G_CLO_CUT = false;	// this can be used in combination with the -f and -l switches which set
				// the variables G_CLO_FIRST and G_CLO_LAST.  Normally, if you enter -f20
				// and -l40 then only the subsequence from nucleotides 20 to 40 is analyzed.
				// However, if you set G_CLO_CUT = true, then the sequence from nt 20-40
				// would be cut out and the remainder of the sequence would be analyzed

int    G_CLO_QUERY = -1;	// this is the index of the query sequence if we only want to test one
				// child sequence to see if it is a recombinant or not
				//
				// 07-10-2008: this is not used anywhere

int    G_CLO_BEG_SEQ  =  0;	// these two indices describe what child sequence to start and
int    G_CLO_END_SEQ  = -1;	// end at when looping through child sequences; if all child sequences
				// are to be tested, you must set G_CLO_END_SEQ to N

// for TripletRun mode, these three variables are the indices of the sequence in the sequence array
string G_CLO_TRIPLET_P("");
string G_CLO_TRIPLET_Q("");
string G_CLO_TRIPLET_C("");

bool G_CLO_USE_ALL_TRIPLES = true; 	// this is the controlled by the command line argument -#
					// when user selects -#, this is set to false, and multiple
					// comparisons corrections will use G_N_NUM_TRIPLES instead of
					// G_N_ALL_TRIPLES in the Dunn-Sidak correction
					//
					// the purpose of this switch is to be able to query a sequence
					// e.g. "-b35 -e35" and then use the -# switch to correct for the
					// comparisons done in that run only
					//
					// when running in parallel, make sure -# switch is NOT used

string G_CLO_SUBSET_FILENAME("");
//string G_CLO_OUTPUT_SEQUENCES_FILENAME("");		// 12/7/2008: commented out since "write mode" allows the user to 
							// to write the current sequence/segment subset to the standard output

bool G_CLO_REMOVE_SUBSET = false;
bool G_CLO_REMOVE_IDENTICAL_SEQUENCES = false;
int  G_CLO_REMOVE_DISTANCE = 0;

//bool G_CLO_SKIP_BREAKPOINT_CALCULATIONS = true;	// 12/6/2008: changed this default to true per
							// Fernando's request; this option will be phased out
							// as the two options below are phased in
							
bool G_CLO_BREAKPOINTS_FOR_ALL_RECOMBINANTS = false;	// you should be able to turn on this option
							// with the command line switch "-bp-all"
							
bool G_CLO_NO_BREAKPOINTS = false;			// you should be able to turn on this option
							// with the command line switch "-bp-none"
							
bool G_CLO_NO_3SREC_FILE = false;			// you should be able to turn this on, i.e. suppress the
							// creation of the 3s.rec file, with the "-nr" option
bool G_CLO_USE_SIEGMUND_APPROX = false;

int G_CLO_MIN_RECOMBINANT_LENGTH = 100;

bool G_CLO_OUTPUT_NEXUS = false;
bool G_CLO_OUTPUT_FASTA = false;

string G_CLO_ID("");			// 12-12-2008: added this so that multiple runs can
					// can write to different 3s.rec, 3s.pvalhist, files

int G_CLO_MATCH_MIN = -1;		// in MatchRun, the min and max distance of sequence
int G_CLO_MATCH_MAX = -1;		// shown that match the query sequence

//
// other global variables
//
unsigned int G_N_NUM_TRIPLES = 0;		// total number of triples that are tested for a particular run
double       G_D_NUM_TRIPLES = ((double)-1);	// total number of triples that are tested for a particular run

bool   G_TRIPLES_OVERFLOW = false; 	        // means the total number of triples is greater than int_max; this causes problems

unsigned int G_N_ALL_TRIPLES = 0;		// total number of triples that would be tested for this data set
double       G_D_ALL_TRIPLES = ((double)-1);	// total number of triples that would be tested for this data set

int G_LONGEST_RECOMBINANT_SEGMENT = 0;
int G_NUM_AMBIGUOUS_NT = 0;

bool   G_PHYLIP=true;
int    G_PV[40]; 		// histogram of p-values

FILE* DataFile;			// this is the phylip file with the sequences
FILE* OutFile; 			// NOT USED
FILE* GFileSkippedPValues;
FILE* GFileSubset;
FILE* GFileRecombinants;
//string G_CLO_FILE_RECOMBINANTS_NAME("3s.rec");

string G_FILENAME_LOGFILE("3s.log");
string G_FILENAME_RECOMBINANTS("3s.rec");
string G_FILENAME_LONGRECOMBINANTS("3s.long_recombinants");
string G_FILENAME_PVALUEHISTOGRAM("3s.pvalhist");
string G_FILENAME_SKIPPEDPVALUES("3s.skippedpvals");

vector<MDTRIPLE> UnfinishedTriples;
vector<MDTRIPLE> ImpossibleTriples;

int GLen=-1;		// this is the number of sites being considered; usually the number of polymorphic sites
			// this should always match the length of the vector G_V_NTPOS below

//
// is a vector of the actual nucleotide positions being analyzed,
// which are the nucleotides in the member seq::nt, as opposed to the
// member seq::ntfull which has all the nucloetides.  The numbers in the
// vector below start off being simply 0, 1, 2, ..., GLen-1, which are the 
// indices into the vector seq::ntfull
//
// after the user has made some selections, such as removing non-polymorphic
// sites, looking at only a section of the subsequence, looking at third
// positions only, etc; this vector will hols a set of indices like [3,12,103,...]
// the describe the positions (indices) on the nucleotides that are being
// analyzed in the member variable seq::nt
vector<int> G_V_NTPOS;

// some basic strain stats
vector<double> G_V_STATS;

//
//
// STATIC CLASS VARIABLES.  You must declare these.
//
//
bool ytable::quiet=false;
bool ytable::override_hardlimit=false;
int ytable::mSize=-1;
int ytable::nSize=-1;
int ytable::kSize=-1;
int ytable::jSize=-1;
int ytable::nNumAllocatedInMeta=0;
float** ytable::metatable = NULL;
int pvaluetable::size=-1;
float* pvaluetable::table=NULL;
bool pvaluetable::quiet=true;
int pvaluetable_compact::size=-1;
int pvaluetable_compact::table_len=-1;
float* pvaluetable_compact::table=NULL;
int* pvaluetable_compact::index_array=NULL;
bool pvaluetable_compact::quiet=false;



//
//
// MAIN
//
//
int main(int argc, char* argv[])
{    
    int i, j;
    vector<int>::iterator ivit; 		// integer vector iterator
    int nOriginalLength = -1;

    for(i=0; i<40; i++) G_PV[i]=0;

    // this should be the maximum pairwise difference between strains (unless it's too large) 
    // the number below will allow for the building of hypergeometric random walks H_{m,m}
    int nMaxUpOrDownStepsInHGRW;

    // this should be the maximum descent we expect to see in our HGRWs
    // ideally, this would just be set to nMaxUpOrDownStepsInHGRW (above) but practically, 
    // it may need to be something lower since we have RAM limitations
    int nMaxDescentAllowedInHGRW;

    // parses the command line arguments
    ParseArgs(argc, argv, &nMaxUpOrDownStepsInHGRW, &nMaxDescentAllowedInHGRW );
    //fprintf(stderr, "\n\n\tFinished parsing arguments -- %s\n", G_CLO_SUBSET_FILENAME.c_str() ); fflush( stderr );

    //
    // after the ParseArgs call, the program will have exited if the runmode was Version or Help
    //

    //if( G_CLO_YESNO ) cout << "\n\tYesNo option is on";
    //if( G_CLO_PYTHON ) cout << "\n\tPython option is on";
    if( G_CLO_RECORD_SKIPPED_TRIPLES ) cout << "\n\tWill record skipped pvalues to outfile "<< G_FILENAME_SKIPPEDPVALUES << "\n";
    //if( G_CLO_THRESHOLD != 0.05 ) cout << "\n\tRejection threshold is " << G_CLO_THRESHOLD;
    //if( G_CLO_FIRST != 0 ) cout << "\n\tposition (starting at 1) of first nt is " << G_CLO_FIRST+1;
    //if( G_CLO_LAST != -1 ) cout << "\n\tposition (starting at 1) of last  nt is " << G_CLO_LAST;
    //if( G_CLO_MEMORY_ALLOTMENT != -1 ) cout << "\n\tmemory allotment is " << G_CLO_MEMORY_ALLOTMENT;

    // now, read in the data file
    int N=0; 		// the number of sequences
    seq* pSeq = NULL; 	// the pointer to the sequence array
    if( G_PHYLIP )
    {
        FILETYPE ft = GetFiletype( argv[2] );
        //cout << "\n\tFiletype is " << ft;
        if( ft==phylip )
        {
            pSeq = ReadPhylipFile( argv[2], &N, &nOriginalLength, &G_NUM_AMBIGUOUS_NT ); 	// reads in sequences from datafile argv[2]
            GLen = nOriginalLength;								// and allocates space for pSeq pointer
        }
        else if( ft==nexus )
        {
            cout << "\n\t3SEQ cannot read nexus files.\n\n";
            exit(-1);
        }
        else if( ft==fasta )
        {
            //cout << "\n\tInput is a FASTA file."; fflush(stdout);
	    pSeq = ReadFastaFile( argv[2], &N, &nOriginalLength, &G_NUM_AMBIGUOUS_NT );
            GLen = nOriginalLength;
            //exit(-1);
        }
        else if( ft==no_filetype )
        {
            cout << "\n\tUnknown filetype for '" << argv[2] <<"'.\n\n";
            exit(-1);
        }
        //pSeq = ReadAlignment( argv[2], &N, &nOriginalLength ); 		// reads in sequences from datafile argv[2]	
	
	for(i=0; i<N; i++) (pSeq+i)->ntfull = (pSeq+i)->nt;
	for(j=0; j<nOriginalLength; j++) G_V_NTPOS.push_back(j);
	assert( GLen == G_V_NTPOS.size() );
	//for(j=0; j<G_V_NTPOS.size(); j++) cout << "\n\t" << G_V_NTPOS[j];
	
	if( !G_CLO_PYTHON && G_RunMode != Info && G_RunMode != WriteRun ) 
	{
	    cout << "\n\t" << N << " sequences read in successfully.  Length: " << nOriginalLength << "nt.\n\t"; 
	    cout << G_NUM_AMBIGUOUS_NT << " ambiguous nucleotides changed to gaps.\n\t";
// 	    cout << std::endl;
	    fflush(stdout);
    }
	
	//BEGIN EXTRACTION OF SUBSEQUENCE
	// if G_CLO_LAST was set to -1, set it to the last position now since we just learned the sequence length
	//cout << "\n\t" << G_CLO_LAST;
	if( G_CLO_LAST == -1 )  G_CLO_LAST = nOriginalLength;
	//cout << "\n\t" << G_CLO_LAST;
	// check to make sure -f and -l options are within bounds
	if( G_CLO_FIRST < 0 || G_CLO_FIRST > nOriginalLength-1 )
	{
	    cout << "\n\tCannot use " << G_CLO_FIRST+1 << " as first position.  Setting first position to 1.\n";
	    G_CLO_FIRST = 0;
	}
	if( G_CLO_LAST < 1 || G_CLO_LAST > nOriginalLength )
	{
	    cout << "\n\tCannot use " << G_CLO_LAST << " as last position.  Setting last position to " << nOriginalLength << ".\n";
	    G_CLO_LAST = nOriginalLength;  // this means that last position is at the end of the sequence
	}
	if( G_CLO_FIRST >= G_CLO_LAST )
	{
	    cout << "\n\tFirst position comes after last position.  Ignoring -f, -l, and -x options.  Using whole genome.\n";
	    G_CLO_FIRST = 0;
	    G_CLO_LAST  = nOriginalLength;
	    G_CLO_CUT = false;
	}
	
    cout<< "\n\tTesting sequences "<<G_CLO_BEG_SEQ<<" to "<<G_CLO_END_SEQ<<" as children in any triplet.\n";
        
	// now, splice!
	if( !G_CLO_CUT )
	{
	    for(i=0; i<N; i++)
	    {
	        string str = (pSeq+i)->nt.substr( G_CLO_FIRST , G_CLO_LAST - G_CLO_FIRST );
	        (pSeq+i)->nt = str;
	    }
	    GLen = pSeq->nt.length();
	    vector<int>::iterator b, e, f, l;
	    b = G_V_NTPOS.begin(); e = G_V_NTPOS.end(); f = b + G_CLO_FIRST; l = b + G_CLO_LAST;
	    G_V_NTPOS.erase(l,e);			// the order of these two
	    G_V_NTPOS.erase(b,f);			// operations matters a lot !!
            assert( GLen == G_V_NTPOS.size() );
	    //for(j=0; j<G_V_NTPOS.size(); j++) cout << "\n\t" << G_V_NTPOS[j];
	}
	if( G_CLO_CUT )
	{
	    //
	    // **** WARNING IF USER HAS SELECTED -3po OPTION HERE
	    //
	    if( !G_CLO_PYTHON && G_CLO_THIRD_POSITIONS_ONLY ) 
	    {
	        cout << "\n\t**\n\t**  WARNING: you are cutting out a middle segment of the sequence and requesting that\n\t**  only third positions be used.  Make sure that your starting position is the first\n\t**  position of a codon and that the segment you are cutting out has a length that is\n\t**  divisible by three.      \n\t**\n";
        
	    }
	    for(i=0; i<N; i++)
	    {
	        string str1 = (pSeq+i)->nt.substr( 0 , G_CLO_FIRST );
		string str2 = (pSeq+i)->nt.substr( G_CLO_LAST , nOriginalLength - G_CLO_LAST );
	        (pSeq+i)->nt = str1 + str2;
	    }
	    GLen = pSeq->nt.length();
	    vector<int>::iterator f, l;
	    f = G_V_NTPOS.begin() + G_CLO_FIRST; l = G_V_NTPOS.begin() + G_CLO_LAST;
	    G_V_NTPOS.erase(f,l);
            assert( GLen == G_V_NTPOS.size() );
	    //for(j=0; j<G_V_NTPOS.size(); j++) cout << "\n\t" << G_V_NTPOS[j];
	}
	//END EXTRACTION OF SUBSEQUENCE
	
	//BEGIN STRIPPING OUT CERTAIN CODON POSITIONS
	//
	GLen = (pSeq->nt).length();
	if( G_CLO_THIRD_POSITIONS_ONLY )
	{
	    for( j = 0; j < N; j++ )
	    {
	        string strNT3pos("");
	        for( i = 2; i < GLen; i+=3 )
	        {
	            strNT3pos = strNT3pos + pSeq[j].nt[i];
	        }
	        pSeq[j].nt = strNT3pos;
	    }
	    GLen = (pSeq->nt).length();

	    ivit = G_V_NTPOS.begin();
	    i=1;
	    while( ivit < G_V_NTPOS.end() )
	    {
	        if( i%3!=0 ) G_V_NTPOS.erase(ivit);
	        else ivit++;
	        i++;
	    }
	    assert(GLen == G_V_NTPOS.size());
	}
	else if( G_CLO_FIRST_AND_SECOND_POSITIONS_ONLY )
	{
	    for( j = 0; j < N; j++ )
	    {
	        string strNT12pos("");
	        for( i = 0; i < GLen; i++ )
	        {
	            if( i%3 != 2) strNT12pos = strNT12pos + pSeq[j].nt[i];
	        }
	        pSeq[j].nt = strNT12pos;
	    }
	    GLen = (pSeq->nt).length();

	    ivit = G_V_NTPOS.begin();
	    i=1;
	    while( ivit < G_V_NTPOS.end() )
	    {
	        if( i%3==0 ) G_V_NTPOS.erase(ivit);
	        else ivit++;
	        i++;
	    }
	    assert(GLen == G_V_NTPOS.size());
	}
	//
	//END STRIPPING OUT CERTAIN CODON POSITIONS
	
	// get some basic strain stats
	G_V_STATS = GetBasicStats( pSeq, N );
	
        //BEGIN REMOVING MONOMORPHIC SITES
        //
        if(!G_CLO_ALLSITES ) GLen = OnlyPolymorphicSites2( pSeq, N, &G_V_NTPOS ); // strips all monomorphic sites
	if( G_CLO_ALLSITES ) GLen = (pSeq->nt).length();
	// assert(GLen == G_V_NTPOS.size());
	//for(j=0; j<G_V_NTPOS.size(); j++) cout << "\n\t" << G_V_NTPOS[j];
	//
	//END REMOVING MONOMORPHIC SITES
	
	/*FILE* al_file = fopen("new.aln", "w");
	fprintf( al_file, "  %d  %d  \n", N, GLen );
	for(i=0; i<N; i++)
	{
	    fprintf(al_file, "%s  \t%s\n", (pSeq+i)->accnum.c_str(), (pSeq+i)->nt.c_str() );
	}
	
	cout << "\n\tGenerated new file in phylip format: `new.aln' \n\n";*/
    }
    else  // for FASTA files -- this is legacy code; the program should never go here
    {
        assert( false );
        cout << "\n\tassuming files are in FASTA format...";
	
        // here, we simply count the number of sequences in the file
        // based on the number of '>' characters
        DataFile = fopen( argv[2], "r" );
        assert( DataFile );
        //cout << "\n\tabout to count sequences in datafile " << argv[3];
        N = NumSequences( DataFile );
        fclose( DataFile );
        // return 1;

        // now that we know how many sequences we have, make an array of our N sequence objects
        pSeq = new seq[N];
        seq* p = pSeq;

        // here, read in data from DataFile into the allocated objects;
        DataFile = fopen( argv[2], "r" );
        for(i=0; i < N; i++)
        {
            //cout << "\n\tAbout to read seqeunce #" << i << " out of " << N;
	    ReadNextSequence_02( DataFile, p );
	    if( i == 0 )
	    {
	        // only assign this value once!
	        GLen = p->nt.length();
	        nOriginalLength = GLen;
	        cout << "\n\tFirst sequence's length = " << GLen;
	    }
	    int len = p->nt.length();
	    if( len != GLen )
	    {
  	        cout << "\n\tSeq#" << i << " (" << p->accnum << " -- " <<p->name << ") : length=" << len;
	    }
	    // cout << "\nread sequence " << i << "\n";
	    // p->makeAAfromNT();
	    p++;
        }
        fclose(DataFile);
        cout << "\n\tfinished reading in sequences . . . .\n";
	
	FILE* al_file = fopen("new.aln", "w");
	fprintf( al_file, "  %d  %d  \n", N, GLen );
	for(i=0; i<N; i++)
	{
	    fprintf(al_file, "%s  \t%s\n", (pSeq+i)->accnum.c_str(), (pSeq+i)->nt.c_str() );
	}
	fclose( al_file );
	
	cout << "\n\tFasta file converted to phylip format as file `new.aln' \n\n";
	
	return 0;
    }
    //

    // check if the user wants to analyze a particular subset of sequences
    if( G_CLO_SUBSET_FILENAME.length() > 0 )
    {
        // in this case, do not remove duplicate sequences; include
        // all the ones that the user wants;
        G_CLO_REMOVE_IDENTICAL_SEQUENCES = false;

        // remember that the function below (1) returns a seq*
        // (2) changes the variable N to the new number of sequences
        // (3) and takes care of allocation issues
        pSeq = ReadAccessionNumberFile( G_CLO_SUBSET_FILENAME, pSeq, &N, G_CLO_REMOVE_SUBSET );

        // and, make sure that the WHOLE subset is being used, even
        // if the user specified otherwise
        G_CLO_BEG_SEQ = 0;
        G_CLO_END_SEQ = N;
    }

    CheckForDuplicateAccessionNumbers( pSeq, N );
    int NDistinct = GetNumberDistinctSequences( pSeq, N );
    
    if( !G_CLO_PYTHON && G_RunMode != Info && G_RunMode != WriteRun ) 
    {
        cout << "\n\t" << NDistinct << " distinct sequences.\n\t"; 
        fflush(stdout);
    }

    if( G_CLO_REMOVE_IDENTICAL_SEQUENCES ) 
    {
        if( !G_CLO_PYTHON && G_RunMode != WriteRun )
        {
            cout << "\n\tRemoving identical sequences.\n\t"; 
            fflush(stdout);
        }
        pSeq = RemoveIdenticalSequences( pSeq, N, NDistinct );
        N = NDistinct;
        if( G_CLO_REMOVE_DISTANCE > 0 && G_RunMode != WriteRun )
        {
            pSeq = RemoveNeighborSequences( pSeq, &N, G_CLO_REMOVE_DISTANCE ); 
            if( !G_CLO_PYTHON ) cout << "\n\tRemoving sequences mod "<< G_CLO_REMOVE_DISTANCE << ".  Using "<<N<<" sequences.\n\t"; 
        }
    }

    // ----------------------------------------
    //
    // --- P R I N T  O U T  I N F O ---
    //
    if( G_RunMode==Info )
    {
        DisplayInfo( pSeq, N, nOriginalLength, NDistinct );
	delete[] pSeq;
	return 0;
    }
    //
    // --- E N D  P R I N T  O U T  I N F O ---
    //
    // ----------------------------------------
    
    // now make sure you have at least 3 sequences 
    if( N <= 2 && G_RunMode!=WriteRun )
    {
        cerr << "\n\tYour datafile must have a minimum of 3 sequences.\n\n\tExiting.\n\n"; 
        delete[] pSeq;
        return 0;
    }

    //BEGIN - USE INFO SUPPLIED BY -b AND -e OPTIONS
    //
    // SET BEGINNING SEQUENCE
    if( G_CLO_BEG_SEQ != 0 )
    {
	if( G_CLO_BEG_SEQ < 0 || G_CLO_BEG_SEQ > N-1 )
	{
	    cerr << "\n\t-b option: beginning sequence index " << G_CLO_BEG_SEQ << " must be between 0 and " << N-1 << ". \n\n\tIf you used the '-d' option to remove duplicate sequences, your \n\trequested start point with the -b option may now be out of range.\n\n\tExiting.\n\n";	
	    delete[] pSeq;
	    return 0;
	}
    } 
    // SET END SEQUENCE
    if( G_CLO_END_SEQ != -1 )
    {
        if( G_CLO_END_SEQ <= 0 || G_CLO_END_SEQ > N )
	{
            cerr << "\n\t-e option: end sequence index " << G_CLO_END_SEQ-1 << " must be between 0 and " << N-1 << ". \n\n\tIf you used the '-d' option to remove duplicate sequences, your \n\trequested end point with the -e option may now be out of range.\n\n\tExiting.\n\n";	
	    delete[] pSeq;
	    return 0;
        }
    }
    else
    {
	G_CLO_END_SEQ = N;
    }
    if( G_CLO_BEG_SEQ >= G_CLO_END_SEQ )
    {
	    cerr << "\n\t-b & -e options: beginning sequence has index after end sequence\n\n\tExiting.\n\n";	
	    delete[] pSeq;
	    return 0;
    }
    //END - USE INFO SUPPLIED BY -b AND -e OPTIONS
    
    G_D_NUM_TRIPLES = ((double)(G_CLO_END_SEQ - G_CLO_BEG_SEQ))*((double)(N-1))*((double)(N-2));

    if( (G_D_NUM_TRIPLES > 4.294e9 && !G_CLO_USE_ALL_TRIPLES) || (N > 1626 && G_CLO_USE_ALL_TRIPLES) )
    //
    // int max for an unsigend long is 4294967295
    // this means that 1626 is the max number of sequences
    // before we get an overflow; if an overflow happens the variable
    // just acts as if it's holding the value modulo INT_MAX
    //
    {
        cerr << "\n\t**\n\t**  WARNING: the number of comparisons you are requesting is larger than INT_MAX for\n\t**  an 'unsigned int' type on a 32-bit system.  The p-values below should be correct,\n\t**  but the numbers of comparisons that were approximated/computed/skipped is not\n\t**  guaranteed to be correct.\n\t**\n";
        G_TRIPLES_OVERFLOW = true;
        G_D_ALL_TRIPLES = ((double)N)*((double)(N-1))*((double)(N-2));
    }
    else // no overflow problem
    {
        G_N_NUM_TRIPLES = ((unsigned int)(G_CLO_END_SEQ - G_CLO_BEG_SEQ))*((unsigned int)(N-1))*((unsigned int)(N-2));
        G_N_ALL_TRIPLES = ((unsigned int)N)*((unsigned int)(N-1))*((unsigned int)(N-2));
        G_D_NUM_TRIPLES = -1.0;
        assert( G_D_ALL_TRIPLES < -0.5 ); // this should be set to -1
    }
    
    //BEGIN WRITE RUN
    if( G_RunMode == WriteRun )
    {
        if( G_CLO_OUTPUT_NEXUS )
        {
            cout << "#NEXUS\n\n[!Data from\n\n]\n\nbegin taxa;\n\tdimensions ntax=" << G_CLO_END_SEQ-G_CLO_BEG_SEQ << ";\n\ttaxlabels";
            for(i=G_CLO_BEG_SEQ; i<G_CLO_END_SEQ; i++)
	    {
	        cout << "\n\t\t" << (pSeq+i)->accnum;
	    }
            cout << ";\nend;\n\nbegin characters;\n\tdimensions nchar=" << GLen << ";\n\tformat missing=? gap=- matchchar=. datatype=dna;\n\toptions gapmode=missing;\n\tmatrix\n";
            for(i=G_CLO_BEG_SEQ; i<G_CLO_END_SEQ; i++)
	    {
	        cout << "\n" << (pSeq+i)->accnum << "    \t" << (pSeq+i)->nt;
	    }
	    cout << ";\nend;\n\n";
        }
        else if( G_CLO_OUTPUT_FASTA )
	{
	    for(i=G_CLO_BEG_SEQ; i<G_CLO_END_SEQ; i++)
	    {
	        fprintf(stdout, "> %s\n", (pSeq+i)->accnum.c_str() );
		fprintf(stdout, "%s\n", (pSeq+i)->nt.c_str() );
	    }
	}
	else
        {
	    fprintf( stdout, "  %d  %d  \n", G_CLO_END_SEQ-G_CLO_BEG_SEQ, GLen );
	    for(i=G_CLO_BEG_SEQ; i<G_CLO_END_SEQ; i++)
	    {
	        fprintf(stdout, "%s  \t%s\n", (pSeq+i)->accnum.c_str(), (pSeq+i)->nt.c_str() );
	    }
	}	
	delete[] pSeq;
	return 0;
    }
    //END WRITE RUN
    
    //BEGIN DRY RUN
    if( G_RunMode == DryRun )
    {
        DoDryRun( pSeq, N, nMaxUpOrDownStepsInHGRW, nMaxDescentAllowedInHGRW );
	delete[] pSeq;
	return 0;
    }
    //END DRY RUN

    //BEGIN FULL RUN
    if( G_RunMode==FullRun )
    {
        GFileRecombinants = fopen(G_FILENAME_RECOMBINANTS.c_str(), "w");
        if(!G_CLO_NO_3SREC_FILE) fprintf(GFileRecombinants, "P_ACCNUM \t Q_ACCNUM \t C_ACCNUM \t m \t n \t k \t  p \t [p_max]\t HS? \t log(p) \t DS(p) \t DS(p) \t min_rec_length \t breakpoints \n");

        if( G_CLO_RECORD_SKIPPED_TRIPLES ) GFileSkippedPValues = fopen(G_FILENAME_SKIPPEDPVALUES.c_str(), "w");
	
        double dPValue = DoFullRun( pSeq, N, G_CLO_THRESHOLD, G_CLO_MEMORY_ALLOTMENT, !G_CLO_PYTHON, G_CLO_YESNO );
	
        if( G_CLO_RECORD_SKIPPED_TRIPLES )
            fclose( GFileSkippedPValues );
        fclose( GFileRecombinants ); 
        if(G_CLO_WRITEPVALHIST)
            SendPValDistributionToOutfile( G_PV, N );
	
	/*if( G_CLO_PYTHON )
	{
	    if( dPValue<G_CLO_THRESHOLD ) 
	        cout << "-99\t-99"; // these -99 values are telling python that a recombination event took place
	    else
	        cout << dPValue << "\t" << ImpossibleTriples.size(); 	
	}*/
	
	if( !G_CLO_PYTHON ) cout << "\n\n\tFreeing memory.  Please wait  .  .  .  \n\n";
	delete[] pSeq;	
	return 0;
    }
    //END FULL RUN

    //BEGIN XRUN
    //
    // In this run we use the premade table of p-values which should
    // be stored in a file that begins with "PVT_BINARY_"
    //
    if( G_RunMode==XRun )
    {
        GFileRecombinants = fopen(G_FILENAME_RECOMBINANTS.c_str(), "w");
        if(!G_CLO_NO_3SREC_FILE) fprintf(GFileRecombinants, "P_ACCNUM \t Q_ACCNUM \t C_ACCNUM \t m \t n \t k \t  p \t [p_max]\t HS? \t log(p) \t DS(p) \t DS(p) \t min_rec_length \t breakpoints \n");
        if( G_CLO_RECORD_SKIPPED_TRIPLES )
            GFileSkippedPValues = fopen(G_FILENAME_SKIPPEDPVALUES.c_str(), "w");
	
        DoXRun( pSeq, N );
	
        if( G_CLO_RECORD_SKIPPED_TRIPLES )
            fclose( GFileSkippedPValues );
        fclose( GFileRecombinants );
        if(G_CLO_WRITEPVALHIST)
            SendPValDistributionToOutfile( G_PV, N );
        
    delete[] pSeq;	
	return 0;
    }
    //END XRUN

    //BEGIN SINGLE BREAKPOINT RUN
    if( G_RunMode==SingleBpRun )
    {
	//cout << "\n\tabout to perform single-breakpoint run...";
	double dPVal = SingleBreakpointRun( pSeq, N, G_CLO_THRESHOLD, G_CLO_MEMORY_ALLOTMENT, G_CLO_YESNO );
	
	delete[] pSeq;	
	return 0;
    }
    //END SINGLE BREAKPOINT RUN
    
    //BEGIN TRIPLET RUN
    if( G_RunMode==TripletRun )
    {
	//cout << "\n\tabout to perform single-breakpoint run...";
	DoTripletRun( pSeq, N, G_CLO_TRIPLET_P, G_CLO_TRIPLET_Q, G_CLO_TRIPLET_C );
        delete[] pSeq;	
	return 0;
    }
    //END TRIPLET RUN

    //BEGIN MATCH RUN
    if( G_RunMode==MatchRun )
    {
	//cout << "\n\tabout to perform single-breakpoint run...";
	DoMatchRun( pSeq, N );
        delete[] pSeq;	
	return 0;
    }
    //END MATCH RUN


    //
    // The rest of the code below (until the end of the main function) is for quick-run mode
    //


    // indices for 3 loops
    int nC, nP1, nP2;
    int nCount = 0;
    
    // counts of how may p-values were computed exactly, approximated, skipped
    unsigned int nNumComputedExactly=0;
    unsigned int nNumBounded=0;
    unsigned int nNumApproximatedHS=0;
    unsigned int nNumSkipped=0;
        
    // you must declare this variable EXACTLY ONCE so that the constructor for each class is called
    // then, you want to adjust M and K below so that you can analyze many types of HGRWs, with many types
    // of maximum descents
    ytable y( nMaxUpOrDownStepsInHGRW+1, nMaxUpOrDownStepsInHGRW+1, nMaxDescentAllowedInHGRW+1, nMaxDescentAllowedInHGRW+1 );
    
    if( G_CLO_RECORD_SKIPPED_TRIPLES ) GFileSkippedPValues = fopen(G_FILENAME_SKIPPEDPVALUES.c_str(), "w");
    GFileRecombinants = fopen(G_FILENAME_RECOMBINANTS.c_str(), "w");
    if(!G_CLO_NO_3SREC_FILE) fprintf(GFileRecombinants, "P_ACCNUM \t Q_ACCNUM \t C_ACCNUM \t m \t n \t k \t  p \t [p_max]\t HS? \t log(p) \t DS(p) \t DS(p) \t min_rec_length \t breakpoints \n");
    double dGlobalPValMin = ((float)1);
    int nLastPercentDone = 0;

    fprintf(stderr, "\n\tNeed a p-value of %e to survive multiple comparisons correction\n\n", G_CLO_THRESHOLD / ( ((double)N)*((double)(N-1))*((double)(N-2)) ) );

    double dnt = G_TRIPLES_OVERFLOW ? G_D_NUM_TRIPLES : ((double)G_N_NUM_TRIPLES);

    fprintf(stderr, "\t                           \t\t min p-value, so far \t  time elapsed\n");
    time_t start_time, now;
    start_time = time(NULL);
    bool bStopLooping = false;

    //
    // --- M A I N  L O O P --- T H I S   I S   F O R   Q U I C K   R U N   M O D E
    //
    // first loop through each child
    for( nC = G_CLO_BEG_SEQ; nC < G_CLO_END_SEQ; nC++ )
    {
        if( bStopLooping ) break;

	for( nP1=0; nP1 < N; nP1++ )
	{
	    if(nP1==nC) continue;
            if( bStopLooping ) break;

	    //BEGIN PROGRESS COUNTER
	    int nPercentDone = (int)(((double)100000)*(  ((double)(nP1))*((double)(N-2)) + ((double)(nC-G_CLO_BEG_SEQ))*((double)(N-1))*((double)(N-2)) )/dnt);
	    if( nPercentDone > nLastPercentDone )
	    {
	        nLastPercentDone = nPercentDone;
       	        now = time(NULL);
	        int timer=now-start_time;
	        fprintf(stderr, "\tQUICK RUN Progress --  %3.3f%%\t\t %e    \t  %03d:%02d:%02d\r", (double)nPercentDone/((double)1000), dGlobalPValMin, timer/3600, (timer/60)%60, timer%60); 
		fflush(stderr);
	    } 
	    //END PROGRESS COUNTER
	    
	    for( nP2=0; nP2 < N; nP2++ )
	    {
		if(nP2==nC || nP2==nP1 ) continue;
		nCount++;
		MDTRIPLE mdt = Calculate_Maximum_Descent( pSeq+nP1, pSeq+nP2, pSeq+nC );
		
		if( y.can_compute_exact_pvalue( mdt.m, mdt.n, mdt.md ) )
		{
		    double pvalue = y.compute_exact_pvalue( mdt.m, mdt.n, mdt.md );
		    nNumComputedExactly++;
		    Bin( pvalue );
		    if( pvalue < dGlobalPValMin ) dGlobalPValMin = pvalue;
		    if( DS(pvalue) < G_CLO_THRESHOLD ) 
		    {
		        RecordRecombinantTriplet( nP1, nP2, nC, mdt, pvalue, pSeq  );
		        if( G_CLO_YESNO ) { bStopLooping = true; break; }
		    }
		}
		else if( y.can_approximate_pvalue( mdt.m, mdt.n, mdt.md ) )
		{
		    BOUNDS bnds = y.approximate_pvalue( mdt.m, mdt.n, mdt.md );

		    // either do an HS-approximation, or accept the bounds above
		    if( bnds.max/bnds.min > 3.0 && G_CLO_USE_SIEGMUND_APPROX )
		    {
		        double pvalue = approx::siegmund_discrete( mdt.m, mdt.n, mdt.md );
		        nNumApproximatedHS++;
		        Bin( pvalue );
		        if( pvalue < dGlobalPValMin ) dGlobalPValMin = pvalue;
		        if( DS(pvalue) < G_CLO_THRESHOLD )
		        {
		            RecordRecombinantTriplet( nP1, nP2, nC, mdt, pvalue, pSeq, HOGANSIEGMUND );
		            if( G_CLO_YESNO ) { bStopLooping = true; break; }
		        }
 
		    }
		    else
		    {
		        nNumBounded++;
		        Bin( bnds.max );
		        if( bnds.max < dGlobalPValMin ) dGlobalPValMin = bnds.max;
		        if( DS(bnds.max) < G_CLO_THRESHOLD )
		        {
		            RecordRecombinantTriplet( nP1, nP2, nC, mdt, bnds, pSeq  );		
		            if( G_CLO_YESNO ) { bStopLooping = true; break; }
		        }
		    }
		}
		else // we are out of array bounds in y-table
		{
		    if( G_CLO_USE_SIEGMUND_APPROX )
		    {
		        double pvalue = approx::siegmund_discrete( mdt.m, mdt.n, mdt.md );
		        nNumApproximatedHS++;
		        Bin( pvalue );
		        if( pvalue < dGlobalPValMin ) dGlobalPValMin = pvalue;
		        if( DS(pvalue) < G_CLO_THRESHOLD )
		        {
		            RecordRecombinantTriplet( nP1, nP2, nC, mdt, pvalue, pSeq, HOGANSIEGMUND );
		            if( G_CLO_YESNO ) { bStopLooping = true; break; }
		        }		    
		    }
		    else
		    {
		        nNumSkipped++;
		        if( G_CLO_RECORD_SKIPPED_TRIPLES ) RecordSkippedTriplet( nP1, nP2, nC, mdt, pSeq  );
		    }
		}
	    }
	}
    }
    //
    // --- E N D  M A I N  L O O P --- Q U I C K   R U N   M O D E
    //



    if( bStopLooping )
    {
	if(!G_TRIPLES_OVERFLOW) nNumSkipped = N*(N-1)*(N-2) - nNumComputedExactly - nNumBounded - nNumApproximatedHS;
	else nNumSkipped = -1;
    }

    // CalculateBestBreakpoints( ... )
    DisplayResults( nNumComputedExactly, nNumBounded, nNumApproximatedHS, nNumSkipped, dGlobalPValMin, pSeq, N );

    if( G_CLO_RECORD_SKIPPED_TRIPLES ) fclose( GFileSkippedPValues );
    fclose( GFileRecombinants );
    if(G_CLO_WRITEPVALHIST)
        SendPValDistributionToOutfile( G_PV, N );

    cerr << "\n\n\tFreeing memory.  Please wait  .  .  .  \n\n";
    delete[] pSeq;
    return 0;
} // end main

void DisplayResults( unsigned int num_computed_exactly, unsigned int num_bounded, unsigned int num_approximated_hs, unsigned int num_skipped, double min_pvalue, seq* pSeq, int N, int num_rec_triplets )
{
    double dBonf; // number to use in Bonferroni correction
    int nNumRecombinant=0;
    int nNumRecombinantAndLong=0;
    
    if(G_CLO_WRITELONGRECOMBINANTS)
    {
        FILE* ff = fopen(G_FILENAME_LONGRECOMBINANTS.c_str(), "w");
    
        for(int i=0; i<N; i++)
        {
            if( pSeq[i].recombinant ) nNumRecombinant++;
            if( pSeq[i].recombinant_and_is_long ) 
            {
                nNumRecombinantAndLong++;
                fprintf( ff, "%s\n", pSeq[i].accnum.c_str() );
            }
        }
        fclose( ff );
    }
    
    if(G_TRIPLES_OVERFLOW) dBonf = G_CLO_USE_ALL_TRIPLES ? G_D_ALL_TRIPLES : G_D_NUM_TRIPLES;
    else dBonf = G_CLO_USE_ALL_TRIPLES ? ((double)G_N_ALL_TRIPLES) : ((double)G_N_NUM_TRIPLES);
    
    if( G_TRIPLES_OVERFLOW) cout << "\n\n\tNumber of triples tested: \t\t " << G_D_NUM_TRIPLES;
    if(!G_TRIPLES_OVERFLOW) cout << "\n\n\tNumber of triples tested: \t\t " << G_N_NUM_TRIPLES;
    cout << "\n\tNumber of p-values computed exactly: \t " << num_computed_exactly;
    cout << "\n\tNumber of p-values bounded: \t\t " << num_bounded;
    cout << "\n\tNumber of p-values approximated (hs): \t " << num_approximated_hs;
    cout << "\n\tNumber of p-values not computed: \t " << num_skipped;
    if(num_rec_triplets >= 0) cout << "\n\n\tNumber of recombinant triplets :                               \t " << num_rec_triplets;
    else cout << "\n\n\tNumber of recombinant triplets :                               \t ??";
    cout <<   "\n\tNumber of distinct recombinant sequences:                      \t " << nNumRecombinant;
    if( G_CLO_YESNO ) cout << "  [[ search stopped when first one found ]] ";
    if( G_CLO_NO_BREAKPOINTS )
    {
        cout <<   "\n\tNumber of distinct recombinant sequences at least "<< G_CLO_MIN_RECOMBINANT_LENGTH <<" nt long: \t ??";
        cout <<   "\n\tLongest of short recombinant segments:                         \t ??";
    }
    else
    {
        cout <<   "\n\tNumber of distinct recombinant sequences at least "<< G_CLO_MIN_RECOMBINANT_LENGTH <<" nt long: \t " << nNumRecombinantAndLong;
        cout <<   "\n\tLongest of short recombinant segments:                         \t " << G_LONGEST_RECOMBINANT_SEGMENT << " nt";
    }
    
    cout << "\n\n\t-----------------------------------------------------------------------------";    
    cout << "\n\t| Rejection of the null hypothesis of clonal evolution at p = " << DS( min_pvalue );
     printf("\n\t|                                                         p = %1.3e", DS( min_pvalue ) );
    //cout << "\n\t|\n\t|\t\t\tlog10( p ) = " << log10( DS( min_pvalue ) );
    cout << "\n\t| uncorrected p = " << min_pvalue;
    cout << "\n\t| bonferroni  p = " << min_pvalue*dBonf;
    cout << "\n\t-----------------------------------------------------------------------------";
	    
    fflush(stdout);
    return;
}

void OutputFormattedForPython( unsigned int num_computed_exactly, unsigned int num_bounded, unsigned int num_approximated_hs, unsigned int num_skipped, double min_pvalue, seq* pSeq, int N, int num_rec_triplets )
{
    printf("%1.4f\t%d\t%d\t%d\t%d\t%d\t%d", DS( min_pvalue ), num_computed_exactly, num_bounded, num_approximated_hs, num_skipped, N, num_rec_triplets );
}


void DoTripletRun( seq* pSeq, int N, string p_accnum, string q_accnum, string c_accnum )
{
    int p_index = GetIndexByAccNum( pSeq, N, p_accnum );
    int q_index = GetIndexByAccNum( pSeq, N, q_accnum ); 
    int c_index = GetIndexByAccNum( pSeq, N, c_accnum );
    
    if( p_index == -1 )
    {
        cerr << "\n\tNo sequence with accession number " << p_accnum << ".\n\n";
        return;
    }
    if( q_index == -1 )
    {
        cerr << "\n\tNo sequence with accession number " << q_accnum << ".\n\n";
        return;
    }
    if( c_index == -1 )
    {
        cerr << "\n\tNo sequence with accession number " << c_accnum << ".\n\n";
        return;
    }
    
    
    if( p_index==q_index || p_index==c_index || c_index==q_index )
    {
	    cerr << "\n\tIndices must be distinct.\n\n";
	    return;
    }
    
    seq* parent1 = pSeq+p_index;
    seq* parent2 = pSeq+q_index;
    seq* child   = pSeq+c_index;
    
    int nMinRecLength = GLen;
    //int nMaxRecLength = -1;

    MDTRIPLE mdt = Calculate_Maximum_Descent( parent1, parent2, child );
    
    int nPCdist = SeqDistanceNT( pSeq+p_index, pSeq+c_index );
    int nQCdist = SeqDistanceNT( pSeq+q_index, pSeq+c_index );
    int nPCdist_ignore_gaps = SeqDistanceNT( pSeq+p_index, pSeq+c_index, true );
    int nQCdist_ignore_gaps = SeqDistanceNT( pSeq+q_index, pSeq+c_index, true );
    
    cerr << "\n\tInformative sites of type P \t" << mdt.m;
    cerr << "\n\tInformative sites of type Q \t" << mdt.n;
    cerr << "\n\tMaximum Descent \t\t" << mdt.md;
    cerr << "\n\n\tParent P: \t\t\t" << parent1->accnum << "(i="<<p_index<<")   \t ("<<nPCdist<<" nt diff w child sequence; "<<nPCdist_ignore_gaps<<" ignoring gaps & ambig. nt)";
    cerr <<   "\n\tParent Q: \t\t\t" << parent2->accnum << "(i="<<q_index<<")   \t ("<<nQCdist<<" nt diff w child sequence; "<<nQCdist_ignore_gaps<<" ignoring gaps & ambig. nt)";
    cerr <<   "\n\tChild:    \t\t\t" << child->accnum << "(i="<<c_index<<")   \n\n\tBreakpoint Ranges:\n\n";
    
    // remember to free this later, since it is allocated inside the called function
    vector<BREAKPOINTRANGES>* pvBPR = GetBreakpoints( parent1, parent2, child, mdt.md, &nMinRecLength );
    
    vector<BREAKPOINTRANGES>::iterator it;
    int nRanges = pvBPR->size();
    int nPairs = 0;

    for( it=pvBPR->begin(); it < pvBPR->end(); it++ )
    {
	BREAKPOINTRANGES bpr = *it;
	cout << "\t\t" << bpr.L1 << "-" << bpr.R1 << " and " << bpr.L2 << "-" << bpr.R2 << "\n"; fflush(stdout);
	
	// get max and min length
	// if( bpr.R2 - bpr.L1 > nMaxRecLength ) nMaxRecLength = bpr.R2 - bpr.L1;
	// if( bpr.L2 - bpr.R1 < nMinRecLength ) nMinRecLength = bpr.L2 - bpr.R1;
	
	nPairs += (bpr.R2-bpr.L2+1)*(bpr.R1-bpr.L1+1);
    }
    
    cerr << "\n\t# Breakpoint Pairs: " << nPairs; 
    cerr << "\n\t# Breakpoint Ranges: " << nRanges; cout << "\n";
    cerr << "\n\tMinimum length of recombinant segment is " << nMinRecLength << "nt.     (excluding gaps and ambiguous nucleotides)\n\n";
    //cerr << "\n\tMaximum length of recombinant segment is " << nMaxRecLength << "nt.\n\n";
    
    delete pvBPR;
    
    MakePSFile(pSeq, N, p_index, q_index, c_index );
}

void CalculateBestBreakpoints( seq* pSeq, int N )
{
    bool bFirstRecombinantDone = false; 

    // the index `c' is for `child sequence'
    for(int c=0; c<N; c++)
    {
        int p = pSeq[c].best_parent1_index;
        int q = pSeq[c].best_parent2_index;
        
        if( p>=0 && q>=0 && p<N && q<N )
        {
            if( !bFirstRecombinantDone )
            {
                bFirstRecombinantDone=true;
                fprintf(stderr, "\n\n");
            }
            fprintf(stderr, "\tCalculating breakpoints for sequence %d of %d          \r", c, N);
        
            MDTRIPLE mdt;
            mdt.m  = pSeq[c].best_m;
            mdt.n  = pSeq[c].best_n;
            mdt.md = pSeq[c].best_md;

            // this tells you if the p-value was bounded and recorded in the form of a BOUNDS structure
            bool bounded = pSeq[c].best_bounds.min > 1.5 ? false : true;

            float p_min  = pSeq[c].best_bounds.min;
            float p_max  = pSeq[c].best_bounds.max;
            float pvalue = pSeq[c].best_pvalue;
            bool hs      = pSeq[c].best_hs;

            //                                                       m   n   k    pvalue     -99      hs
            fprintf( GFileRecombinants, "%s-[%d]\t%s-[%d]\t%s-[%d]\t%d\t%d\t%d\t  %1.12f\t  %1.12f\t  %d\t  %2.4f\t  %1.5f\t  %e",
		 ((pSeq[p]).accnum).c_str(), p,
		 ((pSeq[q]).accnum).c_str(), q,
		 ((pSeq[c]).accnum).c_str(), c,
		 mdt.m, mdt.n, mdt.md, 
		 bounded?p_min:pvalue, bounded?p_max:-99.0, hs, log10(pvalue), 
		 DS( pvalue ), DS( pvalue )  );

            int len = (pSeq->ntfull).length();

            // remember to free these two before returning from function
            int* pnRecLength = new int;
            vector<BREAKPOINTRANGES>* pvBPR = NULL;

            pvBPR = GetBreakpoints( pSeq+p, pSeq+q, pSeq+c, mdt.md, pnRecLength );
            assert( pvBPR->size() != 0 );

            fprintf( GFileRecombinants, " \t %d", *pnRecLength );
            if( *pnRecLength > G_LONGEST_RECOMBINANT_SEGMENT ) G_LONGEST_RECOMBINANT_SEGMENT = *pnRecLength;

            if( *pnRecLength >= G_CLO_MIN_RECOMBINANT_LENGTH ) 
            {
                (pSeq[c]).recombinant_and_is_long = true;
            }

            vector<BREAKPOINTRANGES>::iterator it;
            for(int i=0; i< pvBPR->size(); i++)
            {
                BREAKPOINTRANGES bpr = (*pvBPR)[i];
                if( bpr.R1-bpr.L1>0 && bpr.R2-bpr.L2>0 )        fprintf( GFileRecombinants, "  \t  %d-%d,%d-%d", bpr.L1, bpr.R1, bpr.L2, bpr.R2 );
                else if( bpr.R1-bpr.L1==0 && bpr.R2-bpr.L2>0  ) fprintf( GFileRecombinants, "  \t  %d,%d-%d", bpr.L1, bpr.L2, bpr.R2 );
                else if( bpr.R1-bpr.L1>0  && bpr.R2-bpr.L2==0 ) fprintf( GFileRecombinants, "  \t  %d-%d,%d", bpr.L1, bpr.R1, bpr.L2 );
                else if( bpr.R1-bpr.L1==0 && bpr.R2-bpr.L2==0 ) fprintf( GFileRecombinants, "  \t  %d,%d", bpr.L1, bpr.L2 );
                else assert( false );
            }

            fprintf( GFileRecombinants, "\n" ); fflush( GFileRecombinants );
        }
    }
    return;
}

//
// this needs to be freed after it is returned
//
vector<BREAKPOINTRANGES>* GetBreakpoints( seq* parent1, seq* parent2, seq* child, int md, int* pnRecLength )
{
    // this is the vector pointer that will be returned
    vector<BREAKPOINTRANGES>* pvBPR = new vector<BREAKPOINTRANGES>;
    assert( pvBPR->size() == 0 );
    
    int len = (parent1->ntfull).length();
    int shortest = len + 1;
    
    int b1, b2; 	// these will actually need to traverse the ranges in the
    			// G_V_NTPOS vector
    for( b1=0; b1<len; b1++)
    {
	int nCurrentDescent=0;
	for( b2=b1+1; b2<=len; b2++)
        {
	    char p = (parent1->ntfull)[b2-1];
	    char q = (parent2->ntfull)[b2-1];
	    char c = (child->ntfull)[b2-1];
	    if( p==c && q!=c && ACGT(p) && ACGT(q) && ACGT(c) ) nCurrentDescent--; // you have to decrement bc this was a step up
	    if( p!=c && q==c && ACGT(p) && ACGT(q) && ACGT(c) ) nCurrentDescent++;	
	    
	    if( nCurrentDescent == md )
	    {
	        // function below will return false if pvBPR->size()==0
	        bool bAdded = TryAddingToCurrentRanges( pvBPR, b1, b2 );

       	        if( !bAdded )
	        {
	            BREAKPOINTRANGES bpr;
	            bpr.L1 = b1; bpr.R1 = b1; bpr.L2 = b2; bpr.R2 = b2;
	            pvBPR->push_back( bpr );
	        }
	        
	        int nInside  = GetNumberNonGappedSites( parent1, parent2, child, b1, b2 );
	        //fprintf( stderr, "\n\n\t\t\t Inside: num-nongapped is %d \n", nInside );
	        int nOutside = GetNumberNonGappedSites( parent1, parent2, child, 0, b1 ) + GetNumberNonGappedSites( parent1, parent2, child, b2, len );
	        //fprintf( stderr, "\n\n\t\t\t Outside: num-nongapped is %d \n", nOutside );
	        int shorter = (nInside>nOutside) ? nOutside : nInside;
	        if( shorter < shortest ) shortest = shorter;
	    }
	}
    }

    assert( shortest < len );
    *pnRecLength = shortest;
    //cerr << "\n\n";
    return pvBPR;
}
//

bool TryAddingToCurrentRanges( vector<BREAKPOINTRANGES>* pvBPR, int b1, int b2 )
{
    //cerr << "\n\tTrying to add " << b1 << " " << b2;
    
    if( pvBPR->size() == 0 ) return false;

    vector<BREAKPOINTRANGES>::iterator it = pvBPR->begin();

    while( it < pvBPR->end() )
    {
        // test to see if b1 is inside the current range for breakpoint 1
        if( b1 >= (*it).L1 && b1 <= (*it).R1 )
        {
            if( b2 >= (*it).L2 && b2 <= (*it).R2 )  // testing if b2 is inside the range for breakpoint 2
            {
                // this means that the breakpoint was already in the range, so we're done
                return true;
            }
            if( b2 == (*it).L2-1 )
            {
                // in this case expand the range of the second breakpoint
                (*it).L2 = b2;
                return true;
            }
            if( b2 == (*it).R2+1 )
            {
                // in this case expand the range of the second breakpoint
                (*it).R2 = b2;
                return true;
            }
        }
        
        // test to see if b2 is inside the current range for breakpoint 2
        if( b2 >= (*it).L2 && b2 <= (*it).R2 )
        {
            if( b1 >= (*it).L1 && b1 <= (*it).R1 )  // testing if b1 is inside the range for breakpoint 1
            {
                // this means that the breakpoint was already in the range, so we're done
                return true;
            }
            if( b1 == (*it).L1-1 )
            {
                // in this case expand the range of the second breakpoint
                (*it).L1 = b1;
                return true;
            }
            if( b1 == (*it).R1+1 )
            {
                // in this case expand the range of the second breakpoint
                (*it).R1 = b1;
                return true;
            }
        }
        
        // increment the iterator, moving to the next breakpoint range
        it++;
    }
    return false;
}

//
// returns the number of positions, between breakpoints b1 and b2, where there are 
// no gaps and no ambiguous nucleotides
//
int GetNumberNonGappedSites( seq* parent1, seq* parent2, seq* child, int b1, int b2 )
{
    int i;
    int n = 0;
    for(i=b1; i<b2; i++)
    {
        char p = (parent1->ntfull)[i];
        char q = (parent2->ntfull)[i];
        char c = (child->ntfull)[i];
        if( ACGT(p) && ACGT(q) && ACGT(c) ) n++;
    }
    return n;
}

/*int GetMinRecombinantLength( vector<BREAKPOINTRANGES>* pvBPR, int len )
{
    if( pvBPR->size() == 0 ) return 0;

    int shortest=len;
    vector<BREAKPOINTRANGES>::iterator it = pvBPR->begin();
    
    while( it < pvBPR->end() )
    {
        int nShortestInsideSegment  = (*it).L2 - (*it).R1;
        int nShortestOutsideSegment = (*it).L1 + (len - (*it).R2);
        int shorter = (nShortestInsideSegment>nShortestOutsideSegment) ? nShortestOutsideSegment : nShortestInsideSegment;
        if( shorter < shortest ) shortest = shorter;
        it++;
    }
    
    return shortest;
}*/


void MakePSFile(seq* pSeq, int N, int p_index, int q_index, int c_index )
{
    //int* s = new int[N];  	// will hold the type of site this is 
    				// 0 means all identical; 1 means inf site of type P
				// 2 means inf site of type Q; 3 means parents identical & different from child
				// 4 means all different; 5 is for gaps or ambiguous nucleotides
    int w = 2;			// width of each nucleotides space in the PS file
    int h = 240;

    int len = (pSeq->ntfull).length();
    stringstream ss;
    string filename;
    
    //ss << pSeq[p_index].accnum << "." << pSeq[q_index].accnum << "." << pSeq[c_index].accnum  << ".eps";
    ss << "3s.triplet." << p_index << "." << q_index << "." << c_index  << ".eps";
    ss >> filename;
    //filename = "psfile_dengue.eps";
    //string filename_walk = pSeq[c_index].accnum + "walk.eps";
    FILE* psfile = fopen( filename.c_str(), "w" );
    //FILE* psfile_walk = fopen( filename.c_str(), "w" );
    
    fprintf( psfile, "%!PS-Adobe-3.0 EPSF-3.0\n%%%%BoundingBox: 0 0 %d %d \n%%%%EndComments", (len+1)*w, h);
    fprintf( psfile, "\n\n%%%%%%%%%%%% \n/Times-Roman findfont \n7 scalefont \nsetfont");
    fprintf( psfile, "\n\n0.001 setlinewidth \n\n/w {%d} def    % This is the width of a small box on the plot\n\n/h {%d} def    % This is the height of a small box on the plot", w, h);
    
    /*fprintf( psfile_walk, "%!PS-Adobe-3.0 EPSF-3.0\n%%%%BoundingBox: 0 0 %d %d \n%%%%EndComments", (len+1)*w, 300);
    fprintf( psfile_walk, "\n\n%%%%%%%%%%%% \n/Times-Roman findfont \n7 scalefont \nsetfont");
    fprintf( psfile_walk, "\n\n0.001 setlinewidth \n\n/w {%d} def    % This is the width of a small box on the plot\n\n/h {%d} def    % This is the height of a small box on the plot", w, h);*/
    
    for(int i = 0; i < len; i++)
    {
        char p = pSeq[p_index].ntfull[i];
        char q = pSeq[q_index].ntfull[i];
        char c = pSeq[c_index].ntfull[i];
        
        if( !ACGT(p) || !ACGT(q) || !ACGT(c) ) 
        {
            // if it's white, print nothing
            //fprintf( psfile, "\n\n1 1 1 setrgbcolor %d 3 moveto \n0 h rlineto w 0 rlineto 0 h neg rlineto closepath stroke", i*w );
        }
        else if( p==q && q==c )
        {
            // if it's white, print nothing
            //fprintf( psfile, "\n\n1 1 1 setrgbcolor %d 3 moveto \n0 h rlineto w 0 rlineto 0 h neg rlineto closepath stroke", i*w );
        }
        else if( p==c && q!=c )
        {
            fprintf( psfile, "\n\n1 0 0 setrgbcolor %d 3 moveto \n0 h rlineto w 0 rlineto 0 h neg rlineto closepath fill stroke", i*w );
            //printf("  %d  ", i );
        }
        else if( p!=c && q==c )
        {
            fprintf( psfile, "\n\n0 0 1 setrgbcolor %d 3 moveto \n0 h rlineto w 0 rlineto 0 h neg rlineto closepath fill stroke", i*w );
        }
        else  // draw a gray line if there is polymorphisms but it is not an informative site
        {
            fprintf( psfile, "\n\n0.4 0.4 0.4 setrgbcolor %d 3 moveto \n0 %d rlineto w 0 rlineto 0 h neg rlineto closepath fill stroke", i*w, h/3 );
        }

    }
    
    fprintf( psfile, "\n\nshowpage\n%%EOF");
    fclose( psfile );
    //fclose( psfile_walk );
}


MDTRIPLE Calculate_Maximum_Descent( seq* parent1, seq* parent2, seq* child )
{
    int nMaxSeen=0; // the max value of the hgrw seen so far
    int nMaxDescentSeen=0; // the max descent seen so far
    int nMaxDescentToThisPoint=0; // the max descent possible to this point
    int nCurrentHeight=0;
    int nM=0;
    int nN=0;
    int i;
   
    //cout << "\n\tentering Calculate_Maximum_Descent function with sequences " << parent1->accnum << " " << parent2->accnum << " " << child->accnum;
    //cout << "\n\tthe value of GLen is " << GLen;
      
    for(i=0; i < GLen; i++)
    {
        char p = (parent1->nt)[i];
	char q = (parent2->nt)[i];
	char c = (child->nt)[i];
	
        //this is an up-step
        if( p==c && q!=c && ACGT(p) && ACGT(q) && ACGT(c) )
        {
            nCurrentHeight++;
	    nM++;
	    if( nCurrentHeight > nMaxSeen ) nMaxSeen = nCurrentHeight;
	    nMaxDescentToThisPoint = nMaxSeen - nCurrentHeight;
	    if( nMaxDescentToThisPoint > nMaxDescentSeen ) nMaxDescentSeen = nMaxDescentToThisPoint; 	  
        }
      
        //this is a down-step
        if( p!=c && q==c && ACGT(p) && ACGT(q) && ACGT(c) )
        {
            nCurrentHeight--;
	    nN++;
	    if( nCurrentHeight > nMaxSeen ) nMaxSeen = nCurrentHeight;
	    nMaxDescentToThisPoint = nMaxSeen - nCurrentHeight;
	    if( nMaxDescentToThisPoint > nMaxDescentSeen ) nMaxDescentSeen = nMaxDescentToThisPoint;       
        }
      
      //otherwise, there is no step
    }
   
    MDTRIPLE mdt;
    mdt.m  = nM;
    mdt.n  = nN;
    mdt.md = nMaxDescentSeen;
    /*if( nMaxDescentSeen < 0 )
        cout << "\n\tTriple is (" << mdt.m << ", " << mdt.n << ", " << mdt.md << ") for sequences" << parent1->accnum << ", " << parent2->accnum << ", " << child->accnum;*/
   
    return mdt;
}

MDTRIPLE Calculate_Maximum_Height( seq* parent1, seq* parent2, seq* child )
{
    int nMaxHeight=0; // the max value of the hgrw seen so far
    int nCurrentHeight=0;
    int nM=0;
    int nN=0;
    int i;
      
    for(i=0; i < GLen; i++)
    {
        char p = (parent1->nt)[i];
	char q = (parent2->nt)[i];
	char c = (child->nt)[i];
        
	//this is an up-step
        if( p==c && q!=c && ACGT(p) && ACGT(q) && ACGT(c) )
        {
            nCurrentHeight++;
	    if( nCurrentHeight > nMaxHeight ) nMaxHeight = nCurrentHeight;
	    nM++;
        }
        //this is a down-step
        if( p!=c && q==c && ACGT(p) && ACGT(q) && ACGT(c) )
        {
            nCurrentHeight--;
	    nN++;
        }
      
        //otherwise, there is no step
    }
   
    MDTRIPLE mdt;
    mdt.m  = nM;
    mdt.n  = nN;
    mdt.md = nMaxHeight;
   
    //cout << "\n\tTriple is (" << mdt.m << ", " << mdt.n << ", " << mdt.md << ")";
   
    return mdt;
}

void DisplayInfo( seq* pSeq, int N, int origLen, int NDistinct )
{
    int i,j;
    
    unsigned int NN = (unsigned int) N;
    unsigned int nNumComparisons = NN*(NN-1)*(NN-2);
    int active_length = G_CLO_LAST-G_CLO_FIRST;
    if( G_CLO_CUT ) active_length = origLen - active_length;
    
    double* pdStats = StrainStats( pSeq, N );            
    int nMaxDist = (int) pdStats[3];
    double dMeanDist = pdStats[0];
    delete[] pdStats;
    
    int nNumSitesWithNoGaps=GLen;
    for(i = 0; i < GLen; i++)
    {
        for(j=0; j < N; j++)
        {
            char c = ((pSeq+j)->nt)[i];
            if(c == '-') { nNumSitesWithNoGaps--; break; }
        }
    }
    
    cout << "\n\t3SEQ INFO";
    cout << "\n\t---------------------------------\n\t";
    cout << "\n\tNumber of sequences is          " << N ;
    cout << "\n\tNumber of distinct sequences is " << NDistinct ;
    cout << "\n\tNumber of comparisons is " << nNumComparisons << "\n\t" ;
    cout << "\n\tOriginal sequence length: " << origLen << "nt.";
    
    if( !G_CLO_CUT ) cout << "\n\tUsing " << G_CLO_LAST-G_CLO_FIRST << " positions, from " <<G_CLO_FIRST+1<< " to " <<G_CLO_LAST<< " inclusive.";
    if( G_CLO_CUT ) cout << "\n\tCutting out " << G_CLO_LAST-G_CLO_FIRST << " positions, from " <<G_CLO_FIRST+1<< " to " <<G_CLO_LAST<< " inclusive.";
    
    if( !G_CLO_ALLSITES ) cout << "\n\n\tNumber of polymorphic sites is " << GLen << ".  Using only polymorphic sites.";
    if(  G_CLO_ALLSITES ) cout << "\n\n\tUsing all " << GLen << " sites.  \n\tCounting gap/nucleotide mismatches as differences.";
    printf("\n\t\tgapped: %d, mono: %d, bi: %d, tri: %d, tetra: %d", (int)G_V_STATS[0],(int)G_V_STATS[1],(int)G_V_STATS[2],(int)G_V_STATS[3],(int)G_V_STATS[4]);
    
    cout << "\n\n\tNumber of sites where there are no gaps is " << nNumSitesWithNoGaps;
    
    if( !G_CLO_ALLSITES ) cout << "\n\tWatterson's Theta is \t\t" << ((double)GLen)/log((double)N);
    if( !G_CLO_ALLSITES ) cout << "\n\tWatterson's Theta (per site) is " << ((double)GLen)/ ( log((double)N)*((double)active_length) );
    
    cout << "\n\n\tMax  pairwise-distance between strains is " << nMaxDist;  
    cout << "\n\tMean pairwise-distance between strains is " << dMeanDist;  
    cout << "\n\tMean pwd per site (pi) is                 " << dMeanDist / ((double)active_length);  
    cout << "\n\t\n\t---------------------------------\n\n";
}

void DoDryRun( seq* pSeq, int N, int maxMN, int maxK )
{
    // indices for 3 loops
    int nC, nP1, nP2;
    int maxInfSites=0; // maximum number of informative sites
    int nMegs = GetMegsNeeded( maxMN, maxK );
    
    // counts of how many p-values can be computed exactly, approximated, skipped
    unsigned int nNumComputedExactly=0;
    unsigned int nNumApproximated=0;
    unsigned int nNumSkipped=0;
    int nLastPercentDone = 0;
        
    fprintf(stderr, "\n");
    
    double dnt = G_TRIPLES_OVERFLOW ? G_D_NUM_TRIPLES : ((double)G_N_NUM_TRIPLES);
    
    // first loop through each child
    for( nC=G_CLO_BEG_SEQ; nC < G_CLO_END_SEQ; nC++ )
    {
	for( nP1=0; nP1 < N; nP1++ )
	{
	    if(nP1==nC) continue;
	    	    
	    //BEGIN PROGRESS COUNTER        
	    int nPercentDone = (int)(((double)100000)*(  ((double)(nP1))*((double)(N-2)) + ((double)(nC-G_CLO_BEG_SEQ))*((double)(N-1))*((double)(N-2)) )/dnt);
	    if( nPercentDone > nLastPercentDone )
	    {
		    nLastPercentDone = nPercentDone;
		    fprintf(stderr, "\tDRY RUN Progress --  %3.3f%% \t\t(%d)    \r", (double)nPercentDone/((double)1000), maxInfSites); 
		    fflush(stderr);
	    } 
	    //END PROGRESS COUNTER

	    
	    for( nP2=0; nP2 < N; nP2++ )
	    {
		if(nP2==nC || nP2==nP1 ) continue;
		
		MDTRIPLE mdt = Calculate_Maximum_Descent( pSeq+nP1, pSeq+nP2, pSeq+nC );
		
		if( mdt.m > maxInfSites ) maxInfSites=mdt.m;
		
		// REMEMBER: you cannot use the ytable::can_compute_exact_pvalue and ytable::can_approximate_pvalue
		// functions here since we have not yet allocated space for the ytable
		if( (mdt.n - mdt.m) == mdt.md ) nNumComputedExactly++;
		else if( mdt.n != 0 &&  mdt.md == 1 ) nNumComputedExactly++;
		else if( mdt.md > maxK || mdt.n > maxMN || mdt.m > maxMN ) nNumSkipped++;
		else if( mdt.n <= maxK )  nNumComputedExactly++;
		else nNumApproximated++;
	    }
	}
    }

    fprintf(stderr, "\n");
    
    cout << "\n\t3SEQ DRYRUN";
    cout << "\n\t======================================================\n\t";
    cout << "\n\tNumber of sequences is\t\t\t\t " << N ;
    cout << "\n\tNumber of comparisons is\t\t\t " << G_N_NUM_TRIPLES;
    if( G_CLO_END_SEQ - G_CLO_BEG_SEQ == 1 )
    {
        cout << "\n\tQuerying sequence with index " << G_CLO_BEG_SEQ << ": \t\t " << pSeq[G_CLO_BEG_SEQ].accnum;
    }
    cout << "\n\n\tNumber of polymorphic sites is\t\t\t " << GLen;
    cout << "\n\tMax number of informative sites is\t\t " << maxInfSites;  
    cout << "\n\n\tNumber of megabytes or RAM+SWAP needed is\t " << nMegs << "mb" ;
    if( G_TRIPLES_OVERFLOW) cout << "\n\n\tNumber of triples tested\t\t\t " <<  G_D_NUM_TRIPLES;
    if(!G_TRIPLES_OVERFLOW) cout << "\n\n\tNumber of triples tested\t\t\t " <<  G_N_NUM_TRIPLES;
    cout << "\n\tNumber of p-values that can be computed exactly\t " << nNumComputedExactly;
    cout << "\n\tNumber of p-values that can be approximated\t " << nNumApproximated;
    cout << "\n\tNumber of p-values that cannot be computed\t " << nNumSkipped;

    cout << "\n\t\n\t======================================================\n\n";
}

void Bin(double p)
{
    int index = (int)(((double)-1)*log10( p ));
    if( index > 39 ) index=39;
    if( index < 0  ) index=0;
    G_PV[index] = G_PV[index] + 1;
}

void RecordSkippedTriplet( int p, int q, int c, MDTRIPLE mdt, seq* pSeq  )
{
    fprintf( GFileSkippedPValues, "%s\t%s\t%s\t%d\t%d\t%d\n", ((pSeq+p)->accnum).c_str(), ((pSeq+q)->accnum).c_str(), ((pSeq+c)->accnum).c_str(), mdt.m, mdt.n, mdt.md);
    return;
}

// will record exact p-value calculation to 3s.rec file (there is an overloaded version below)
void RecordRecombinantTriplet( int p, int q, int c, MDTRIPLE mdt, double pvalue, seq* pSeq, int hs  )
{
    if( G_CLO_NO_3SREC_FILE ) return;
    int len = (pSeq->ntfull).length();

    // remember to free these before returning from function
    int* pnRecLength = new int;
    *pnRecLength = -1;
    vector<BREAKPOINTRANGES>* pvBPR = NULL;

    // go into this loop either if we're doing *all* recombinants or *no* recombinants
    // if we're doing no recombinants, then just skip the breakpoint calculations
    if( G_CLO_BREAKPOINTS_FOR_ALL_RECOMBINANTS || G_CLO_NO_BREAKPOINTS )
    {
        //                                                       m   n   k    pvalue     -99      hs
        fprintf( GFileRecombinants, "%s-[%d]\t%s-[%d]\t%s-[%d]\t%d\t%d\t%d\t  %1.12f\t  %1.12f\t  %d\t  %2.4f\t  %1.5f\t  %e",
		 ((pSeq[p]).accnum).c_str(), p,
		 ((pSeq[q]).accnum).c_str(), q,
		 ((pSeq[c]).accnum).c_str(), c,
		 mdt.m, mdt.n, mdt.md, 
		 pvalue, -99.0, hs, log10(pvalue), 
		 DS( pvalue ), DS( pvalue )  );

        if( G_CLO_BREAKPOINTS_FOR_ALL_RECOMBINANTS )
        {
            pvBPR = GetBreakpoints( pSeq+p, pSeq+q, pSeq+c, mdt.md, pnRecLength );
            assert( pvBPR->size() != 0 );

            fprintf( GFileRecombinants, " \t %d", *pnRecLength );
            if( *pnRecLength > G_LONGEST_RECOMBINANT_SEGMENT ) G_LONGEST_RECOMBINANT_SEGMENT = *pnRecLength;
            //fprintf(stderr, "\n\n\t\t\t G_LONGEST_RECOMBINANT_SEGMENT variable being set to %d \n", G_LONGEST_RECOMBINANT_SEGMENT );

            vector<BREAKPOINTRANGES>::iterator it;
            for(int i=0; i< pvBPR->size(); i++)
            {
                BREAKPOINTRANGES bpr = (*pvBPR)[i];
                if( bpr.R1-bpr.L1>0 && bpr.R2-bpr.L2>0 ) fprintf( GFileRecombinants, "  \t  %d-%d,%d-%d", bpr.L1, bpr.R1, bpr.L2, bpr.R2 );
                else if( bpr.R1-bpr.L1==0 && bpr.R2-bpr.L2>0  ) fprintf( GFileRecombinants, "  \t  %d,%d-%d", bpr.L1, bpr.L2, bpr.R2 );
                else if( bpr.R1-bpr.L1>0  && bpr.R2-bpr.L2==0 ) fprintf( GFileRecombinants, "  \t  %d-%d,%d", bpr.L1, bpr.R1, bpr.L2 );
                else if( bpr.R1-bpr.L1==0 && bpr.R2-bpr.L2==0 ) fprintf( GFileRecombinants, "  \t  %d,%d", bpr.L1, bpr.L2 );
                else assert( false );
            }
        }
        fprintf( GFileRecombinants, "\n" ); fflush( GFileRecombinants );
    }

    (pSeq[c]).recombinant = true;
    if( *pnRecLength >= G_CLO_MIN_RECOMBINANT_LENGTH && G_CLO_BREAKPOINTS_FOR_ALL_RECOMBINANTS ) 
    {
        (pSeq[c]).recombinant_and_is_long = true;
    }
    
    // now check if this is the *best* recombinant (meaning lowest p-value) and if
    // it is record it in the seq class members
    if( pvalue < ((double) pSeq[c].best_pvalue) )
    {
        pSeq[c].best_pvalue = (float) pvalue;
        pSeq[c].best_parent1_index = p;	
        pSeq[c].best_parent2_index = q;
        pSeq[c].best_m             = mdt.m;
        pSeq[c].best_n             = mdt.n;
        pSeq[c].best_md            = mdt.md;
        pSeq[c].best_hs            = hs==0 ? false : true;
        pSeq[c].best_bounds.max    = 2.0;
        pSeq[c].best_bounds.min    = 2.0;
    }

    delete pnRecLength;
    if( pvBPR != NULL) delete pvBPR;
    return;
}

// overloaded version which will record approximate p-value to 3s.rec file
void RecordRecombinantTriplet( int p, int q, int c, MDTRIPLE mdt, BOUNDS bnds, seq* pSeq  )
{
    if( G_CLO_NO_3SREC_FILE ) return;
    int len = (pSeq->ntfull).length();

    // remember to free these before returning from function
    int* pnRecLength = new int;
    *pnRecLength = -1;
    vector<BREAKPOINTRANGES>* pvBPR = NULL;

    // go into this loop either if we're doing *all* recombinants or *no* recombinants
    // if we're doing no recombinants, then just skip the breakpoint calculations
    if( G_CLO_BREAKPOINTS_FOR_ALL_RECOMBINANTS || G_CLO_NO_BREAKPOINTS )
    {
        //                                                       m   n   k    p_min     p_max     hs=0
        fprintf( GFileRecombinants, "%s-[%d]\t%s-[%d]\t%s-[%d]\t%d\t%d\t%d\t  %1.12f\t  %1.12f\t  %d\t  %2.4f\t  %1.5f\t  %e",
		 ((pSeq[p]).accnum).c_str(), p,
		 ((pSeq[q]).accnum).c_str(), q,
		 ((pSeq[c]).accnum).c_str(), c,
		 mdt.m, mdt.n, mdt.md, 
		 bnds.min, bnds.max, 0, log10(bnds.max),
		 DS( bnds.max ), DS( bnds.max )  );

        if( G_CLO_BREAKPOINTS_FOR_ALL_RECOMBINANTS )
        {
            pvBPR = GetBreakpoints( pSeq+p, pSeq+q, pSeq+c, mdt.md, pnRecLength );
            assert( pvBPR->size() != 0 );

            fprintf( GFileRecombinants, " \t %d", *pnRecLength );
            if( *pnRecLength > G_LONGEST_RECOMBINANT_SEGMENT ) G_LONGEST_RECOMBINANT_SEGMENT = *pnRecLength;

            vector<BREAKPOINTRANGES>::iterator it;
            for(int i=0; i< pvBPR->size(); i++)
            {
                BREAKPOINTRANGES bpr = (*pvBPR)[i];
                if( bpr.R1-bpr.L1>0 && bpr.R2-bpr.L2>0 ) fprintf( GFileRecombinants, "  \t  %d-%d,%d-%d", bpr.L1, bpr.R1, bpr.L2, bpr.R2 );
                else if( bpr.R1-bpr.L1==0 && bpr.R2-bpr.L2>0  ) fprintf( GFileRecombinants, "  \t  %d,%d-%d", bpr.L1, bpr.L2, bpr.R2 );
                else if( bpr.R1-bpr.L1>0  && bpr.R2-bpr.L2==0 ) fprintf( GFileRecombinants, "  \t  %d-%d,%d", bpr.L1, bpr.R1, bpr.L2 );
                else if( bpr.R1-bpr.L1==0 && bpr.R2-bpr.L2==0 ) fprintf( GFileRecombinants, "  \t  %d,%d", bpr.L1, bpr.L2 );
                else assert( false );
            }
        }
        fprintf( GFileRecombinants, "\n" ); fflush( GFileRecombinants );
    }

    (pSeq[c]).recombinant = true;
    if( *pnRecLength >= G_CLO_MIN_RECOMBINANT_LENGTH && G_CLO_BREAKPOINTS_FOR_ALL_RECOMBINANTS ) 
    {
        (pSeq[c]).recombinant_and_is_long = true;
    }

    // now check if this is the *best* recombinant (meaning lowest p-value) and if
    // it is record it in the seq class members
    if( bnds.max < pSeq[c].best_pvalue )
    {
        pSeq[c].best_pvalue        = bnds.max;
        pSeq[c].best_parent1_index = p;	
        pSeq[c].best_parent2_index = q;
        pSeq[c].best_m             = mdt.m;
        pSeq[c].best_n             = mdt.n;
        pSeq[c].best_md            = mdt.md;
        pSeq[c].best_hs            = false;
        pSeq[c].best_bounds.max    = bnds.max;
        pSeq[c].best_bounds.min    = bnds.min;
    }

    delete pnRecLength;
    if( pvBPR != NULL) delete pvBPR;
    return;
}
//

void SendPValDistributionToOutfile( int* pn, int N )
{
    int i;
    double dNumComparisons = (double)(N*(N-1)*(N-2));
    
    FILE* outHist = fopen(G_FILENAME_PVALUEHISTOGRAM.c_str(), "w");  

    for(i=0; i<40; i++)
    {
        fprintf( outHist, "%d\t%d\t%1.7f\t%1.3f\n", i, pn[i], ((double)pn[i])/dNumComparisons, log10(((double)pn[i])/dNumComparisons) );
    }
    
    fclose( outHist );
}
//

bool ACGT( char c )
{
    if( c=='A' || c=='C' || c=='G' || c=='T' ) return true;
    return false;
}


double DS( double pval )
{
    double dOne = (double)1;
    double dM;  // number of comparisons
    if( pval >= dOne ) return dOne;
    
    if( G_TRIPLES_OVERFLOW )
    {
        dM = G_CLO_USE_ALL_TRIPLES ? G_D_ALL_TRIPLES : G_D_NUM_TRIPLES;
    }
    else
    {
        dM = (double) (G_CLO_USE_ALL_TRIPLES ? G_N_ALL_TRIPLES : G_N_NUM_TRIPLES);
    }

    if( pval < 1e-15 )
    {
        // simply return the bonferroni correction
        // you need to do this bc if the pvalue is less than 1e-15, then 1 - 1e-15
        // rounds off to one and you cannot do a Dunn-Sidak Correction
        return pval*dM;
    }
    else
    {
        return dOne - pow( dOne-pval, dM );
    }
}
//


int GetMaxInformativeSites( seq* pSeq, int N )
{
    // indices for 3 loops
    int nC, nP1, nP2;
    int maxInfSites=0; // maximum number of informative sites
    int nLastPercentDone = 0;
    double dnt = G_TRIPLES_OVERFLOW ? G_D_NUM_TRIPLES : ((double)G_N_NUM_TRIPLES);
    double dat = G_TRIPLES_OVERFLOW ? G_D_ALL_TRIPLES : ((double)G_N_ALL_TRIPLES);

    // first loop through each child
    for( nC=G_CLO_BEG_SEQ; nC < G_CLO_END_SEQ; nC++ )
    {
	// now select the first candidate parent
	for( nP1=0; nP1 < N-1; nP1++ )
	{
	    //BEGIN PROGRESS COUNTER
	    int nPercentDone = (int)(((double)100000)*(  ((double)(nP1))*((double)(N-2)) + ((double)(nC-G_CLO_BEG_SEQ))*((double)(N-1))*((double)(N-2)) )/dnt);
	    if( !G_CLO_PYTHON && nPercentDone > nLastPercentDone )
	    {
	        nLastPercentDone = nPercentDone;
	        //now = time(NULL);
	        //int timer=now-start_time;
	        fprintf(stderr, "\tMAX-INF-SITES Progress --  %3.3f%% \r", (double)nPercentDone/((double)1000) ); 
		fflush(stderr);
	    } 
	    //END PROGRESS COUNTER
	
	    if(nP1==nC) continue;
	    for( nP2=nP1+1; nP2 < N; nP2++ )
	    {
		if(nP2==nC) continue;
		
		MDTRIPLE mdt = Calculate_Maximum_Descent( pSeq+nP1, pSeq+nP2, pSeq+nC );
		
		if( mdt.m > maxInfSites ) maxInfSites=mdt.m;
		if( mdt.n > maxInfSites ) maxInfSites=mdt.n;
	    }
	}
    }
    
    return maxInfSites;
}

unsigned int GetNumTriplesCalculated( seq* pSeq, int N, int maxMN, int maxK )
{
    assert( maxK <= maxMN );
    
    // indices for 3 loops
    int nC, nP1, nP2;
    
    // counts of how many p-values can be computed exactly, approximated, skipped
    unsigned int nNumComputedExactly=0;
    
    // first loop through each child
    for( nC=0; nC < N; nC++ )
    {
	// now select the first candidate parent
	for( nP1=0; nP1 < N; nP1++ )
	{
	    if(nP1==nC) continue;
	    for( nP2=0; nP2 < N; nP2++ )
	    {
		if(nP2==nC || nP2==nP1 ) continue;
		
		MDTRIPLE mdt = Calculate_Maximum_Descent( pSeq+nP1, pSeq+nP2, pSeq+nC );
		
		if( (mdt.n - mdt.m) == mdt.md ) nNumComputedExactly++;
		else if( mdt.n != 0 &&  mdt.md == 1 ) nNumComputedExactly++;
		else if( mdt.n <= maxK )  nNumComputedExactly++;
	    }
	}
    }
    
    return nNumComputedExactly;
}


int GetMegsNeeded( int maxMN, int maxK )
{
    double dMN = (double) maxMN;
    double dK = (double) maxK;
    double f = (int) sizeof( float );
    
    return 1 + (int)((f*dMN*dMN*dK*dK)/((double)1048576));
}

/********************************
**
** Full running of algorithm which attempts to compute all triples
** and rebuilds the y-table as necessary in this pursuit
**
** There are two main loops in this run
**    (1) loop which builds the largest possible table for exact computations 
**        and tries to compute all triplets via this table
**    (2) loop which goes through the remaining uncomputed triplets and tries to build
**        a custom table for each one
**
*******************************/
double DoFullRun( seq* pSeq, int N, double th, int memAllot, bool show, bool bYesNoMode )
{
    //if( !bYesNoMode ) cout << "\n\n\tbYesNoMode is false\n\n";
    
    if(show)
    {
        //cout << "\n\t3SEQ FULL RUN";
        //cout << "\n\t======================================================";
    }

    // these two integers will give the table size for the first pass of the algorithm
    // the table will have size nTableSizeMN * nTableSizeMN * nTableSizeK * nTableSizeK
    int nTableSizeMN, nTableSizeK;

    bool bDone = false; // whether we are done looking for optimal memory parameters
    
    // first count the number of segregating sites and see if you can build your table based 
    // on the number of segregating sites
    //
    // the reason you want to do this is that counting the number of segregating sites only 
    // takes N^2 loops (not N^3) and it may be quicker for large data sets
    //
    double* pdStats = StrainStats( pSeq, N );            
    int nMaxDist = (int) pdStats[3];
    delete[] pdStats;
    int nMegs = GetMegsNeeded( nMaxDist, nMaxDist );
    if(show) cout << "\n\ttrying  maxMN=" << nMaxDist << "\tmaxK=" << nMaxDist << "\trequires " << nMegs << " mb of RAM.";
    fflush(stdout);
    if( nMegs < memAllot )
    {
        nTableSizeMN = nMaxDist;
	nTableSizeK = nMaxDist;
	bDone = true;
    }
        
    int maxInfSites=-1;
    
    // only go in here if you must since the function call "GetMaxInformativeSites" runs in N^3 iterations
    if( !bDone )
    {
        if(show) {cout << "\n\n\tNot enough memory for strategy above.  Computing max number of informative sites.\n\n";  fflush( stdout );}
        maxInfSites = GetMaxInformativeSites( pSeq, N );
        nMegs = GetMegsNeeded( maxInfSites, maxInfSites );
        if(show) cout << "\n\n\ttrying  maxMN=" << maxInfSites << "\tmaxK=" << maxInfSites << "\trequires " << nMegs << " mb of RAM.";
	fflush(stdout);
        if( nMegs < memAllot )
        {
            nTableSizeMN = maxInfSites;
	    nTableSizeK  = maxInfSites;
	    bDone = true;
	}
    }
         
    // if using the total number of segregating sites or the maximum number of informative sites
    // requires too much memory, then we simply have to look at the allotted memory and choose
    // nTableSizeMN = nTableSizeK such that the total table size fits into the allotted memory.
    // This is the optimal way of calculating as many EXACT p-value calculations as possible 
    if( !bDone )
    {
        nTableSizeK = (int) pow( ( ((double)1048576)*((double)memAllot) )/(4.0), 0.25 );
        nTableSizeMN = nTableSizeK;
        assert( nTableSizeK >= 0 );
	nMegs = GetMegsNeeded( nTableSizeMN, nTableSizeK );
	if(show) cout << "\n\n\ttrying  maxMN=" << nTableSizeMN << "\tmaxK=" << nTableSizeK << " \trequires " << nMegs << " mb of RAM."; fflush(stdout);
	bDone = true;
    }

    if(show) cout << "\n\n"; fflush(stdout);
    
    // Here begin computing p-values for the triples in the data set
    // you must declare these variables EXACTLY ONCE so that the constructor for each class is called
    // then, you want to adjust M and K below so that you can analyze many types of HGRWs, with many types
    // of maximum descents
    //
    ytable y( nTableSizeMN+1, nTableSizeMN+1, nTableSizeK+1, nTableSizeK+1 );

    int nC, nP1, nP2;   
    double dGlobalPValMin = ((double)1);
    int nLastPercentDone = 0;

    // keeps track of how many triples were computed exactly and how many were approximated
    unsigned int nNumExact=0;
    unsigned int nNumBounded=0;
    unsigned int nNumApproxHS=0;
    double dnt = G_TRIPLES_OVERFLOW ? G_D_NUM_TRIPLES : ((double)G_N_NUM_TRIPLES);
    
    //
    //
    // --- F I R S T  L O O P ---
    //
    //
    // loop through each child
    for( nC = G_CLO_BEG_SEQ; nC < G_CLO_END_SEQ; nC++ )
    {
        //fprintf( OutFile, "\n%3.1f%% done", dPercentDone );
	
	// now select the first candidate parent
	for( nP1=0; nP1 < N; nP1++ )
	{
	    //cout << "\n\tlooping -- nC= " << nC << " nP1=" << nP1;
	    if(nP1==nC) continue;

	    //BEGIN PROGRESS COUNTER
	    if( show )
	    {
	        int nPercentDone = (int)(((double)100000)*(  ((double)(nP1))*((double)(N-2)) + ((double)(nC-G_CLO_BEG_SEQ))*((double)(N-1))*((double)(N-2)) )/dnt);
	        if( nPercentDone > nLastPercentDone )
	        {
		    nLastPercentDone = nPercentDone;
		    fprintf(stderr, "\tFULL RUN.  FIRST PHASE.  Progress --  %3.3f%% \t\t(%d, %d)    \r", (double)nPercentDone/((double)1000), UnfinishedTriples.size(), ImpossibleTriples.size() ); 
		    fflush(stderr);
	        }
	    }
	    //END PROGRESS COUNTER
	    
	    for( nP2=0; nP2 < N; nP2++ )
	    {
		if(nP2==nC || nP2==nP1 ) continue;
		//nCount++;
		//cout << "\n\tlooping " << nP1 << " " << nP2 << " " << nC;
		MDTRIPLE mdt = Calculate_Maximum_Descent( pSeq+nP1, pSeq+nP2, pSeq+nC );
		//cout << "\n\tmax descent triple (m,n,k) is (" << mdt.m << ", " << mdt.n << ", " << mdt.md << ")";
		
		if( y.can_compute_exact_pvalue(mdt.m, mdt.n, mdt.md) )
		{
		    double dPValue = y.compute_exact_pvalue(mdt.m, mdt.n, mdt.md);
		    Bin( dPValue );
		    nNumExact++;
		    if( dPValue < dGlobalPValMin ) dGlobalPValMin = dPValue;
		    double dPValueCorr = DS(dPValue);
		    if( dPValueCorr < th ) 
		    {
	                RecordRecombinantTriplet( nP1, nP2, nC, mdt, dPValue, pSeq );
			if( bYesNoMode )
			{
				int num_not_calculated;
				if(!G_TRIPLES_OVERFLOW) num_not_calculated = N*(N-1)*(N-2) - nNumExact - nNumBounded - nNumApproxHS;
				else num_not_calculated = -1;
				if( show) DisplayResults( nNumExact, nNumBounded, nNumApproxHS, num_not_calculated, dGlobalPValMin, pSeq, N );
				if(!show) OutputFormattedForPython( nNumExact, nNumBounded, nNumApproxHS,   0    ,  dGlobalPValMin, pSeq, N,    -99    );
				return dPValueCorr;
			}
	            }
		}
		// in this case, we will always be out of the array bounds for all table
		// sizes within memAllot; we cannot even approximate in this case
		else if( 4.0*((double)mdt.m)*((double)mdt.n)*((double)mdt.md)*((double)mdt.md) > ((double)1048576)*((double)memAllot)  )
		{
      	            //if(show) printf("\n\tmd-triple %d %d %d is out of scope given %d mb memory allotment", mdt.m, mdt.n, mdt.md, memAllot );
		    mdt.p = nP1; mdt.q = nP2; mdt.c = nC;
	            ImpossibleTriples.push_back( mdt );
		    if( G_CLO_RECORD_SKIPPED_TRIPLES ) RecordSkippedTriplet( nP1, nP2, nC, mdt, pSeq );
		}
		// in this case, we are going to see if we can bound it in such a way
		// that the upper bound is only 10% more than the lower bound
		else 
		{
		    bool bApproximated = false;
		    
		    // try to approximate now (with bounds); if approximation is good enough, keep it.
		    if( y.can_approximate_pvalue(mdt.m, mdt.n, mdt.md) )
		    {
	                BOUNDS bnds = y.approximate_pvalue(mdt.m, mdt.n, mdt.md); 
	                if( (bnds.max/bnds.min) < 1.10  )
			{
			    bApproximated = true;
			    //if(show) printf("\n\t\tapproximated: md-triple %d %d %d has p-value bounds \t%1.6f \t%1.6f", mdt.m, mdt.n, mdt.md, bnds.min, bnds.max );
			    Bin( bnds.max );
			    nNumBounded++;
			    double dPValueCorr = DS(bnds.max);
			    if( bnds.max < dGlobalPValMin ) dGlobalPValMin = bnds.max;    
			    if( dPValueCorr < th ) 
			    {
				RecordRecombinantTriplet( nP1, nP2, nC, mdt, bnds, pSeq );
				if( bYesNoMode )
				{
					int num_not_calculated;
					if(!G_TRIPLES_OVERFLOW) num_not_calculated = N*(N-1)*(N-2) - nNumExact - nNumBounded - nNumApproxHS;
					else num_not_calculated = -1;
					if( show) DisplayResults( nNumExact, nNumBounded, nNumApproxHS, num_not_calculated, dGlobalPValMin, pSeq, N );
					if(!show) OutputFormattedForPython( nNumExact, nNumBounded, nNumApproxHS,   0    ,  dGlobalPValMin, pSeq, N,    -99    );
					return dPValueCorr;
				}
			    }
			}
		    }
		    
		    if( !bApproximated )
		    {
		        mdt.p = nP1; mdt.q = nP2; mdt.c = nC;
		        if( 4.0*((double)mdt.m)*((double)mdt.n)*((double)mdt.n)*((double)mdt.n) < ((double)1048576)*((double)memAllot)  )
		        {
		            // means we can compute it exactly
			    mdt.must_approximate = false;
		        }
		        else
		        {
		            // must approximate, either with bounding or HS-method
			    mdt.must_approximate = true;
		        }
		        UnfinishedTriples.push_back( mdt );
		    }
		}
	    }
	}
    }
    //
    //
    // --- E N D  F I R S T  L O O P ---
    //
    //

    if( show )
    {
        /*if(G_TRIPLES_OVERFLOW) cout << "\n\n\t" << ImpossibleTriples.size() << " triples out of " << G_D_NUM_TRIPLES << " will be approximated with Hogan-Siegmund method";
        else cout << "\n\n\t" << ImpossibleTriples.size() << " triples out of " << G_N_NUM_TRIPLES << " will be approximated with Hogan-Siegmund method";*/
        
        fprintf(stderr, "\n\n\tFULL RUN.  SECOND PHASE.");
        
	if(G_TRIPLES_OVERFLOW) cout << "\n\n\t" << UnfinishedTriples.size() << " triples out of " << G_D_NUM_TRIPLES << " still need to be computed\n";
	else cout << "\n\n\t" << UnfinishedTriples.size() << " triples out of " << G_N_NUM_TRIPLES << " still need to be computed";
    }

    //
    //
    // --- S E C O N D  L O O P ---
    //
    //
    int nc=1; // number computations made in last loop
    while( UnfinishedTriples.size() != 0 && nc > 0 )
    {        
        nc = 0; // this is the number you compute per loop

        // now, try to recalculate some of the unfinished p-values
        //
        // get the m- and n- values from the first unfinished triple in the vector,
        // set up a new table based on this m and n and see how many triples you can 
        // compute or approximate
        vector<MDTRIPLE>::iterator iter = UnfinishedTriples.begin();
        int n, k;
	int m = (*iter).m;
	if( !( (*iter).must_approximate ) )
        {
	    n = (int) pow( ((double)1048576)*((double)memAllot)/(4.0 * ((double)m) ), 0.3333333 );
	    if(n<0) n=0;
	    k=n;
	}
	if( (*iter).must_approximate )
	{
	    //if(show) cout << "\n\twill build ytable for approximation";
	    n = (*iter).n;
	    k = (int) ( ((double)512)*sqrt( ((double)memAllot)/(((double)m)*((double)n)) ) );
	    if(k<0) k=0;
	}
	
        if(show) cout << "\n\t\tNew m, n, k for re-allocated table will be m=" << m << " n=" << n << " k=" << k;
        if(show) cout << "\n\t\tThis is being constructed for triple " << m << " " << (*iter).n << " " << (*iter).md;
        y.reallocate_space(m+1,n+1,k+1,k+1);
    
        iter = UnfinishedTriples.begin();
        while( iter < UnfinishedTriples.end() )
        {
            MDTRIPLE mdt = *iter;
	    if( y.can_compute_exact_pvalue(mdt.m, mdt.n, mdt.md) )
	    {
	        double dPValue = y.compute_exact_pvalue( mdt.m, mdt.n, mdt.md );
		Bin( dPValue );
		nNumExact++;
	        if( dPValue < dGlobalPValMin ) dGlobalPValMin = dPValue;
		double dPValueCorr = DS(dPValue);
		if( dPValueCorr < th ) 
		{
		    RecordRecombinantTriplet( mdt.p, mdt.q, mdt.c, mdt, dPValue, pSeq );
		    if(bYesNoMode)
		    {
			int num_not_calculated;
			if(!G_TRIPLES_OVERFLOW) num_not_calculated = N*(N-1)*(N-2) - nNumExact - nNumBounded - nNumApproxHS;
			else num_not_calculated = -1;
			if( show) DisplayResults( nNumExact, nNumBounded, nNumApproxHS, num_not_calculated, dGlobalPValMin, pSeq, N );
		        if(!show) OutputFormattedForPython( nNumExact, nNumBounded, nNumApproxHS,   0    ,  dGlobalPValMin, pSeq, N,    -99    );
		        return dPValueCorr;
		    }
		}
	        //printf("\n\t%d %d %d has p-value %1.8f", mdt.m, mdt.n, mdt.md, dPValue);
	    
	        // after you erase, the iterator increments automatically
	        UnfinishedTriples.erase(iter);
		nc++;
	    }
	    else if( y.can_approximate_pvalue(mdt.m, mdt.n, mdt.md) )
	    {
	        BOUNDS bnds = y.approximate_pvalue(mdt.m, mdt.n, mdt.md);
	    
	        // if the p-value bounds are within 10% of each other, accept them;
		// or, if this is the first triple in the vector and the bounds are
		// within 100% of each other, accept the approximation since it is 
		// good enoughand probably better than a Hogan-Siegmund approximation
	        if( (bnds.max/bnds.min) < 1.10 || (iter==UnfinishedTriples.begin() && (bnds.max/bnds.min) < 2.0) )
	        {
	            if( bnds.max < dGlobalPValMin ) dGlobalPValMin = bnds.max;
		    //if(show) printf("\n\t\tapproximated: md-triple %d %d %d has p-value bounds \t%1.6f \t%1.6f", mdt.m, mdt.n, mdt.md, bnds.min, bnds.max );
		    Bin( bnds.max );
		    nNumBounded++;
		    double dPValueCorr = DS(bnds.max);
		    //if( bnds.max < 0.5 ) fprintf( OutFile, "%1.12f\n", bnds.max );
		    if( dPValueCorr < th ) 
		    {
			RecordRecombinantTriplet( mdt.p, mdt.q, mdt.c, mdt, bnds, pSeq );
			if( bYesNoMode )
			{
				int num_not_calculated;
				if(!G_TRIPLES_OVERFLOW) num_not_calculated = N*(N-1)*(N-2) - nNumExact - nNumBounded - nNumApproxHS;
				else num_not_calculated = -1;
				if( show) DisplayResults( nNumExact, nNumBounded, nNumApproxHS, num_not_calculated, dGlobalPValMin, pSeq, N );
				if(!show) OutputFormattedForPython( nNumExact, nNumBounded, nNumApproxHS,   0    ,  dGlobalPValMin, pSeq, N,    -99    );
				return dPValueCorr;
			}
		    }
		    
		    // after you erase, the iterator increments automatically
	            UnfinishedTriples.erase( iter );
		    nc++;
	        }
	        else
	        {
	            // you need to push it back into the impossible triples vector (and erase it
	            // from the unfinished triples vector) so that it can be approximated with
	            // the Hogan-Siegmund method
	            MDTRIPLE mdt2 = *iter;
	            ImpossibleTriples.push_back( mdt2 );
                    //printf("\n\t\t---moving from unfinished to impossible: md-triple %d %d %d has p-value bounds \t%1.4e \t%1.4e", mdt.m, mdt.n, mdt.md, bnds.min, bnds.max );

	            // after you erase, the iterator increments automatically
	            UnfinishedTriples.erase( iter );
	            nc++;
	        }
            }
	    else
	    {	    
	        // need to iterate to next element in vector if you do not call vector.erase()
	        iter++;
	    }
        }
        if(show) 
	{
	    if( G_TRIPLES_OVERFLOW) cout << "\n\n\t" << UnfinishedTriples.size() << " triples out of " << G_D_NUM_TRIPLES << " still need to be computed";
    	    if(!G_TRIPLES_OVERFLOW) cout << "\n\n\t" << UnfinishedTriples.size() << " triples out of " << G_N_NUM_TRIPLES << " still need to be computed";
	    fflush(stdout);
	}
	//fprintf(stderr, "\n\t\t\t%11.0d triples left", UnfinishedTriples.size() ); fflush(stderr);
    } 
    //
    //
    // --- E N D  S E C O N D  L O O P ---
    //
    //

    //
    //
    // --- T H I R D  L O O P --- (do everything here with Hogan-Siegmund approximation)
    //
    //

    if(show) fprintf(stderr, "\n\n\tFULL RUN.  THIRD PHASE.\n\t(using hogan-siegmund approximation for remaining %d triples).\n\n", ImpossibleTriples.size() ); fflush(stderr);
    vector<MDTRIPLE>::iterator iter = ImpossibleTriples.begin();
    nNumApproxHS = 0;
    int ii = 1;
    while( iter != ImpossibleTriples.end() )
    {
        if(show) fprintf(stderr, "\t\t\t%d of %d \r", ii++, nNumApproxHS ); fflush(stderr);
        MDTRIPLE mdt = *iter;
        double pvalue = approx::siegmund_discrete( mdt.m, mdt.n, mdt.md );
        nNumApproxHS++;
        double dPValueCorr = DS(pvalue); 
        Bin( pvalue );
        if( pvalue < dGlobalPValMin ) dGlobalPValMin = pvalue;
        if( dPValueCorr < G_CLO_THRESHOLD ) 
        {
            RecordRecombinantTriplet( mdt.p, mdt.q, mdt.c, mdt, pvalue, pSeq, HOGANSIEGMUND );
	    if(bYesNoMode)
	    {
		int num_not_calculated;
		if(!G_TRIPLES_OVERFLOW) num_not_calculated = N*(N-1)*(N-2) - nNumExact - nNumBounded - nNumApproxHS;
		else num_not_calculated = -1;
		if( show) DisplayResults( nNumExact, nNumBounded, nNumApproxHS, num_not_calculated, dGlobalPValMin, pSeq, N );
		if(!show) OutputFormattedForPython( nNumExact, nNumBounded, nNumApproxHS,   0    ,  dGlobalPValMin, pSeq, N,    -99    );
	        return dPValueCorr;
	    }
        }
        ImpossibleTriples.erase( iter );
    } 
    //
    //
    // --- E N D  T H I R D  L O O P ---
    //
    //
 
    //fprintf(stderr, "\n\n\n" ); fflush(stderr);
    
    assert( UnfinishedTriples.size() == 0 );
    unsigned int nNumNotCalculated = 0;
    if( !G_CLO_BREAKPOINTS_FOR_ALL_RECOMBINANTS && !G_CLO_NO_BREAKPOINTS ) CalculateBestBreakpoints( pSeq, N );
    if(show) DisplayResults( nNumExact, nNumBounded, nNumApproxHS, nNumNotCalculated, dGlobalPValMin, pSeq, N );
    //                                                                       num skipped                           num_rec_triplets 
    if(!show) OutputFormattedForPython( nNumExact, nNumBounded, nNumApproxHS,   0    ,  dGlobalPValMin, pSeq, N,    -99    );

    float p = DS( dGlobalPValMin ); 
    return p;
}
// END DoFullRun(..)

/********************************
**
** Running of algorithm using pre-computed p-values stored in a file
** which starts with the 12 characters 'PVT_COMPACT_'.   The file name
** is supposed to be something like 'PVT_COMPACT_120' indicating that
** it has all the p-values up to and including m=120, n=120, k=120
**
** As of 05-May-2007, this version of the function does not compute all triples
** Noted 06-Dec-2008, this version does compute all triples if -hs options is choen
**
** 3SEQ will look for the file PVT_COMPACT_NNN in the directory stored in the 
** global variable G_PVALUETABLE_DIRECTORY which is defined in the ProbTables.cpp file
**
*******************************/
void DoXRun( seq* pSeq, int N )
{
    if( G_CLO_PYTHON ) pvaluetable_compact::quiet=true;

    // when this variable is declared, the constructor of the class
    // pvaluetable_compact is called, and it finds the "PVT_COMPACT_" file 
    // on disk and reads it into memory.  This takes some time.
    pvaluetable_compact pvt;

    bool bValid = pvt.validate();

    if( !bValid )
    {
        cout << "\n\t**\n\t**  ERROR: The file PVT_COMPACT_XYZ was not read in correctly.  This occurs sometimes \n\t**  when the sequence file and the p-value table file are on different filesystems,   \n\t**  for example, if these files are on different Linux partitions (one ext3, the other ext4) \n\t**  or if you are running 3seq inside a virtual machine, but the p-value table is located \n\t**  in the other operating system's filesystem.\n\t**\n\t**  To be safe, make sure the p-value table and sequence file are on the same filesystem\n\t**  and that 3seq is also compiled on this filesystem.  \n\t**\n\n";
 
	return;
    }
    
    if( pvaluetable_compact::size == -1 ) return;

    // indices for 3 loops
    int nC, nP1, nP2;
    unsigned int nCount = 0;
    unsigned int nNumRecombinantTriplets = 0;

    // counts of how may p-values were computed exactly, approximated, skipped
    unsigned int nNumComputedExactly=0;
    unsigned int nNumBounded=0;
    unsigned int nNumApproximatedHS=0;	// number approximated with Hogan-Siegmund method
    unsigned int nNumSkipped=0;

    double dGlobalPValMin = ((float)1);
    int nLastPercentDone = 0;
    bool bStopLooping=false;
    double dnt = G_TRIPLES_OVERFLOW ? G_D_NUM_TRIPLES : ((double)G_N_NUM_TRIPLES);
    double dat = G_TRIPLES_OVERFLOW ? G_D_ALL_TRIPLES : ((double)G_N_ALL_TRIPLES);
    double dNumForCorrection = G_CLO_USE_ALL_TRIPLES ? dat : dnt;
    
    if( !G_CLO_PYTHON ) fprintf(stderr, "\n\tNeed a p-value of %e to survive multiple comparisons correction\n\n", G_CLO_THRESHOLD / dNumForCorrection );
    
    if( !G_CLO_PYTHON ) fprintf(stderr, "\t                           \t\t min p-value, so far \t  time elapsed \t    #.put.rec.trip. \t  min.rec.len. \n");
    time_t start_time, now;
    start_time = time(NULL);

    // first loop through each child
    for( nC = G_CLO_BEG_SEQ; nC < G_CLO_END_SEQ; nC++ )
    {
        if( bStopLooping ) break;

	for( nP1=0; nP1 < N; nP1++ )
	{
	    if(nP1==nC) continue;
	    if( bStopLooping ) break;
 
	    //BEGIN PROGRESS COUNTER
	    int nPercentDone = (int)(((double)100000)*(  ((double)(nP1))*((double)(N-2)) + ((double)(nC-G_CLO_BEG_SEQ))*((double)(N-1))*((double)(N-2)) )/dnt);
        if(floor(nPercentDone/100) > floor(nLastPercentDone/100))
        {
            if(!G_CLO_PYTHON)
            {
                nLastPercentDone = nPercentDone;
                now = time(NULL);
                int timer=now-start_time;
                if(G_CLO_BREAKPOINTS_FOR_ALL_RECOMBINANTS)
                {
                    fprintf(stderr, "\tX-RUN Progress --  %3.3f%% \t\t %e    \t  %03d:%02d:%02d \t    %9d \t\t      %d\r", (double)nPercentDone/((double)1000), dGlobalPValMin, timer/3600, (timer/60)%60, timer%60, nNumRecombinantTriplets, G_LONGEST_RECOMBINANT_SEGMENT );
                }
                else
                {
                    fprintf(stderr, "\tX-RUN Progress --  %3.3f%% \t\t %e    \t  %03d:%02d:%02d \t    %9d \t\t       ?? \r", (double)nPercentDone/((double)1000), dGlobalPValMin, timer/3600, (timer/60)%60, timer%60, nNumRecombinantTriplets );
                }
                fflush(stderr);
            }
        }
	    //END PROGRESS COUNTER
	    
	    for( nP2=0; nP2 < N; nP2++ )
	    {
		if(nP2==nC || nP2==nP1 ) continue;
		nCount++;
		MDTRIPLE mdt = Calculate_Maximum_Descent( pSeq+nP1, pSeq+nP2, pSeq+nC );
		
		if( pvt.can_get_pvalue( mdt.m, mdt.n, mdt.md ) )
		{
		    double pvalue = pvt.get_pvalue( mdt.m, mdt.n, mdt.md );
		    nNumComputedExactly++;
		    Bin( pvalue );
		    if( pvalue < dGlobalPValMin ) dGlobalPValMin = pvalue;
		    //if( DS(pvalue) < G_CLO_THRESHOLD || pvalue < .0003 ) 
		    if( DS(pvalue) < G_CLO_THRESHOLD )
		    {
		        nNumRecombinantTriplets++;
		        RecordRecombinantTriplet( nP1, nP2, nC, mdt, pvalue, pSeq  );
		        if( G_CLO_YESNO ) 
		        {
		            bStopLooping = true;
		            break;
		        }
		    }

		}
		else // we are out of array bounds in pvalue-table
		{
		    if( G_CLO_USE_SIEGMUND_APPROX )
		    {
		        double pvalue = approx::siegmund_discrete( mdt.m, mdt.n, mdt.md );
		        nNumApproximatedHS++;
		        Bin( pvalue );
		        if( pvalue < dGlobalPValMin ) dGlobalPValMin = pvalue;
		        if( DS(pvalue) < G_CLO_THRESHOLD ) 
		        {
		            nNumRecombinantTriplets++;
		            RecordRecombinantTriplet( nP1, nP2, nC, mdt, pvalue, pSeq, HOGANSIEGMUND );
		            if( G_CLO_YESNO ) 
		            {
		                bStopLooping = true;
		                break;
		            }
		        }
		    }
		    else
		    {
		        nNumSkipped++;
		        if( G_CLO_RECORD_SKIPPED_TRIPLES ) RecordSkippedTriplet( nP1, nP2, nC, mdt, pSeq  );
		    }
		}
	    }
	}
    }
    
    if( bStopLooping )
    {
	if(!G_TRIPLES_OVERFLOW) nNumSkipped = N*(N-1)*(N-2) - nNumComputedExactly - nNumBounded - nNumApproximatedHS;
	else nNumSkipped = -1;
    }

    if( !G_CLO_BREAKPOINTS_FOR_ALL_RECOMBINANTS && !G_CLO_NO_BREAKPOINTS ) CalculateBestBreakpoints( pSeq, N );
    
    if( !G_CLO_PYTHON ) DisplayResults( nNumComputedExactly, nNumBounded, nNumApproximatedHS, nNumSkipped, dGlobalPValMin, pSeq, N, nNumRecombinantTriplets );
    if(  G_CLO_PYTHON ) OutputFormattedForPython( nNumComputedExactly, nNumBounded, nNumApproximatedHS, nNumSkipped, dGlobalPValMin, pSeq, N, nNumRecombinantTriplets );
    
    if( !G_CLO_PYTHON ) cerr << "\n\n\tFreeing memory.  Please wait  .  .  .  \n\n"; fflush(stderr);
    return ;
}


// returns p-value
double SingleBreakpointRun( seq* pSeq, int N, double th, int memAllot, bool bYesNoMode )
{
    int nC, nP1, nP2; 
    unsigned int nCount=0;
    double dGlobalPValMin = ((double)1);
    int nLastPercentDone = 0;
    double dnt = G_TRIPLES_OVERFLOW ? G_D_NUM_TRIPLES : ((double)G_N_NUM_TRIPLES);
    double dat = G_TRIPLES_OVERFLOW ? G_D_ALL_TRIPLES : ((double)G_N_ALL_TRIPLES);
    double dNumForCorrection = G_CLO_USE_ALL_TRIPLES ? dat : dnt;
    
    fprintf(stderr, "\n\tNeed a p-value of %e to survive multiple comparisons correction\n\n", G_CLO_THRESHOLD / dNumForCorrection );

    //
    // --- M A I N  L O O P ---
    //
    // first loop through each child
    for( nC=0; nC < N; nC++ )
    {
	for( nP1=0; nP1 < N; nP1++ )
	{
	    if(nP1==nC) continue;
	    
	    //BEGIN PROGRESS COUNTER
	    int nPercentDone = (int)(((double)100000)*(  ((double)(nP1))*((double)(N-2)) + ((double)(nC-G_CLO_BEG_SEQ))*((double)(N-1))*((double)(N-2)) )/dnt);
	    if( nPercentDone > nLastPercentDone )
	    {
	        nLastPercentDone = nPercentDone;
	        fprintf(stderr, "\tSINGLE-BP-RUN Progress --  %3.3f%% \t\t(%e)    \r", (double)nPercentDone/((double)1000), dGlobalPValMin); 
		fflush(stderr);
	    } 
	    //END PROGRESS COUNTER

	    for( nP2=0; nP2 < N; nP2++ )
	    {
		if(nP2==nC || nP2==nP1 ) continue;
		nCount++;
		
		// note that we will store the max height inside the 'md' field of MDTRIPLE
		MDTRIPLE mdt = Calculate_Maximum_Height( pSeq+nP1, pSeq+nP2, pSeq+nC );
		
		double dPVal = PValMaxHeight_1( mdt.m, mdt.n, mdt.md );
		if( dPVal < dGlobalPValMin ) 
		{
		    dGlobalPValMin = dPVal;
		    double d = DS( dGlobalPValMin );
		    //cout << "\n\t" << d << "\t\t" << dGlobalPValMin << "\t\t" << th << "\t" << (int)bYesNoMode;
		    if( bYesNoMode && d < th )
	 	    {
		        DisplayResults( nCount, 0, 0, 0, dGlobalPValMin, pSeq, N );
		        cout << "\n\n";
		        return d;
		    }
		}
	    }
	}
    }
    //
    // --- E N D  M A I N  L O O P ---
    //
  
    DisplayResults( nCount, 0, 0, 0, dGlobalPValMin, pSeq, N );

    cout << "\n\n";

    return DS( dGlobalPValMin );
}
//


void DoMatchRun( seq* pSeq, int N )
{
    vector<int> v;
    vector<int>::iterator it;
    int nC;

    //fprintf( stdout, "\n\tTesting sequence %s\n", (pSeq+G_CLO_BEG_SEQ)->accnum.c_str() );
    fprintf( stdout, "\n\tThe following sequences are between %d and %d nt different from the query sequence %s : \n", G_CLO_MATCH_MIN, G_CLO_MATCH_MAX, (pSeq+G_CLO_BEG_SEQ)->accnum.c_str() );
    
    for( int i=G_CLO_MATCH_MIN; i <= G_CLO_MATCH_MAX; i++ )
    {
        for( nC=0; nC < N; nC++ )
        {
            if( nC==G_CLO_BEG_SEQ ) continue;
            int dist = SeqDistanceNT( pSeq+nC, pSeq+G_CLO_BEG_SEQ, true );
        
            if( dist==i ) fprintf( stdout, "\n\t\t%3d\t%s ", i, (pSeq+nC)->accnum.c_str() );
        }
    }
    
    fprintf( stdout, "\n\n");
}
//

double PValMaxHeight_1( int m, int n, int k )
{
    double dPValClosed = ((double)1);
    double dM = ((double)m);
    double dN = ((double)n);
    double dK = ((double)k);
    for(int jj = 1; jj <= k; jj++)
    {
        dPValClosed = dPValClosed * (dM/(dN+dK));
	dM = dM - ((double)1);
	dN = dN - ((double)1);
    }

    return dPValClosed;
}

void CheckForDuplicateAccessionNumbers( seq* pSeq, int N )
{
    int i, j;
    bool bProblem = false;
    
    for(i = 0; i < N -1; i++ )
    {
        for(j = i+1; j < N; j++)
        {
            if( (pSeq+i)->accnum == (pSeq+j)->accnum )
            {
                fprintf( stderr, "\n\tDATA PROBLEM : sequences %d and %d have the same accession number %s.", i, j, ((pSeq+i)->accnum).c_str() );
                bProblem = true;
            }
        }
    }
    
    if( bProblem ) fprintf( stderr, "\n");
    return;
}

int GetNumberDistinctSequences( seq* pSeq, int N )
{
    int i, j, k;
    bool b = false;

    // loop through the sequences
    for(i = 0; i < N -1; i++ )
    {
        if( (pSeq+i)->marked_for_deletion == true ) continue;
        
	// loop through candidate comparison sequences
        for(j = i+1; j < N; j++)
        {
            if( (pSeq+j)->marked_for_deletion == true ) continue;
            
	    // here you have two sequences that are NOT marked for deletion; if they
	    // are identical at non-gapped sites, then we mark the second for deletion
	    
	    // assume these two are identical, and try to find a difference
	    bool bIdentical = true;
	    
	    // loop through all nt positions
	    for(k = 0; k < pSeq->nt.length(); k++)
	    {
	        if( (pSeq+i)->nt[k] != (pSeq+j)->nt[k]   &&   (pSeq+i)->nt[k] != '-'   &&   (pSeq+j)->nt[k] != '-' )
                {
                    //fprintf( stderr, "\n\tNOTE : sequence %d identical to sequence %d.", i, j );
                    bIdentical = false;
		    break;
                }  
	    }
	    if( bIdentical ) (pSeq+j)->marked_for_deletion = true;
        }
    }

    int nDistinct = 0;
    for(i = 0; i < N; i++ )
    {
        if( (pSeq+i)->marked_for_deletion == false ) nDistinct++;
    }
    
    //if( b ) fprintf( stderr, "\n");
    
    return nDistinct;
}

seq* RemoveIdenticalSequences( seq* pSeq, int N, int NDistinct )
{
    int i;
    int j=0;
    seq* p = new seq[NDistinct];
    
    for(i = 0; i < N; i++ )
    {
        if( (pSeq+i)->marked_for_deletion == false ) 
        {
            assert( j < NDistinct );
            p[j] = pSeq[i];
            j++;
        }
    }
    assert( j == NDistinct );
    
    delete[] pSeq;
    return p;
}

seq* RemoveNeighborSequences( seq* pSeq, int* pN, int dist )
{
    int newN = 0;
    
    int i, j;
    
    for(i = 0; i < (*pN) - 1; i++ )
    {
        if( (pSeq+i)->marked_for_deletion == true ) continue;

        for(j = i+1; j < *pN; j++)
        {
            if( SeqDistanceNT( pSeq+i, pSeq+j ) <= dist ) 
            {
                (pSeq+j)->marked_for_deletion = true;
                (pSeq+i)->had_neighbor_deleted = true;
            }
        }
    }

    for(i = 0; i < *pN; i++ ) if( (pSeq+i)->marked_for_deletion == false ) newN++;
    seq* p = new seq[ newN ];
    j=0;

    for(i = 0; i < *pN; i++ )
    {
        if( (pSeq+i)->marked_for_deletion == false ) 
        {
            assert( j < newN );
            p[j] = pSeq[i];
            j++;
        }
    }

    assert( j == newN );

    *pN = newN;

    delete[] pSeq;
    return p;
}


void PrintUsageModes()
{

    cout << "\n\tUSAGE: \t./3seq -runmode  input_file  options";
    cout << "\n\n\tThere are currently 11 run modes:";
    cout << "\n\n\t\t./3seq  -version";
    cout << "\n\t\t./3seq  -help";     
    cout << "\n\t\t./3seq  -info      input_file  [-options]";
    cout << "\n\t\t./3seq  -write     input_file  [-options]";
    
    cout << "\n\n\t\t./3seq  -single    input_file  [-options]";
    
    cout << "\n\n\t\t./3seq  -match     input_file  minDist   maxDist             [-options]";
    cout <<   "\n\t\t./3seq  -triplet   input_file  P_ACCNUM  Q_ACCNUM  C_ACCNUM  [-options]";
    
    cout << "\n\n\t\t./3seq  -dryrun    input_file  maxPWDAllowed  maxDescentAllowed  [-options]";
    cout <<   "\n\t\t./3seq  -quickrun  input_file  maxPWDAllowed  maxDescentAllowed  [-options]";
    cout << "\n\n\t\t./3seq  -xrun      input_file  [-options]";
    cout << "\n\n\t\t./3seq  -fullrun   input_file  memory_allotment(in mb)  [-options]";
    cout << "\n\n";
}

void PrintOptions()
{
	cout << "\n\n\tOPTIONS:\n";
	cout << "\n\n\t\t-a\tuses all sites rather than just polymorphic sites; default is off.";
	cout << "\n\n\t\t-b -e\tbeginning sequence / end sequence; e.g. -b13 -e17 tests sequences #13 through #17\n\t\t\tinclusive (each as the child sequence) to test if they are a recombinant of the\n\t\t\tremaining sequences in the data set.\n\n\t\t\tThis option can be used to parallelize the algorithm (e.g. -b0 -e9 on processor #1; \n\t\t\t-b10 -e19 on processor #2). \n\n\t\t\tTo test a single query sequence for recombination, simply use -b19 -e19.\n\n\t\t\tDefault is to test all sequences for recombination.";
	cout << "\n\n\t\t-d\tdistinct sequences only; removes sequences that are identical to other sequences;\n\t\t\tdefault is off.";
	cout << "\n\n\t\t-f -l\tfirst and last nucleotide to be analyzed, e.g. -f100 -l200 considers nucleotide\n\t\t\tpositions 100-200 inclusive (first position is 1, not 0); default is all positions.";
	
	cout << "\n\n\t\t-L\tsets the minimum length to count a segment as recombinant; e.g. -L150 sets \n\t\t\tminimum length to 150 nucleotides; default is 100nt.";
	cout << "\n\n\t\t-p\tuse when 3SEQ is called by a python script; output is formatted as a single\n\t\t\ttab-delimited string to be used by a python program; default is off.";
	cout << "\n\n\t\t-r\trecord skipped computation to file \"3s.skippedpvals\"; default is off.";
	cout << "\n\n\t\t-t\trejection threshold, e.g. -t0.01, -t1e-6; default is -t0.05.";
	cout << "\n\n\t\t-x\tcut; this option can be used with the -f and -l switches to cut out a portion of\n\t\t\tthe sequence and use the remainder of the sequence for analysis\n\t\t\t( e.g. 3seq -f file -1 -f100 -l200 -x )";
	cout << "\n\n\t\t-y\tindicates YesNo-mode; algorithm stops once a significant triple has been found;\n\t\t\tthis is off by default.";
	cout << "\n\n\t\t-#\tindicates that for multiple comparisons corrections, the number of comparisons\n\t\t\tto be used is the actual number performed in the run; when this option is off,\n\t\t\tthe number of comparisons used in the correction is N*(N-1)*(N-2) where N is\n\t\t\tthe total number of sequences; this options is off by default.";
	
	cout << "\n\n\t\t-bp-all        \t calculate all breakpoint positions for all candidate recombinants; this\n\t\t\t\t will significantly slow down the algorithm when the sequence data are\n\t\t\t\t highly recombinant; default is to calculate only the best breakpoint\n\t\t\t\t positions per candidate recombinant.";
	cout << "\n\n\t\t-bp-none       \t do not calculate any breakpoint positions; this mode will generate a file\n\t\t\t\t `3s.rec' with all candidate recombinant triplets but with no breakpoint\n\t\t\t\t information; default is to calculate the best breakpoint positions\n\t\t\t\t per candidate recombinant and include only these triplets in `3s.rec'.";
	cout << "\n\n\t\t-fasta         \t format output as fasta; write mode only.";
	cout << "\n\n\t\t-hs            \t use the Hogan-Siegmund approximations (Adv. Appl. Math., 1986), when\n\t\t\t\t the exact p-values cannot be computed.";
	cout << "\n\n\t\t-id            \t gives unique identifier for this run; e.g. when running the algorithm\n\t\t\t\t in parallel, you can specify \n\n\t\t\t\t\t3seq -x myfile.aln -b0  -e9  -id run01\n\t\t\t\t\t3seq -x myfile.aln -b10 -e19 -id run02\n\n\t\t\t\t and this will create output files called 3s.rec.run01, 3s.rec.run02, \n\t\t\t\t 3s.pvalhist.run01, 3s.pvalhist.run02, etc.";
	cout << "\n\n\t\t-nexus         \t format output as nexus; write mode only.";
	cout << "\n\n\t\t-nr            \t suppress writing to 3s.rec file.";
	//cout << "\n\n\t\t-nobreakpoints \t don't calculate breakpoint positions; this significantly speeds up\n\t\t\t\t the algorithm when there are many recombinants.";
	//cout << "\n\n\t\t-out\t\t designates output file which will store the chosen subset and cut of\n\t\t\t\t the full sequences. Usage is '3seq -x seq.aln -out newfile.aln'.  Output\n\t\t\t\t file will be in PHYLIP format.\n\n\t\t\t\t When using the -out option, it is helpful to use the -a option as well,\n\t\t\t\t so that the entire sequence will be written to the output file (not just\n\t\t\t\t the polymorphic sites).";
	
	cout << "\n\n\t\t-subset\t\t designates subset of sequences to be analyzed; command-line usage is \n\t\t\t\t '3seq -x seq.aln -subset my_subset_file' where the file 'my_subset_file'\n\t\t\t\t is text file with accession numbers separated by whitespace.";
	cout << "\n\n\t\t-subset-remove\t as above, except that the sequences in the subset file 'my_subset_file'\n\t\t\t\t are removed from the dataset.";
	cout << "\n\n\t\t-12po\t\t first and second positions only; strips sequences down to positions 1, 2\n\t\t\t\t 4, 5, 7, 8 etc. Note that if your start codon is at positions 20-22,\n\t\t\t\t then you must use the option -f20 (and perhaps -l as well) to ensure\n\t\t\t\t that you are in the right reading frame and that you are looking at a\n\t\t\t\t coding region.";
	cout << "\n\n\t\t-3po\t\t third positions only; strips sequences down to positions 3, 6, 9, etc.\n\t\t\t\t Note that if your start codon is at positions 20-22, then you must use\n\t\t\t\t the option -f20 (and perhaps -l as well) to ensure that you are in the\n\t\t\t\t right reading frame and that you are looking at a coding region.";
	cout << "\n\n";
}

// parses command line arguments
void ParseArgs(int argc, char **argv, int* m, int* k)
{
    int i, start;
    FILE* fp=NULL; // this is just a file pointer used to see if files exist

    if( argc==1 )
    { 
        PrintUsageModes(); 
	exit(-1);
    }
    
    // read in run mode
    switch( (argv[1])[1] )
    {
        case 'v' :
	    cout << "\n\t3SEQ -- software for identifying recombination in sequence data.";
	    cout << "\n\n\tCopyright © 2006-10 Maciej F. Boni.  All Rights Reserved.\n\tLicensed for non-commercial use only.";
	    cout << "\n\n\tWhen using this software software, please cite\n\n\t\tBoni MF, Posada D, Feldman MW.  An exact nonparametric\n\t\tmethod for inferring mosaic structure in sequence triplets.\n\t\tGenetics, 176:1035-1047, 2007.";
	    cout << "\n\n\tIf you use the '-hs' option or 'fullrun' mode, please also cite\n\n\t\tHogan ML, Siegmund D.  Large deviations for the maxima\n\t\tof some random fields.  Advances in Applied Mathematics,\n\t\t7:2-22, 1986.";
	    //cout << "\n\n\tversion " << VERSION << "\n\n";
	    printf("\n\n\tversion %1.5f \n\n", VERSION);
	    exit(-1);
	case 'h' :
            cout << "\n\t---------------------------------\n";
            //PrintHelp();
            cout << "\n\tFor help, email author: maciej.boni@ndm.ox.ac.uk, mboni@oucru.org\n";
	    cout << "\n\tInput file may be PHYLIP (interleaved or non-interleaved) or FASTA format.\n";
	    cout << "\n\t---------------------------------\n";
	    //cout << "\n\t----------------";
	    //cout << "\n\tUse:\n\t\t0 for phylip (interleaved)\n\t\t1 for neisseria\n\t\t2 for dengue and mtDNA\n\t\t3 for phylip (non-interleaved with newline after sequence name) ";
	    //cout << "\n\t----------------\n";
	    PrintUsageModes(); 
	    cout << "\t---------------------------------";
	    PrintOptions();
	    cout << "\t---------------------------------\n\n";
	    exit(-1);
	case 'i' : G_RunMode = Info; break;
	case 's' : G_RunMode = SingleBpRun; break;
	case 'd' : G_RunMode = DryRun; break;
	case 'q' : G_RunMode = QuickRun; break;
	case 'f' : G_RunMode = FullRun; break;
	case 't' : G_RunMode = TripletRun; break;
	case 'x' : G_RunMode = XRun; break;
	case 'w' : G_RunMode = WriteRun; break;
	case 'm' : G_RunMode = MatchRun; break;
	default : 
	    PrintUsageModes(); 
	    exit(-1);
    }
    
    // at this point, we need at least 3 args because we need an input file
    if( argc < 3 )
    { 
        PrintUsageModes();
	exit(-1);
    }
    else
    {
        // check if file exists
        fp=NULL;
        fp=fopen( argv[2], "r");
        if( fp==NULL )
        {
            printf("\n\tFile '%s' does not exist.\n\n", argv[2] );
            exit(-1);
        }
        fclose( fp );
    }
    
    // set start position for looping through command line options
    switch( G_RunMode )
    {
        case Info:   case SingleBpRun:  case XRun:  case WriteRun:    	  		start=3; break;
	case DryRun: case QuickRun:     case MatchRun:                			start=5; break;
	case FullRun:                               					start=4; break;
	case TripletRun:                            					start=6; break;
	default:                                    					start=argc; 
    }    

    string str;

    // read in options
    for(i=start; i<argc; i++)
    {
        if( (argv[i])[0] != '-' ) 
	{
	    fprintf(stderr, "\n\tCannot understand `%s' on command line.\n\n", argv[i]);
            exit(-1);
        }
	if( (argv[i])[1] == (char)0 ) continue;
	
	char option = (argv[i])[1];
	switch( option )
	{
	    case '1' : str = argv[i]; 
                         if( str == "-12po" )
	                 {
	                     G_CLO_FIRST_AND_SECOND_POSITIONS_ONLY = true; 
	                     G_CLO_THIRD_POSITIONS_ONLY = false;
	                     break;
	                 }
	                 else
	                 {
	    		     fprintf(stderr, "\n\tUnknown option [%s] on command line.\n\n", argv[i]);
	        	     exit(-1);
	                 }	
	    case '3' : str = argv[i]; 
                         if( str == "-3po" )
	                 {
	                     G_CLO_THIRD_POSITIONS_ONLY = true; 
	                     G_CLO_FIRST_AND_SECOND_POSITIONS_ONLY = false;
	                     break;
	                 }
	                 else
	                 {
	    		     fprintf(stderr, "\n\tUnknown option [%s] on command line.\n\n", argv[i]);
	        	     exit(-1);
	                 }
	    case 'a' : G_CLO_ALLSITES = true; break;
	    case 'b' : str = argv[i];
	                 if( str == "-bp-all" )
	                 {
	                     G_CLO_BREAKPOINTS_FOR_ALL_RECOMBINANTS = true;
	                     G_CLO_NO_BREAKPOINTS = false; break;
	                 }
	                 else if( str == "-bp-none" )
	                 {
	                     G_CLO_NO_BREAKPOINTS = true;
	                     G_CLO_BREAKPOINTS_FOR_ALL_RECOMBINANTS = false; break;
	                 }
	                 else if( str == "-b" )
	                 {
	                     fprintf(stderr, "\n\tWith -b option, you must give a starting position in the sequence array,\n\te.g. -b0 for the first sequence or -b2 for the third sequence.\n\n");
	        	     exit(-1);
	                 }
	                 else
	                 {
	                     G_CLO_BEG_SEQ  = atoi( argv[i]+2 ); break;
	                 }
	    case 'd' :  G_CLO_REMOVE_IDENTICAL_SEQUENCES = true; 
                    G_CLO_REMOVE_DISTANCE = atoi( argv[i]+2 ); break;
        case 'D' :
                    if(argv[i+1][0]=='-') { printf("\n\tdirectory of pvalues after -D option cannot start with '-' character.\n\n"); exit(-1);}
                    //G_PVALUETABLE_DIR = argv[i+1];
                    break;            
	    case 'e' : str = argv[i];
	                 if( str == "-e" )
	                 {
	                     fprintf(stderr, "\n\tWith -e option, you must give an ending position in the sequence array,\n\te.g. -e0 for the first sequence or -e2 for the third sequence.\n\n");
	        	     exit(-1);
	                 }
	                 else
	                 {
	                     G_CLO_END_SEQ  = atoi( argv[i]+2 ) + 1; break;
	                 }
	    case 'f' : str = argv[i];
	                 if( str == "-fasta" ) {G_CLO_OUTPUT_FASTA = true; break;}
			 else
			 {
		             G_CLO_FIRST = atoi( argv[i]+2 ) - 1; 
			     break;
			 }
	    case 'h' : str = argv[i]; 
	    	        if( str == "-hs" ) {G_CLO_USE_SIEGMUND_APPROX = true; break;}
	    		else
	    		{
	    		    fprintf(stderr, "\n\tUnknown option [%s] on command line.\n\n", argv[i]);
	        	    exit(-1);
	    		}
	    case 'i' :  str = argv[i]; 
	    	        if( str == "-id" ) 
	    	        {
	    	            if(i==argc-1) { printf("\n\tNo identifier string given after -id option.\n\n"); exit(-1);}
	    	            if(argv[i+1][0]=='-') { printf("\n\tIdentifier string after -id option cannot start with '-' character.\n\n"); exit(-1);}
	    	            G_CLO_ID = argv[i+1];
	    	            i++;
	    	            string strPeriod(".");
	    	            G_FILENAME_LOGFILE          = G_CLO_ID + strPeriod + G_FILENAME_LOGFILE;
                        G_FILENAME_RECOMBINANTS     = G_CLO_ID;
                        G_FILENAME_LONGRECOMBINANTS = G_CLO_ID + strPeriod + G_FILENAME_LONGRECOMBINANTS;
                        G_FILENAME_PVALUEHISTOGRAM  =  G_CLO_ID + strPeriod + G_FILENAME_PVALUEHISTOGRAM;
                        G_FILENAME_SKIPPEDPVALUES   = G_CLO_ID + strPeriod + G_FILENAME_SKIPPEDPVALUES;
                        break;
	    	        }
                    else
                    {
                        fprintf(stderr, "\n\tUnknown option [%s] on command line.\n\n", argv[i]);
                        exit(-1);
                    }
	    case 'l' : G_CLO_LAST = atoi( argv[i]+2 ); break;
	    case 'L' : G_CLO_MIN_RECOMBINANT_LENGTH = atoi( argv[i]+2 ); break;
	    case 'n' : str = argv[i]; 
	    		//if( str == "-nobreakpoints" ) {G_CLO_SKIP_BREAKPOINT_CALCULATIONS = true; break;}
	    		if( str == "-nexus" ) {G_CLO_OUTPUT_NEXUS = true; break;}
	    		else if( str == "-nr" ) {G_CLO_NO_3SREC_FILE = true; break;}
	    		else
	    		{
	    		    fprintf(stderr, "\n\tUnknown option [%s] on command line.\n\n", argv[i]);
	        	    exit(-1);
	    		}
	    /*case 'o' : str = argv[i]; 
	    		 if( str == "-out" )
	    		 {
	    		     if( i==argc-1 ){printf("\n\tNo filename given after '-out' option.\n\n");exit(-1);}
	    		     if(argv[i+1][0]=='-'){printf("\n\t'%s' not a valid filename.\n\n", argv[i+1]);exit(-1);}
	    		     G_CLO_OUTPUT_SEQUENCES_FILENAME = argv[i+1]; i++; break;
	    		 }
	    		 else
	    		 {
	    		     fprintf(stderr, "\n\tUnknown option [%s] on command line.\n\n", argv[i]);
	        	     exit(-1);
	    		 }*/
	    case 'p' : G_CLO_PYTHON = true; break;
        case 'P' : G_CLO_WRITEPVALHIST = true; break;
	    case 'r' : G_CLO_RECORD_SKIPPED_TRIPLES = true; break;
        case 'R' : G_CLO_WRITELONGRECOMBINANTS = true; break;
	    case 's' : str = argv[i]; 
	    		 if( i==argc-1 ) { printf("\n\tNo filename given after subset option.\n\n"); exit(-1);}
	    		 G_CLO_SUBSET_FILENAME = argv[i+1];
        		 fp=NULL; fp=fopen( argv[i+1], "r");
        		 if( fp==NULL ) { printf("\n\tFile '%s' does not exist.\n\n", argv[i+1] ); exit(-1);}
        		 fclose( fp );
	    		 if( str == "-subset" ) {i++; break;}
	    		 else if( str == "-subset-remove" ) {i++; G_CLO_REMOVE_SUBSET = true; break;}
	    		 else
	    		 {
	    		     fprintf(stderr, "\n\tUnknown option [%s] on command line.\n\n", argv[i]);
	        	     exit(-1);
	    		 }
	    case 't' : str = argv[i];
	                 if( str == "-t" )
	                 {
	    		     fprintf(stderr, "\n\tWith -t option, you must give a value for the rejections threshold,\n\te.g. -t0.20 or -t1e-6\n\n", argv[i]);
	        	     exit(-1);
	                 }
	                 else // here we assume -t was used properly, i.e. "-t0.01"
	                 {
	                     G_CLO_THRESHOLD = atof( argv[i]+2 ); break;
	                 }
	    case 'x' : G_CLO_CUT  = true; break;	    
	    case 'y' : G_CLO_YESNO  = true; break;	    
	    case '#' : G_CLO_USE_ALL_TRIPLES = false; break;
	    case '*' : G_PHYLIP  = false; break;	// this is a secret; converts fasta to phylip
	    default :
	        fprintf(stderr, "\n\tUnknown option [%s] on command line.\n\n", argv[i]);
		exit(-1);
	}
    }
        
    // for DryRun and QuickRun, make sure there are at least 5 CLOs and read in #3 and #4 into *m and *k
    if( G_RunMode==DryRun || G_RunMode==QuickRun )
    {
        if( argc < 5 )
	{
	    PrintUsageModes();
	    exit(-1);
	}
	
	if( G_CLO_PYTHON )
	{
	    cerr << "\n\tWARNING: -p option being ignored (not yet implemented for QuickRun and DryRun modes).";
	    G_CLO_PYTHON=false;
	}
		
	// verify that that args 3 and 4 are numbers
	if( !is_integer( argv[3] ) || !is_integer( argv[4] ) )
	{
	    cout << "\n\t4th and 5th arguments on command line must be positive integers.\n\n";
	    exit(-1);
	}
	*m = atoi( argv[3] );
	*k = atoi( argv[4] );
	
	// make sure m or k are not zero
	if( *m==0 || *k==0 )	
	{
		cout << "\n\t4th and 5th arguments on command line must be positive integers.\n\n";
		exit(-1);
	}
	
	int nMegs = GetMegsNeeded( *m, *k ); 
	char ans;	
	if( (nMegs > 10 || nMegs < 0) && G_RunMode==QuickRun )
        {
	    int f = sizeof( float );
	    if( f!=4 ) cerr << "\n\t`float' type in C/C++ is " << sizeof( float ) << " bytes on your system.\n";
	    cerr << "\n\tTotal RAM+SWAP needed is " << nMegs << " megabytes.\n";
            cerr << "\n\tIs this OK (y/N)?  ";
	    cin >> ans;
	    if( ans != 'y' )
	    {
	        cerr << "\n\tGoodbye.\n\n";
	        exit(-1);
	    }
        }
    } 

    // for FullRun mode make sure we have read in a memory allotment
    if( G_RunMode==FullRun )
    {
        if( argc < 4 )
	{
	    PrintUsageModes();
	    exit(-1);
	}
	
	G_CLO_MEMORY_ALLOTMENT = atoi( argv[3] );
	
	/*
     if( !G_CLO_PYTHON )
	{
	    char ans;
	    cerr << "\n\t3SEQ will ask your operating system for " << G_CLO_MEMORY_ALLOTMENT << " megabytes of memory.\n";
	    cerr << "\n\tIs this OK (y/N)?  ";
	    cin >> ans;
	    if( ans != 'y' )
	    {
	        cerr << "\n\tGoodbye.\n\n";
	        exit(-1);
	    }
	}*/
    }     
    
    // TripletRun should have 6 args
    if( G_RunMode==TripletRun )
    {
	    if( argc < 6 )
	    {
		    PrintUsageModes();
		    exit(-1);
	    }
	
	    if( G_CLO_PYTHON )
	    {
		    cout << "\n\tCannot use python option [-p] in TripletRun mode.\n\tPython running in this mode has not been implemented yet.\n\n\t-p option being ignored.\n";
	    }
	
	    // verify that that args 3 and 4 are numbers
	    /*if( !is_integer( argv[3] ) || !is_integer( argv[4] ) || !is_integer( argv[5] ) )
	    {
		    cout << "\n\t4th, 5th, 6th arguments on command line must be non-negative integers.\n\n";
		    exit(-1);
	    }*/
	    
	    // because the indices that are passed in are POSSIBLY from a
	    // run when identical sequences were removed
	    G_CLO_REMOVE_IDENTICAL_SEQUENCES = false;
	    G_CLO_TRIPLET_P = argv[3];
	    G_CLO_TRIPLET_Q = argv[4];
	    G_CLO_TRIPLET_C = argv[5];
	    
	    // G_CLO_ALLSITES = true;
    } 
    
    if( G_RunMode==XRun )
    {
	if( G_CLO_PYTHON )
	{
	    //cerr << "\n\tWARNING: -p option being ignored (not yet implemented for XRun mode).";
	    //G_CLO_PYTHON=false;
	}
    }
    
    if( G_RunMode==MatchRun )
    {
        if( argc < 5 )
	{
	    PrintUsageModes();
	    exit(-1);
	}
	G_CLO_MATCH_MIN = atoi( argv[3] );
	G_CLO_MATCH_MAX = atoi( argv[4] );      
    }
    
    return;
}
//




