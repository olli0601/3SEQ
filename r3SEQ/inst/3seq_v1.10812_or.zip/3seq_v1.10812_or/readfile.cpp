//
// Copyright (c) 2006-07 Maciej F. Boni.  All Rights Reserved.
//
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <vector>

#include <ctype.h>
#include <assert.h>
#include <cstdlib>

#include "readfile.h"

// function declarations
// bool isnt( char c );



// function declarations
// bool isnt( char c );

// pass in a file pointer to
// a NEWLY opened file, and it will count the number
// sequences in the file assuming each sequence starts
// with the charcater cDelim, the delimiter
int NumSequences( FILE* DataFile, char cDelim )
{
    int nNumSeq=0;
    char c;

    //cout << "\n\t" << cDelim;
    
    while( (c=fgetc(DataFile)) != EOF )
    {
	if( c == cDelim )
	{
	    nNumSeq++;
	}
    }

    //cout << nNumSeq;
    
    return nNumSeq;
}

bool isnt( char c )
{
    if( c=='A' || c=='C' || c=='G' || c=='T' ||
	c=='a' || c=='c' || c=='g' || c=='t' || 
	c=='R' || c=='Y' || c=='M' || c=='K' ||
	c=='r' || c=='y' || c=='m' || c=='k' || 
	c=='S' || c=='W' || c=='H' || c=='B' ||
	c=='s' || c=='w' || c=='h' || c=='b' || 
	c=='V' || c=='D' || c=='N' || c=='-' ||
	c=='v' || c=='d' || c=='n' )
    {
	return true;
    }
    else
    {
	return false;
    }    
}

//
// this version reads in Neisseria sequences from GenBank
// the format is that the first line looks like
//               > ACCNUM NAME
// and the rest is whitespace and nucleotides until the next sequence.
//
void ReadNextSequence_01( FILE* DataFile, seq* p )
{
    char c;
    int i;
    string accnum("");

    // skip all '>' characters and spaces
    while( (c=fgetc(DataFile)) == '>' || isspace(c));

    // read strain accession number
    while( !isspace(c) )
    {
	accnum += c;
	c = fgetc(DataFile);
    }

    //cout << "\n\t" << accnum;
    
    // skip white space
    while( isspace(c) ) {c=fgetc(DataFile);}

    // read strain name (until space)
    string name("");
    while( !isspace(c) )
    {
	name += c;	
	c = fgetc( DataFile );
    }

    // now go to the first nucleotide
    while( !isnt(c) ) {c=fgetc(DataFile);}

    // and now read in all the nucleotides
    string ntseq("");
    while( (isnt(c) || isspace(c)) && c!='>' && c!=EOF )
    {
        if(isnt(c))
	{
	    if( islower(c) )
	    {
	        c = c-32;
	    }
	    ntseq += c;
	}
	c = fgetc(DataFile);
    }

    if( c!= '>' )
    {
         cout << "\n\tfinished reading nt-seq at character " << c << " (" << ((int)c) << ")";
    }

    p->accnum = accnum;
    p->nt = ntseq;
    p->name = name;

    return;
}

//
// this version reads in Neisserie sequences from GenBank
// the format is that the first line looks like
//               > ACCNUM 
// and the rest is whitespace and nucleotides until the next sequence.
//
void ReadNextSequence_02( FILE* DataFile, seq* p )
{
    char c;
    int i;
    string accnum("");

    // skip all '>' characters and spaces
    while( (c=fgetc(DataFile)) == '>' || isspace(c));

    // read strain accession number
    while( !isspace(c) )
    {
	accnum += c;
	c = fgetc(DataFile);
    }

    //cout << "\n\t" << accnum;
    
    // now go to the first nucleotide
    while( !isnt(c) ) {c=fgetc(DataFile);}

    // and now read in all the nucleotides
    string ntseq("");
    while( (isnt(c) || isspace(c)) && c!='>' && c!=EOF )
    {
        if(isnt(c))
	{
	    if( islower(c) )
	    {
	        c = c-32;
	    }
	    ntseq += c;
	}
	c = fgetc(DataFile);
    }

    if( c!= '>' && c!= EOF )
    {
         cout << "\n\tfinished reading nt-seq at character " << c << " (" << ((int)c) << ")";
    }

    p->accnum = accnum;
    p->nt = ntseq;

    return;
}


//
// this version reads in some of the test flu sequences
// the format is that the first line looks like
//               > ACCNUM *
// where the first line ends in an asterisk
// and the rest is whitespace and nucleotides until the next sequence.
//
void ReadNextSequence_03( FILE* DataFile, seq* p )
{
    char c;
    int i;
    string accnum("");

    // skip all '>' characters and spaces
    while( (c=fgetc(DataFile)) == '>' || isspace(c));

    // read strain accession number
    while( !isspace(c) )
    {
	accnum += c;
	c = fgetc(DataFile);
    }

    // go to the asterisk
    while( c != '*' ) c=fgetc(DataFile);
    
    // now go to the first nucleotide
    while( !isnt(c) ) c=fgetc(DataFile);

    // and now read in all the nucleotides
    string ntseq("");
    while( (isnt(c) || isspace(c)) && c!='>' && c!=EOF )
    {
        if(isnt(c))
	{
	    if( islower(c) )
	    {
	        c = c-32;
	    }
	    ntseq += c;
	}
	c = fgetc(DataFile);
    }

    if( c!= '>' )
    {
         cout << "\n\tfinished reading nt-seq at character " << c << " (" << ((int)c) << ")";
    }

    p->accnum = accnum;
    p->nt = ntseq;

    return;
}


//
// this reads in alignment files that are output by clustal
//
// it allocates memory for the sequence array and returns
// a pointer to the first sequence
//
// the input file does not *have* to be interleaved, but it can be
//
seq* ReadAlignmentIL( FILE* DataFile, int* pnNumSeq, int* pnLen )
{
    char c;
    int i;
    
    //move to the first non-space
    while( isspace(c=fgetc(DataFile)));

    string strNumSeq("");
    while( !isspace(c) )
    {
        strNumSeq += c;
	c = fgetc(DataFile);
    }
    
    // now that we know the number of sequences, allocate space for the sequence array
    int N = atoi( strNumSeq.c_str() );
    //cout << "\n\tinside ReadAlignmentIL( .. ) " << N;
    *pnNumSeq = N;
    seq* pSeq = new seq[N];
            
    //move to the first non-space
    while( isspace(c=fgetc(DataFile)));

    string strSeqLen("");
    while( !isspace(c) )
    {
        strSeqLen += c;
	c = fgetc(DataFile);
    }
    int L = atoi( strSeqLen.c_str() );
    *pnLen = L;
            
    // now, for the first N lines, read in accession numbers and nucleotides
    for(i = 0; i < N; i++)
    {
        // move one past the newline character
	while( c != '\n' ) c=fgetc(DataFile);
	c= fgetc(DataFile);
	
	//cout << "\n\tcurrent char is " << c;
	
        // read in the accession number
        string strAccNum("");
        while( !isspace(c) )
        {
            strAccNum += c;
	    c = fgetc(DataFile);
        }
    
        // and now read in all the nucleotides until a newline
        string strNtseq("");
        while( (isnt(c) || isspace(c)) && c!='\n' && c!=EOF )
        {
            if( islower(c) && c != '-' ) c=c-32;
	    if( isnt(c) ) strNtseq += c;
	    c = fgetc(DataFile);
        }

	(pSeq+i)->accnum = strAccNum;
	(pSeq+i)->nt = strNtseq;
        //cout << "\n\t" << strAccNum << " " << strNtseq;
    }

    //if( c == '\n' ) cout << "\n\tchar is a newline";
    
    
    // now just loop through each line and add it to the appropriate sequence by 
    // keeping track of i (the number of the line) and adding it to sequence i%N
    i = N;    
    while( true )
    {
        // advance to the next nucleotide
	while( !isnt(c) && c!=EOF ) c=fgetc(DataFile);
	if( c==EOF ) break;
	
        // now read in all the nucleotides until a newline
        string strNtseq("");
        while( (isnt(c) || isspace(c)) && c!='\n' && c!=EOF )
        {
            if( islower(c) && c != '-' ) c=c-32;
	    if( isnt(c) ) strNtseq += c;
	    c = fgetc(DataFile);
        }	
	
	(pSeq+(i%N))->nt += strNtseq;
	i++;
	
	if( c==EOF ) break;
    }
            
    /*for(i=0; i<N; i++)
    {
        cout << "\n\t" << (pSeq+i)->accnum << "  " << ((pSeq+i)->nt).length();
    }*/
    
    fclose( DataFile );
    return pSeq;

}


//
// this reads in alignment files that are phylip format, meaning:
// (1) non-interleaved (NI)
// (2) newline after sequence name (NL)
//
// it allocates memory for the sequence array and returns
// a pointer to the first sequence
//
seq* ReadAlignmentNINL( FILE* DataFile, int* pnNumSeq, int* pnLen )
{
    char c;
    int i;
    
    //cout << "\n\tinside ReadAlignmentNINL(..)\n";
    //move to the first non-space
    while( isspace(c=fgetc(DataFile)));

    string strNumSeq("");
    while( !isspace(c) )
    {
        strNumSeq += c;
	c = fgetc(DataFile);
    }
    
    // now that we know the number of sequences, allocate space for the sequence array
    int N = atoi( strNumSeq.c_str() );
    //cout << "\n\tnumber of sequences is " << N;
    *pnNumSeq = N;
    seq* pSeq = new seq[N];
            
    //cout << "\n\tnum sequences is " << N;
    
    //move to the first non-space
    while( isspace(c=fgetc(DataFile)));

    string strSeqLen("");
    while( !isspace(c) && c != '\n' && c!=EOF )
    {
        strSeqLen += c;
	//cout << "\n\t" << c << "  " << (int)c;
	c = fgetc(DataFile);
    }
    int L = atoi( strSeqLen.c_str() );
    *pnLen = L;
            
    //cout << "\n\tseq length is " << L;
    
    // now, for the first N lines, read in accession numbers and nucleotides
    for(i = 0; i < N; i++)
    {
        // move to the first non-space
	while( isspace(c) ) c=fgetc(DataFile);
	
        // read in the accession number
        string strAccNum("");
        while( !isspace(c) && c != '\n' && c!=EOF  )
        {
            strAccNum += c;
	    //cout << "\n\t" << c << "  " << (int)c;
	    c = fgetc(DataFile);
        }
        
	//cout << "\n\t" << c << "  " << (int)c;
	
	//cout << "\n\t" << strAccNum;
	
	// move one past the newline character
	while( c != '\n' ) c=fgetc(DataFile);
	c= fgetc(DataFile);
	
        // and now read in all the nucleotides until a newline
        string strNtseq("");
        while( (isnt(c) || isspace(c)) && c!='\n' && c!=EOF )
        {
            if( islower(c) && c != '-' ) c=c-32;
	    if( isnt(c) ) strNtseq += c;
	    c = fgetc(DataFile);
        }

	//cout << "\n\t" << c << "  " << (int)c;
	
	(pSeq+i)->accnum = strAccNum;
	(pSeq+i)->nt = strNtseq;
        //cout << "\n\t" << strAccNum << " " << strNtseq;
	//cout << "\n";
    }

    //if( c == '\n' ) cout << "\n\tchar is a newline";
    
    fclose( DataFile );
    return pSeq;

}



//
// this is a wrapper for ReadAlignmentIL and ReadAlignmentNINL 
//
seq* ReadAlignment( char* szFilename, int* pnNumSeq, int* pnLen )
{
    char c;
    int i;
    bool bInterleaved;
    bool bFlag = false; // have we determined whether the file is interleaved yet?
    FILE* DataFile;            
    DataFile = fopen( szFilename, "r");
    
    //move to the first newline character
    c=fgetc(DataFile);
    while( c != '\n' ) c=fgetc(DataFile);

    // move to the first non-space (the first accession number)
    while( isspace(c) ) c=fgetc(DataFile);

    // now, move to the first space (after the first accession number)
    while( !isspace(c) ) c=fgetc(DataFile);
    
    // if there is a newline after the first accession number, the file format
    // cannot be interleaved, and we must account for the newlines after the sequence
    // name;  we need this because treevolve generates sequence files like this
    if( c == '\n' )
    {
        bInterleaved = false;
	bFlag = true;
    }

    while( !bFlag )
    {
        c=fgetc(DataFile);
        if( isnt(c) )
	{
	    bFlag=true;
	    bInterleaved=true;
	}
	if( c=='\n' )
	{
	    bFlag=true;
	    bInterleaved=false;
	}
    }

     // need to close and re-open the datafile so you are back at the beginning of the file
    fclose( DataFile );
    DataFile = fopen( szFilename, "r");
    
    if( bInterleaved )
    {
        // cout << "\n\tFile is interleaved.";
        return ReadAlignmentIL( DataFile, pnNumSeq, pnLen );
    }
    else
    {
        // cout << "\n\tFile has newlines after accession number.";
        return ReadAlignmentNINL( DataFile, pnNumSeq, pnLen );
    }
}

// the bool "cut" means that we are cutting out the current accession numbers;
// if this bool is false then we leave in the accession numbers in strFilename and
// but the other ones out
seq* ReadAccessionNumberFile( string strFilename, seq* pSeq, int* pnNumSeq, bool cut )
{
    vector<string> vAccNums;
    FILE* DataFile;
    DataFile = fopen( strFilename.c_str(), "r");
    char c = fgetc( DataFile );
    int oldN = *pnNumSeq;

    // go to first non-space character
    while( isspace(c) ) c = fgetc( DataFile );

    string str("");

    // read in accession numbers one by one
    while( c!=EOF )
    {
        while( !isspace(c) && c!=EOF ) 
        {
            str+=c;
            c = fgetc( DataFile );
        }

        vAccNums.push_back( str );
        str = "";

        while( isspace(c) && c!=EOF ) c = fgetc( DataFile );
    }
    fclose( DataFile );

    int newN = cut ? oldN : 0;
    for(int i = 0; i < vAccNums.size(); i++ )
    {
        int index = GetIndexByAccNum( pSeq, oldN, vAccNums[i] );
        if( index != -1 && !cut ) newN++;
        if( index != -1 &&  cut ) newN--;
    }

    if( newN == 0 && !cut )
    {
        cout << "\n\tNo accession numbers in file '" << strFilename << "' \n\n";
        exit(-1);
    }
    if( newN == 1 && !cut )
    {
        cout << "\n\tOnly 1 accession number in file '" << strFilename << "'.  Cannot proceed with any analysis. \n\n";
        exit(-1);
    }
    if( newN == 0 && cut )
    {
        cout << "\n\tNo accession numbers left to analyze.\n\n";
        exit(-1);
    }
    if( newN == 1 && cut )
    {
        cout << "\n\tOnly 1 accession number left to analyze.  Cannot proceed with any analysis. \n\n";
        exit(-1);
    }

    seq* pSeqSubset = new seq[newN];

    int j = 0;
    if(!cut) fprintf(stderr, "\n\tUsing sequences in file %s.", strFilename.c_str() );
    if( cut) fprintf(stderr, "\n\tRemoving sequences from file %s.", strFilename.c_str() );
    
    if( !cut )
    {
        for(int i = 0; i < vAccNums.size(); i++ )
        {
            int index = GetIndexByAccNum( pSeq, oldN, vAccNums[i] );
            if( index != -1 && !cut )
            {
                //fprintf(stderr, "\tUsing sequence subset from file %s.  Getting sequence %s.  %d left.      \r", strFilename.c_str(), vAccNums[i].c_str(), vAccNums.size()-i); fflush(stderr);
                pSeqSubset[j]= pSeq[index];
                j++;
            }
        }
    }
    if( cut )
    {
        for(int k = 0; k < oldN; k++ )
        {
            // tells you if sequence j is in vAccNums
            bool bSeqInSubset = false;
            for( int i = 0; i < vAccNums.size(); i++ )
            {
                int index = GetIndexByAccNum( pSeq, oldN, vAccNums[i] );
                if( index==k )
                {
                    bSeqInSubset = true;
                    break;
                }
            }
            
            if( !bSeqInSubset )
            {
              pSeqSubset[j]= pSeq[k];
              j++;
            }
        }
    }

    fprintf(stderr, "\n");
    
    *pnNumSeq = newN;
    delete[] pSeq;
    return pSeqSubset;
}


int GetIndexByAccNum( seq* pSeq, int N, string acc )
{
    for( int i = 0; i < N; i++ )
    {
        string str = (pSeq+i)->accnum;
        if( str == acc ) return i;
    }
    
    return -1;
}

//
//
//
//
//
// everything below here is April 2009 and after
// these are the new functions for reading in files
//
//
//
//
//

bool is_integer( char* sz )
{
    int i=0;
    while( sz[i] != '\0' )
    {
        if( !isdigit( sz[i] ) ) return false;
	i++;
    }
    
    return true;
}

bool is_integer( const char* sz )
{
    int i=0;
    while( sz[i] != '\0' )
    {
        if( !isdigit( sz[i] ) ) return false;
	i++;
    }
    
    return true;
}

void capitalize( string& str )
{
    int len=str.length();
    for(int i=0; i<len; i++)
    {
        char c = str[i];
        if( islower(c) ) str[i]=c-32;
    }
}

bool all_chars_are_nt( string str )
{
    int len=str.length();
    for(int i=0; i<len; i++)
    {
        if( !isnt( str[i] ) ) 
	{
	    printf("\n\t%c (ascii code=%d) at position %d is not a nucleotide character", (char)str[i], (int)str[i], i );
	    return false;
	}
    }
    return true;
}

int replace_ambig_nt_with_gaps( string& str )
{
    int len=str.length();
    int num_replaced=0;
    for(int i=0; i<len; i++)
    {
        char c = str[i];
        if( c=='R' || c=='Y' || c=='M' || c=='K' || c=='S' || c=='W' || c=='H' || c=='B' || c=='V' || c=='D' || c=='N' ) 
        {
            str[i]='-';
            num_replaced++;
        }
    }
    return num_replaced;
}

FILETYPE GetFiletype( char* szFilename )
{
    ifstream infile( szFilename, ifstream::in );
    string first_string;
    string second_string;
    infile >> first_string;
    
    FILETYPE ft;
    
    if( first_string == "#NEXUS" ) ft = nexus;
    else if( first_string[0] == '>' ) ft = fasta;
    else ft = no_filetype;
    
    infile >> second_string;
    if( is_integer( first_string.c_str() ) && is_integer( second_string.c_str() ) ) ft = phylip;
    
    infile.close();
    
    return ft;
}

seq* ReadPhylipFile( char* szFilename, int* pnNumSeq, int* pnLen, int* pnAmbig )
{
    ifstream infile( szFilename, ifstream::in );
    int total_ambig_nt_replaced=0;
    string accnum("");
    string ntseq("");
    string positions("");
    int n, len;
    infile >> n;
    infile >> len;
    *pnNumSeq = n;
    *pnLen = len;
    
    seq* pSeq = new seq[n];
    
    // now read in accession numbers and nt-sequences n times
    for(int i = 0; i < n; i++)
    {
        infile >> accnum;
        infile >> ntseq;

        // capitalize
        capitalize( ntseq ); // tested this

        // check that all letters are nucleotides
	if( !all_chars_are_nt( ntseq ) )
	{
            cout << "\n\tSequence " << accnum << " has non-nucleotide characters.\n\n"; // tested this
            delete[] pSeq;
            exit(-1);
	}
	
	// replace ambiguous nucleotides with gaps
	int num_replaced = replace_ambig_nt_with_gaps( ntseq ); // tested this
        total_ambig_nt_replaced += num_replaced;

        (pSeq+i)->accnum = accnum;
	(pSeq+i)->nt = ntseq;
    }

    // and now, in case this is an interleaved file, read in block by block
    // and assign to the appropriate sequence
    int j = 0;
    while( true )
    {
        string str("");
        infile >> str;

        // both conditions must be met because you don't know if the 
        // user ended his file in whitespace or not
        if( str.length() == 0 && infile.eof() ) break;

        // if you didn't break above, that means that some non-whitespace
        // characters were read; see if this was the genome positions string
        // that looks like '#234,235,238,241'
        if( str[0]=='#' )
        {
            positions = str;
            break;
        }

        // otherwise, it should just be a string of nucleotides
        ntseq = str;

        // capitalize
        capitalize( ntseq );  // tested this

        // check that all letters are nucleotides
	if( !all_chars_are_nt( ntseq ) ) // tested this
	{
            cout << "\n\tSequence " << (pSeq+(j%n))->accnum << " has non-nucleotide characters.  If the last line of your phylip file\n\thas genomic positions, check to make sure this line begins with a hash ('#').\n\n";
            delete[] pSeq;
            exit(-1);
	}
	
	// replace ambiguous nucleotides with gaps
	int num_replaced = replace_ambig_nt_with_gaps( ntseq ); // tested this
        total_ambig_nt_replaced += num_replaced;
        
        (pSeq+(j%n))->nt += ntseq;

        j++;
    }
    
    for( int i = 0; i < n; i++ )
    {
        // check that length is ok
	if( (pSeq+i)->nt.length() != len ) // tested this
	{
            cout << "\n\tSequence " << (pSeq+i)->accnum << " has length " << (pSeq+i)->nt.length() << ".  Should be " << len << ".\n\n";
            delete[] pSeq;
            exit(-1);
	}
    }
	
    if( positions.length() > 0 )
    {
        // read in the comma-separated values from the positions string
    }
    
    // now that we're finished reading in the sequences, we 
    // can move on and read the nt positions if they appear after a hashmark
//     string strPos;
// 
//     // read until the hashmark
//     getline(infile, strPos, '#');
//     //cout << "\n\t" << strPos << " " << strPos.length() << "\n";
// 
//     // now read each integer, stopping at the commas
//     for(int i = 0; i < G_LEN; i++)
//     {
//         bool b = getline(infile, strPos, ',').eof();
//         stringstream ss;
//         int nPos;
//         ss << strPos; ss >> nPos;
//         //cout << "\n\t" << nPos;
//         G_V_POSITION.push_back(nPos);
//         if(b) break;
//     }

    *pnAmbig = total_ambig_nt_replaced;
    return pSeq;
}




seq* ReadFastaFile( char* szFilename, int* pnNumSeq, int* pnLen, int* pnAmbig )
{
    ifstream infile( szFilename, ifstream::in );
    int total_ambig_nt_replaced=0;
    string accnum("");
    string tr_ntseq("");
    string positions("");
    
    int n=0;
    int len=0;

    //infile >> n;
    //infile >> len;
    //*pnNumSeq = n;
    //*pnLen = len;
    
    // here just count how many ">" symbols there are at the beginnings of lines
    while( true )
    {
        string str("");
        getline( infile, str );

        // both conditions must be met because you don't know if the 
        // user ended his file in whitespace or not
        if( str.length() == 0 && infile.eof() ) break;
        string str2 = trim_end_ws( str );
        if( str2[0] == '>' ) n++;
    }

    //cerr << "\n\t" << n << " sequences in FASTA file.";

    seq* pSeq = new seq[n];

    // close and open the input file so you start at the beginning of the file again
    infile.close();
    infile.open(szFilename, ifstream::in );

    string str("");
    string strNT("");
    int index=0;
    int ro = 0;
    
    int longest_seq = -1;
    int shortest_seq = 1999999999;
    
    // now read through each line of the file
    while( true )
    {
        str="";
        getline( infile, str );
        ro++;
        //fprintf(stderr, "\n\tread operation %d -- string is %s   \t \tlen=%d", ro, str.c_str(), str.length()  ); fflush(stderr);

        // both conditions must be met because you don't know if the 
        // user ended his file in whitespace or not
        if( str.length() == 0 && infile.eof() ) break;

        if( str[0] == '>' )
        {
            int l = str.length();
            if( strNT.length() == 0 ) // meaning this is the first line of the file
            {
                pSeq[index].accnum = trim_end_ws( str.substr(1,l-1) );
            }
            else
            {
                tr_ntseq = trim_all_ws( strNT );

                // capitalize
                capitalize( tr_ntseq ); // tested this

                // check that all letters are nucleotides
	        if( !all_chars_are_nt( tr_ntseq ) )
	        {
                    cout << "\n\tSequence '" << pSeq[index].accnum << "' has non-nucleotide characters.\n\n"; // tested this
                    delete[] pSeq;
                    exit(-1);
	        }
	
        	// replace ambiguous nucleotides with gaps
	        int num_replaced = replace_ambig_nt_with_gaps( tr_ntseq ); // tested this
                total_ambig_nt_replaced += num_replaced;

                int seqlen = tr_ntseq.length();
                if( seqlen > longest_seq )  longest_seq  = seqlen;
                if( seqlen < shortest_seq ) shortest_seq = seqlen;
                pSeq[index].nt = tr_ntseq;
                strNT = "";
                index++;
                pSeq[index].accnum = trim_end_ws( str.substr(1,l-1) );
            }
        }
        else
        {
            strNT += str;
        }
    }
    
    // make sure the last sequence is read in
    tr_ntseq = trim_all_ws( strNT );

    // capitalize
    capitalize( tr_ntseq ); // tested this

    // check that all letters are nucleotides
    if( !all_chars_are_nt( tr_ntseq ) )
    {
        cout << "\n\tSequence '" << pSeq[index].accnum << "' has non-nucleotide characters.\n\n"; // tested this
        delete[] pSeq;
        exit(-1);
    }

    // replace ambiguous nucleotides with gaps
    int num_replaced = replace_ambig_nt_with_gaps( tr_ntseq ); // tested this
    total_ambig_nt_replaced += num_replaced;

    int seqlen = tr_ntseq.length();
    if( seqlen > longest_seq )  longest_seq  = seqlen;
    if( seqlen < shortest_seq ) shortest_seq = seqlen;
    pSeq[index].nt = tr_ntseq;

    /*fprintf(stderr, "\n\n"); fflush(stderr);
    for( int i = 0; i < n; i++ )
    {
        fprintf(stderr, "\n\t%s  \t %s  %3d %3d", pSeq[i].accnum.c_str(), pSeq[i].nt.c_str(), pSeq[i].accnum.length(), pSeq[i].nt.length() ); fflush( stderr);
    }

    fprintf(stderr, "\n\n\tLongest seq len is %d ; shortest is %d", longest_seq, shortest_seq); fflush(stderr);*/

    if( longest_seq!=shortest_seq )
    {
        fprintf(stderr,"\n\tFasta file is not aligned.  Sequences range from %dnt to %dnt.\n\n", shortest_seq, longest_seq );
        fflush( stderr );
        delete[] pSeq;
        exit(-1);
    }
    
    *pnNumSeq = n;
    *pnLen = longest_seq;
    *pnAmbig = total_ambig_nt_replaced;
    return pSeq;
}

string trim_all_ws( string str )
{
    string::iterator it = str.begin();
    while( it != str.end() )
    {
        if( isspace(*it) )
        {
            str.erase(it);
        }
        else
        {
            it++;
        }
    }
    
    return str;
}

string trim_end_ws( string str )
{
    string::iterator it = str.begin();
    while( it != str.end() )
    {
        if( isspace(*it) )
        {
            str.erase(it);
        }
        else
        {
            break;
        }
    }

    it = str.end();
    it--;
    while( it != str.begin() )
    {
        if( isspace(*it) )
        {
            str.erase(it);
            it--;
        }
        else
        {
            break;
        }
    }
    
    return str;
}
