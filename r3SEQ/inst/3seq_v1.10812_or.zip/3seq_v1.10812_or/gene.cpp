//
// Copyright � 2006 Maciej F. Boni.  All Rights Reserved.
//
#include <math.h>
#include <iostream>
#include <ctype.h>
#include <assert.h>
#include <string>
#include <vector>
#include "gene.h"
#include <cstdlib>
#include <stdio.h>

using namespace std;

int NonSynChanges( CODON cdn )
{
    AMINOACID aaOriginal = AA(cdn);
    CODON cdnOriginal = cdn;

    int n = 0; /* total number of synonymous changes */
    int i;

    for(i = 0; i <=3; i++)
    {
        cdn.pos1 = ((NUCTIDE) i);
	if( AA(cdn) != aaOriginal ) n++;
    }
    cdn.pos1 = cdnOriginal.pos1;

    for(i = 0; i <=3; i++)
    {
        cdn.pos2 = ((NUCTIDE) i);
	if( AA(cdn) != aaOriginal ) n++;
    }    
    cdn.pos2 = cdnOriginal.pos2;

    for(i = 0; i <=3; i++)
    {
        cdn.pos3 = ((NUCTIDE) i);
	if( AA(cdn) != aaOriginal ) n++;
    }

    return n;
}

CODON StringToCodon( char* szCodon )
{
    CODON cdn;
    assert( szCodon );
    assert( szCodon[0] != 0 );  
    assert( szCodon[1] != 0 );
    assert( szCodon[2] != 0 );  

    cdn.pos1 = ((NUCTIDE) F(szCodon[0]));    
    cdn.pos2 = ((NUCTIDE) F(szCodon[1]));    
    cdn.pos3 = ((NUCTIDE) F(szCodon[2]));

    return cdn;
}

void AssertCodon( CODON cdn )
{
    if(cdn.pos1 != A && cdn.pos1 != C && cdn.pos1 != G && cdn.pos1 != T )
    {
        assert( false );
    }
    if(cdn.pos2 != A && cdn.pos2 != C && cdn.pos2 != G && cdn.pos2 != T )
    {
        assert( false );
    }    
    if(cdn.pos3 != A && cdn.pos3 != C && cdn.pos3 != G && cdn.pos3 != T )
    {
        assert( false );
    }

    return;
}

/* this toggles between ints and chars for the nucleotides */
int F( int input )
{
  switch( input )
    {
    case 0:  return 65;
    case 1:  return 67;
    case 2:  return 71;
    case 3:  return 84;
    case 4:  return 45;
    case 65: return  0;
    case 67: return  1;
    case 71: return  2;
    case 84: return  3;
    case 45: return  4;
    default: assert(0); break;
    }
}


AMINOACID AA( CODON cdn )
{
    if( ((int) cdn.pos3)==4 || ((int) cdn.pos2)==4 || ((int) cdn.pos1)==4 )
    {
        cout << "\nWARNING: This function cannot yet handle unknown nucleotides.\n\n";
	exit(-1);
    }  

    int nValue = ((int) cdn.pos3) + 4*((int) cdn.pos2) + 16*((int) cdn.pos1);
    
    // cout << "\naminoacid value is :" << nValue << "\n";

    switch( nValue )
      {
      case  0: return Lysine;     /*AAA*/
      case  1: return Asparagine; /*AAC*/
      case  2: return Lysine;     /*AAG*/
      case  3: return Asparagine; /*AAT*/
      case  4: return Threonine;  /*ACA*/
      case  5: return Threonine;  /*ACC*/
      case  6: return Threonine;  /*ACG*/
      case  7: return Threonine;  /*ACT*/
      case  8: return Arginine;   /*AGA*/
      case  9: return Serine;     /*AGC*/
      case 10: return Arginine;   /*AGG*/
      case 11: return Serine;     /*AGT*/
      case 12: return Isoleucine; /*ATA*/
      case 13: return Isoleucine; /*ATC*/
      case 14: return Methionine; /*ATG*/
      case 15: return Isoleucine; /*ATT*/       

      case 16: return Glutamine;  /*CAA*/
      case 17: return Histidine;  /*CAC*/
      case 18: return Glutamine;  /*CAG*/
      case 19: return Histidine;  /*CAT*/
      case 20: return Proline;    /*CCA*/
      case 21: return Proline;    /*CCC*/
      case 22: return Proline;    /*CCG*/
      case 23: return Proline;    /*CCT*/
      case 24: return Arginine;   /*CGA*/
      case 25: return Arginine;   /*CGC*/
      case 26: return Arginine;   /*CGG*/
      case 27: return Arginine;   /*CGT*/
      case 28: return Leucine;    /*CTA*/
      case 29: return Leucine;    /*CTC*/
      case 30: return Leucine;    /*CTG*/
      case 31: return Leucine;    /*CTT*/   

      case 32: return GlutamicAcid;  /*GAA*/
      case 33: return AsparticAcid;  /*GAC*/
      case 34: return GlutamicAcid;  /*GAG*/
      case 35: return AsparticAcid;  /*GAT*/
      case 36: return Alanine;       /*GCA*/
      case 37: return Alanine;       /*GCC*/
      case 38: return Alanine;       /*GCG*/
      case 39: return Alanine;       /*GCT*/
      case 40: return Glycine;       /*GGA*/
      case 41: return Glycine;       /*GGC*/
      case 42: return Glycine;       /*GGG*/
      case 43: return Glycine;       /*GGT*/
      case 44: return Valine;        /*GTA*/
      case 45: return Valine;        /*GTC*/
      case 46: return Valine;        /*GTG*/
      case 47: return Valine;        /*GTT*/

      case 48: return Stop;          /*TAA*/
      case 49: return Tyrosine;      /*TAC*/
      case 50: return Stop;          /*TAG*/
      case 51: return Tyrosine;      /*TAT*/
      case 52: return Serine;        /*TCA*/
      case 53: return Serine;        /*TCC*/
      case 54: return Serine;        /*TCG*/
      case 55: return Serine;        /*TCT*/
      case 56: return Stop;          /*TGA*/
      case 57: return Cysteine;      /*TGC*/
      case 58: return Tryptophan;    /*TGG*/
      case 59: return Cysteine;      /*TGT*/
      case 60: return Leucine;       /*TTA*/
      case 61: return Phenylalanine; /*TTC*/
      case 62: return Leucine;       /*TTG*/
      case 63: return Phenylalanine; /*TTT*/
      }
}

char AAL( CODON cdn )
{

    if( ((int) cdn.pos2)==4 || ((int) cdn.pos1)==4 )
    {
        cout << "\nWARNING: Unknown amino acid";
	return 'Z';
    }
    if( ((int) cdn.pos3)==N )
    {
        cout << "\ninside if-statement in AAL-function\n";
	CODON cdn1 = cdn;	
	CODON cdn2 = cdn;	
	CODON cdn3 = cdn;	
	CODON cdn4 = cdn;

	cdn1.pos3 = A;
	cdn2.pos3 = C;
	cdn3.pos3 = G;
	cdn4.pos3 = T;

	AssertCodon( cdn1 );
	AssertCodon( cdn2 );
	AssertCodon( cdn3 );
	AssertCodon( cdn4 );
	
	char c1 = AAL( cdn1 );
	char c2 = AAL( cdn2 );
	char c3 = AAL( cdn3 );
	char c4 = AAL( cdn4 );	
	
	if( c1==c2 && c1==c3 && c1==c4 )
	{
	    cout << "\nUnknown nucleotide at 3rd position (no effect on AA)";
	    return c1;
	}
	else
	{
	    cout << "\nUnknown nucleotide at 3rd position (cannot determine AA)";
	    return 'Z';
	}
    }
    
    int nValue = ((int) cdn.pos3) + 4*((int) cdn.pos2) + 16*((int) cdn.pos1);

    switch( nValue )
      {
      case  0: return 'K'; /* Lysine AAA*/
      case  1: return 'N'; /* Asparagine AAC*/
      case  2: return 'K'; /* Lysine AAG*/
      case  3: return 'N'; /* Asparagine AAT*/
      case  4: return 'T'; /* Threonine ACA*/
      case  5: return 'T'; /* Threonine ACA*/
      case  6: return 'T'; /* Threonine ACA*/
      case  7: return 'T'; /* Threonine ACA*/
      case  8: return 'R'; /* Arginine AGA*/
      case  9: return 'S'; /* Serine AGC*/
      case 10: return 'R'; /* Arginine AGG*/
      case 11: return 'S'; /* Serine AGT*/
      case 12: return 'I'; /* Isoleucine ATA*/
      case 13: return 'I'; /* Isoleucine ATC*/ 
      case 14: return 'M'; /* Methionine ATG*/
      case 15: return 'I'; /* Isoleucine ATT*/

      case 16: return 'Q'; /* Glutamine CAA*/
      case 17: return 'H'; /* Histidine CAC*/
      case 18: return 'Q'; /* Glutamine CAG*/
      case 19: return 'H'; /* Histidine CAT*/
      case 20: return 'P'; /* Proline CCA*/
      case 21: return 'P'; /* Proline CCC*/
      case 22: return 'P'; /* Proline CCG*/
      case 23: return 'P'; /* Proline CCT*/
      case 24: return 'R'; /* Arginine CGA*/ 
      case 25: return 'R'; /* Arginine CGC*/ 
      case 26: return 'R'; /* Arginine CGG*/ 
      case 27: return 'R'; /* Arginine CGT*/ 
      case 28: return 'L'; /* Leucine CTA*/
      case 29: return 'L'; /* Leucine CTC*/
      case 30: return 'L'; /* Leucine CTG*/
      case 31: return 'L'; /* Leucine CTT*/

      case 32: return 'E'; /* GlutamicAcid GAA*/
      case 33: return 'D'; /* AsparticAcid GAC*/
      case 34: return 'E'; /* GlutamicAcid GAG*/
      case 35: return 'D'; /* AsparticAcid GAT*/
      case 36: return 'A'; /* Alanine GCA*/
      case 37: return 'A'; /* Alanine GCC*/
      case 38: return 'A'; /* Alanine GCG*/
      case 39: return 'A'; /* Alanine GCT*/
      case 40: return 'G'; /* Glycine GGA*/
      case 41: return 'G'; /* Glycine GGC*/
      case 42: return 'G'; /* Glycine GGG*/
      case 43: return 'G'; /* Glycine GGT*/
      case 44: return 'V'; /* Valine GTA*/
      case 45: return 'V'; /* Valine GTC*/
      case 46: return 'V'; /* Valine GTG*/
      case 47: return 'V'; /* Valine GTT*/

      case 48: return 'X'; /* Stop TAA*/
      case 49: return 'Y'; /* Tyrosine TAC*/
      case 50: return 'X'; /* Stop TAG*/
      case 51: return 'Y'; /* Tyrosine TAT*/
      case 52: return 'S'; /* Serine TCA*/
      case 53: return 'S'; /* Serine TCC*/
      case 54: return 'S'; /* Serine TCG*/
      case 55: return 'S'; /* Serine TCT*/
      case 56: return 'X'; /* Stop TGA*/
      case 57: return 'C'; /* Cysteine TGC*/
      case 58: return 'W'; /* Tryptophan TGG*/
      case 59: return 'C'; /* Cysteine TGT*/
      case 60: return 'L'; /* Leucine TTA*/
      case 61: return 'F'; /* Phenylalanine TTC*/
      case 62: return 'L'; /* Leucine TTG*/
      case 63: return 'F'; /* Phenylalanine TTT*/
      }
}

int NumSeqsPerYear( int nYear, seq* pSeq, int nArraySize )
{
    int i;
    int nCount = 0;

    for(i = 0; i < nArraySize; i++)
    { 
	if( pSeq[i].year == nYear )
	{
	    nCount++;
	}
    }

    return nCount;
}


int SeqDistanceAA( seq* s1, seq* s2 )
{
    // cout <<  "\nentering SeqDistanceAA function " << j << "\n\n";
    assert( s1 );
    assert( s2 );

    // string::size_type len1, len2;
    int len1 = (s1->aa).size();
    // cout << "\n did length calc\n\n";
    int len2 = (s2->aa).length();
    assert( len1 == len2 );

    int nNumDiff = 0;

    // cout << "\nabout to begin looping\n\n";
    for(int i=0; i < len1; i++)
    {
	if( (s1->aa)[i] != (s2->aa)[i] )
	{
	    nNumDiff++;
	}
    }

    return nNumDiff;
}

//
// "ignore_gaps" means that gaps do not count as differences
//
int SeqDistanceNT( seq* s1, seq* s2, bool ignore_gaps )
{
    int len1 = (s1->nt).length();
    int len2 = (s2->nt).length();
    //assert( len1 == len2 );
    if( len1 != len2 )
    {
        cout << "\n\tWARNING: passing in two sequences of unequal length to SeqDistanceNT( seq* , seq* )\n\n";
	return -1;
    }
    
    int nNumDiff = 0;

    for(int i=0; i < len1; i++)
    {
        char c1 = (s1->nt)[i];
        char c2 = (s2->nt)[i];
	if( c1 != c2 )
	{
	    if( ignore_gaps )
	    {
	        if( (c1=='A'||c1=='C'||c1=='G'||c1=='T')  &&  (c2=='A'||c2=='C'||c2=='G'||c2=='T') )
	        {
	            nNumDiff++;
	        }
	    }
	    else
	    {
	        nNumDiff++;
	    }
	}
    }

    return nNumDiff;
}

int SeqDistanceNT( seq* s1, seq* s2, int beg, int end ) // gets the distance between two sub-sequences
{
    int len1 = (s1->nt).length();
    int len2 = (s2->nt).length();
    //assert( len1 == len2 );
    if( len1 != len2 )
    {
        cout << "\n\tWARNING: passing in two sequences of unequal length to SeqDistanceNT( seq* , seq* )\n\n";
	return -1;
    }
    if( beg<0 || end<0 || beg>len1 || end>len1 || beg>end )
    {
        cout << "\n\tWARNING: passing in bad limits to SeqDistanceNT( seq* , seq*, int, int ) "<<beg<<" "<<end<<" "<<len1;
	return -1;    
    }
        
    int nNumDiff = 0;

    for(int i=beg; i < end; i++)
    {
	if( (s1->nt)[i] != (s2->nt)[i] )
	{
	    nNumDiff++;
	}
    }

    return nNumDiff;
}
//

// this function returns an array of statistics on strains that are 'lag' years apart
// the statistics are:   1. mean distance              2. std dev distance 
//                       3. num strains with this lag  4. max distance
//                       5. min distance
// 
// returned array must be freed 
//
// pSeq is the pointer to the array of sequence objects
// N is the total number of strains
double* LagStats( int lag, seq* pSeq, int N )
{

    int nNumPairings = 0;
    int nTotalDistance = 0;
    int i, j;

    double  pdDistArray[1000000];
    double* pd = NULL;

    double* pdReturnArray = NULL;
    double  dMean;
    double  dStdDev;
    double  dMax = ((double) 0 );
    double  dMin = ((double) 200);
    double  dVarSum = ((double) 0);

    pd = pdDistArray;
    pdReturnArray = new double[5];

    assert( lag <= 40 );
  
    for(i = 0; i < N-1; i++)
    {
	for(j = i+1; j < N; j++)
	    {
	        // this removes 2 outlier strains
	        if(i==243||i==244||j==243||j==244)
		{
		  // continue;
		}
	        
		if( abs( pSeq[j].year - pSeq[i].year ) == lag )
		{
		    // the 'false' at the end means we do not ignore gaps
		    // and that gaps are counted as difference
		    // if you put 'true' here, the only nt-diffs where both are non-gap nt are counted
 		    int d = SeqDistanceNT( pSeq+i, pSeq+j, true );
		    if( d == 0 )
		    {
			//printf("\nStrains %d and %d are identical", i, j );
		    }
		    nTotalDistance += d;
		    nNumPairings++;
		    *pd = ((double)d);
		    pd++;
		    assert(nNumPairings < 999995);
		}
	}
    }


    dMean = ((double)nTotalDistance) / ((double)nNumPairings);

    for(i = 0; i < nNumPairings; i++)
    {
	if( pdDistArray[i] > dMax )
	{
   	    dMax = pdDistArray[i];
	}
	if( pdDistArray[i] < dMin )
	{
	    dMin = pdDistArray[i];
	}

	dVarSum += pow( dMean - pdDistArray[i], ((double)2) );
    }

    dStdDev = sqrt( dVarSum / ((double)nNumPairings) );

    pdReturnArray[0] = dMean;
    pdReturnArray[1] = dStdDev;
    pdReturnArray[2] = ((double) nNumPairings); 
    pdReturnArray[3] = dMax;
    pdReturnArray[4] = dMin;

    return pdReturnArray;
}

//
// this function takes an array of N sequences and trims the nt-sequences to
// only show polymorphic sites... all sites that contain gaps (for any sequence)
// are removed.. function returns the new length of the sequences
//
int OnlyPolymorphicSites( seq* pSeq, int N )
{
    assert( pSeq );

    // this is the length we're going to use so they all better have the same length
    int len = pSeq->nt.length();

    // allocate space for the array that holds a bool about whether a particular site
    // is polymorphic or not
    bool* pbPolymorphic = new bool[len];
    int i, j;
    int nNPS=0; // Number Polymorphic Sites

    for(i=0; i < len; i++)
    {
	pbPolymorphic[i] = false;
    }

    
    bool bPolyFlag; // denotes whether a position is polymorphic or not
    
    // i is the index for the sequence position
    for(i=0; i < len; i++)
    {
        char cNT; // this will be the nucleotide at position one
	bPolyFlag = false; 
	
	// j is the index of the sequence in the sequence-array pSeq
	for(j=0; j < N; j++)
	{
	    char c = pSeq[j].nt[i];
	    // if the nucleotide is ambiguous or the site is gapped, do not count it as polymorphic
	    if( c=='R' || c=='Y' || c=='M' || c=='K' || c=='S' || c=='W' || 
		c=='H' || c=='B' || c=='V' || c=='D' || c=='N' || c=='-' )
	    {
	    	bPolyFlag = false;
		break;
	    }
	    
	    if( j == 0 )
	    {
		cNT = c;
	    }
	    else
	    {	
		if( c != cNT )
		{
		    bPolyFlag = true;
		}
	    }
	}
	
	if( bPolyFlag )
	{
	    pbPolymorphic[i] = true;
            nNPS++;
	} 
    }

    //cout << "\nnNPS=" << nNPS << "\n";

    // for each sequence, construct a new string
    for(j=0; j<N; j++)
    {
        string strNTPM("");
	for(i=0;i<len;i++)
	{
	    if( pbPolymorphic[i] )
	    {
	        strNTPM = strNTPM + pSeq[j].nt[i];
	    }
	    else
	    {
		// nothing
	    }
	}
	// cout << "\ntrimmed len is " << strNTPM.length();
	assert( strNTPM.length() == nNPS );
	pSeq[j].nt = strNTPM;	
	// cout << "\ntrimmed len is " << nNPS << " " << pSeq[j].nt.length();
	
    }

    delete[] pbPolymorphic;
    return nNPS;
}


//
// this function takes an array of N sequences and trims the nt-sequences to
// only show polymorphic sites, including gapped sites where there is polymorphisms at
// the non-gapped locations ... it returns the new length of the sequences
//
int OnlyPolymorphicSites2( seq* pSeq, int N, vector<int>* pv_ntmap )
{
    assert( pSeq );

    // this is the length we're going to use so they all better have the same length
    int len = pSeq->nt.length();

    // allocate space for the array that holds a bool about whether a particular site
    // is polymorphic or not
    bool* pbPolymorphic = new bool[len];
    int i, j;
    int nNPS=0; // Number Polymorphic Sites

    for(i=0; i < len; i++)
    {
	pbPolymorphic[i] = false;
    }

    
    bool bPolyFlag; // denotes whether a position is polymorphic or not
    
    // i is the index for the sequence position
    for(i=0; i < len; i++)
    {
        char cNT = '#'; // this will be the nucleotide at position one
	bPolyFlag = false; 
	
	// j is the index of the sequence in the sequence-array pSeq
	for(j=0; j < N; j++)
	{
	    char c = pSeq[j].nt[i];
	    
	    // if the nucleotide is ambiguous or the site is gapped continue looping
	    // until we get to a real nucleotide
	    if( c=='R' || c=='Y' || c=='M' || c=='K' || c=='S' || c=='W' || 
		c=='H' || c=='B' || c=='V' || c=='D' || c=='N' || c=='-' )
	    {
	    	continue;
	    }
	    
	    if( c!='A' && c!='C' && c!='G' && c!='T' )
	    {
	        cerr << "\n\tnucleotide at sequence " << j << " and position " << i << " is " << c << " ascii code: "<< (int)c << "\n\n";
		assert( false );
	    }
	    
	    if( cNT == '#' )  // meaning we haven't assigned anything to the first nt yet
	    {
		cNT = c;
	    }
	    else
	    {	
		if( c != cNT )
		{
		    bPolyFlag = true;
		    break;
		}
	    }
	}
	
	if( bPolyFlag )
	{
	    pbPolymorphic[i] = true;
            nNPS++;
	} 
    }

    //cout << "\nnNPS=" << nNPS << "\n";
    vector<int>::iterator it = pv_ntmap->begin();
    // for each sequence, construct a new string
    for(j=0; j<N; j++)
    {
        string strNTPM("");
	for(i=0;i<len;i++)
	{
	    if( pbPolymorphic[i] )
	    {
	        strNTPM = strNTPM + pSeq[j].nt[i];
	        if(j==0) it++;
	    }
	    else
	    {
		if(j==0) pv_ntmap->erase(it); // automatically increments
	    }
	}
	// cout << "\ntrimmed len is " << strNTPM.length();
	assert( strNTPM.length() == nNPS );
	// assert( pv_ntmap->size() == nNPS );
	pSeq[j].nt = strNTPM;	
	// cout << "\ntrimmed len is " << nNPS << " " << pSeq[j].nt.length();	
    }

    delete[] pbPolymorphic;
    return nNPS;
}



// this function returns an array of statistics on ALL strains 
// the statistics are:   1. mean distance              2. std dev distance 
//                       3. num strains with this lag  4. max distance
//                       5. min distance
// 
// returned array must be freed 
//
// pSeq is the pointer to the array of sequence objects
// N is the total number of strains
double* StrainStats( seq* pSeq, int N )
{

    bool bShowCounter = false;
    if( N > 1400 ) bShowCounter = true;
    
    int nNumPairings = 0;
    double dTotalDistance = ((double)0);
    double dTotalDistanceSumSquares = ((double)0);
    int i, j;

    // careful, this may not be enough
    // right now it's at 4 million which is good enough 
    // for a set with 2000 sequences
    //double*  pdDistArray = NULL;
    //pdDistArray = new double[4000010];

    //assert( N*N/2 < 30000 );

    //double* pd = NULL;

    double* pdReturnArray = NULL;
    double  dMean;
    double  dStdDev;
    double  dMax = ((double) 0 );
    double  dMin = ((double) 1000000);
    double  dVarSum = ((double) 0);

    //pd = pdDistArray;
    pdReturnArray = new double[5];

    if( bShowCounter ) fprintf( stderr, "\n" );
    
    for(i = 0; i < N-1; i++)
    {
      
        if( bShowCounter )
	{
	  fprintf( stderr, "\r\tComputing PWD : %d / %d      ", i+1, N-1 ); fflush(stderr);
	}


	for(j = i+1; j < N; j++)
	{
 		    double d = (double) SeqDistanceNT( pSeq+i, pSeq+j, true );
		    
		    if( d > dMax ) dMax = d;
		    if( d < dMin ) dMin = d;

		    dTotalDistance += d;
		    dTotalDistanceSumSquares += d*d;
		    nNumPairings++;
		    //*pd = ((double)d);
		    //pd++;
		    //assert(nNumPairings < 4000000);
	}
    }

    if( bShowCounter ) fprintf( stderr, "\n" );
    fflush(stderr);
    
    dMean = dTotalDistance / ((double)nNumPairings);
    //cerr << "\n\tTotal Distance is " << dTotalDistance;
    //cerr << "\n\tNum Pairings is " << nNumPairings;
    //cerr << "\n\tMean Distance is " << dMean;  fflush(stderr);
    
    dVarSum = dTotalDistanceSumSquares - (dTotalDistance*dTotalDistance);
    dStdDev = sqrt( dVarSum / ((double)nNumPairings) );

    pdReturnArray[0] = dMean;
    pdReturnArray[1] = dStdDev;
    pdReturnArray[2] = ((double) nNumPairings); 
    pdReturnArray[3] = dMax;
    pdReturnArray[4] = dMin;

    //delete[] pdDistArray;
    
    return pdReturnArray;
}

//
// will first return the number of gapped, monoallelic, biallelic, triallelic, and tetrallelic sites
//
vector<double> GetBasicStats( seq* pSeq, int N )
{
    assert( pSeq );
    vector<double> v;
    v.push_back(0.0); v.push_back(0.0); v.push_back(0.0); v.push_back(0.0); v.push_back(0.0);

    // this is the length we're going to use so they all better have the same length
    int len = pSeq->nt.length();
    int i, j;

    // allocate space for the array that holds an int between 0 to 15 showing which NT are present 1000 = 'A'; 0101 = 'C' and 'T'
    // is polymorphic or not
    int* pnBasesPresent = new int[len];
    for(i=0;i<len;i++) pnBasesPresent[i]=0;

    // i is the index for the sequence position
    for(i=0; i < len; i++)
    {
        //fprintf(stderr,"\n\tinside GetBasicStats( seq* pSeq, int N ), at position %d out of %d", i, len); fflush(stderr);
	// j is the index of the sequence in the sequence-array pSeq
	for(j=0; j < N; j++)
	{
	    char c = pSeq[j].nt[i];
	    
	    // if the nucleotide is ambiguous or the site is gapped continue looping
	    // until we get to a real nucleotide
	    if( c=='R' || c=='Y' || c=='M' || c=='K' || c=='S' || c=='W' || 
		c=='H' || c=='B' || c=='V' || c=='D' || c=='N' || c=='-' )
	    {
	    	continue;
	    }
	    
	    if( c!='A' && c!='C' && c!='G' && c!='T' )
	    {
	        cerr << "\n\tnucleotide at sequence " << j << " and position " << i << " is " << c << " ascii code: "<< (int)c << "\n\n";
		assert( false );
	    }
	    
	    if( c=='A' ) 
	    {
	        if( pnBasesPresent[i]/8 == 0 ) pnBasesPresent[i] += 8;
	    }
	    if( c=='C' ) 
	    {
	        if( (pnBasesPresent[i]/4)%2 == 0 ) pnBasesPresent[i] += 4;
	    }
	    if( c=='G' ) 
	    {
	        if( (pnBasesPresent[i]/2)%2 == 0 ) pnBasesPresent[i] += 2;
	    }
	    if( c=='T' ) 
	    {
	        if( pnBasesPresent[i]%2 == 0 ) pnBasesPresent[i] += 1;
	    }
	}
    }

    // i is the index for the sequence position
    for(i=0; i < len; i++)
    {
        int numBasesPresent=0;
        if( pnBasesPresent[i]/8 == 1 )     numBasesPresent++;
        if( (pnBasesPresent[i]/4)%2 == 1 ) numBasesPresent++;
        if( (pnBasesPresent[i]/2)%2 == 1 ) numBasesPresent++;
        if( pnBasesPresent[i]%2 == 1 )     numBasesPresent++;
        
        v[numBasesPresent] += 1.0;
    }

    return v;
}
