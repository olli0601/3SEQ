#include <iostream>
#include <string>
#include <cstdlib>

#include "seq.h"
#include "gene.h"


// constructor
seq::seq()
{
    // initializes the string of nucleotides to the empty string
    nt = "";
    aa = "";
    ntfull = "";
    poly_to_full = NULL;
    recombinant = false;
    recombinant_and_is_long = false;
    marked_for_deletion = false;
    had_neighbor_deleted = false;

    best_parent1_index = -1;	
    best_parent2_index = -1;
    best_m             = -1;
    best_n             = -1;
    best_md            = -1;
    best_pvalue        = 2.0;
    best_hs            = false;
    best_bounds.max    = 2.0;
    best_bounds.min    = 2.0;
    match_distance_to_target = -1;
}

// destructor
seq::~seq()
{
    if( poly_to_full )
    {
        delete[] poly_to_full;
    }
}


void seq::makeAAfromNT()
{
    int ntLen = nt.length();
    int aaLen = ntLen/3;

    if( aaLen*3 != ntLen )
    {
        cout << "\nWARNING: nucleotide sequence not a multiple of 3 (" << ntLen << ")";
    }

    for(int i=0; i < aaLen; i++)
    {
	string str = nt.substr( 3*i, 3);
	// char* sz = str.c_str();
	CODON cdn = StringToCodon( (char*) str.c_str() );
	aa += AAL( cdn );
    }
    
    return;
}
