//
// Copyright (c) 2006-2008  Maciej F. Boni.  All Rights Reserved.
//
#include "seq.h"

enum filetype {no_filetype, phylip, nexus, fasta}; 
typedef enum filetype FILETYPE;


int NumSequences( FILE* DataFile, char cDelim='>' );
void ReadNextSequence_01( FILE* DataFile, seq* p );
void ReadNextSequence_02( FILE* DataFile, seq* p );
void ReadNextSequence_03( FILE* DataFile, seq* p );
bool isnt( char c );

// this function is a wrapper for the two readline functions below
// it determines the format of the input file and callse on of 
// ReadAlignmentIL(..) and ReadAlignmentNINL(..)
seq* ReadAlignment( char* szFilename, int* pnNumSeq, int* pnLen );

// this reads in alignment files that are output by clustal 
// it allocates memory for the sequence array and returns
// a pointer to the first sequence
//
// interleaved files
seq* ReadAlignmentIL( FILE* DataFile, int* pnNumSeq, int* pnLen );
//
// non-interleaved, with newline after sequence name
seq* ReadAlignmentNINL( FILE* DataFile, int* pnNumSeq, int* pnLen );

//
// this is for reading a file that contains accession numbers
// and stripping down the data set to only those sequences with 
// the listed accession numbers
//
// the input file should have the accession numbers separated 
// by whitespace
seq* ReadAccessionNumberFile( string strFilename, seq* pSeq, int* pnNumSeq, bool cut );

int GetIndexByAccNum( seq* pSeq, int N, string acc );

//
// everything below here is April 2009 and after
// these are the new functions for reading in files
//

bool is_integer( char* sz );
bool is_integer( const char* sz );
void capitalize( string& str );
bool all_chars_are_nt( string str );
int replace_ambig_nt_with_gaps( string& str );
FILETYPE GetFiletype( char* szFilename );
seq* ReadPhylipFile( char* szFilename, int* pnNumSeq, int* pnLen, int* num_ambig );
seq* ReadFastaFile( char* szFilename, int* pnNumSeq, int* pnLen, int* num_ambig );
string trim_all_ws( string str );
string trim_end_ws( string str );
