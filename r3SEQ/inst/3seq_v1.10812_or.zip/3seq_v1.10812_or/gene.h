//
// Copyright � 2006 Maciej F. Boni.  All Rights Reserved.
//
#include <math.h>
#include <iostream>
#include <ctype.h>
#include <assert.h>
#include <vector>
#include "seq.h"

enum nucleotide {A, C, G, T, N}; // the 'N' means an unknown nucleotide
typedef enum nucleotide NUCTIDE;

enum aminoacid {Alanine, Arginine, Asparagine, AsparticAcid, Cysteine,
                GlutamicAcid, Glutamine, Glycine, Histidine, Isoleucine,
		Leucine, Lysine, Methionine, Phenylalanine, Proline,
		Serine, Threonine, Tryptophan, Tyrosine, Valine, Stop};
typedef enum aminoacid AMINOACID;


struct codon
{
    NUCTIDE pos1;
    NUCTIDE pos2;
    NUCTIDE pos3;
};
typedef struct codon CODON;

// triple for a maximum descent (or a maximum height -- just put the height in the 'md' field)
struct mdtriple
{
    int m;
    int n;
    int md;
    int p; // these last three are the indices of the three parents (in some array) for this triple
    int q;
    int c;
    bool must_approximate;
};
typedef struct mdtriple MDTRIPLE;



/**** FUNCTION DECLARATIONS ****/


CODON StringToCodon( char* szCodon );
int F( int input );
AMINOACID AA( CODON cdn );
char AAL( CODON cdn );
int NonSynChanges( CODON cdn );
int NumSeqsPerYear( int nYear, seq* pSeq, int nArraySize );
int SeqDistanceNT( seq* s1, seq* s2, bool ignore_gaps=false );
int SeqDistanceNT( seq* s1, seq* s2, int beg, int end ); // gets the distance between two sub-sequences
int SeqDistanceAA( seq* s1, seq* s2 );
void AssertCodon( CODON cdn );
double* LagStats( int lag, seq* pSeq, int N );
int OnlyPolymorphicSites( seq* pSeq, int N ); 	// removes all sites that contain gaps or are completely identical
int OnlyPolymorphicSites2( seq* pSeq, int N, vector<int>* pv_ntmap );	// removes all sites that are identical
double* StrainStats( seq* pSeq, int N );
vector<double> GetBasicStats( seq* pSeq, int N );
