//
// Copyright (c) 2006-08 Maciej F. Boni.  All Rights Reserved.
//
#include <iostream>
#include <fstream>
#include <string>
#include <ctime>
#include <dirent.h>
#include <cstdlib>
#include "ProbTables.h"

#ifndef PI
#define PI 3.141592653589793238462643
#endif

string G_PVALUETABLE_DIR( HARD_CODED_PATH_FOR_PVALUETABLES );


//
//
//
// ytable 
//
//
//

// constructor
ytable::ytable( void )
{
    cout << "\n\tWARNING: calling ytable constructor without arguments.. exiting.\n\n";
    exit(-1);
}

// constructor
//
// to calculate y_{40,30,20,10} pass in (41,31,21,11)
//
ytable::ytable( int mMax, int nMax, int kMax, int jMax )
{
        
    //cout << "\ninside ytable constructor\n";
    if( mSize != -1 )
    {
        cout << "\n\talready constructed the ytable..don't do it again! .. exiting..\n";
        exit(-1);
    }

    //
    // only the generate_x_table executable should set this to true and override the
    // hard limit set in the code
    //
    if( override_hardlimit==false )
    {
        if( ((double)mMax)*((double)nMax)*((double)kMax)*((double)jMax) > ((double)HARDLIMIT)  || mMax*nMax*kMax*jMax <= 0 )
        {
            cout << "\n\tPre-processor defined HARDLIMIT in your code is set to " << HARDLIMIT;
            cout << "\n\tTable size " << mMax*nMax*kMax*jMax << " is too large .. exiting..\n\n";
            exit(-1);    
        }
    }

    mSize = (mMax>0)?mMax:1;
    nSize = (nMax>0)?nMax:1;
    kSize = (kMax>0)?kMax:1;
    jSize = (jMax>0)?jMax:1;
    quiet = true;
    override_hardlimit = false;

    metatable = new float* [ mSize*nSize ];
    
    // now populate the array with NULLs, meaning that the table for
    // hypergeometric walk (m,n) has not been built yet.
    int m, n;
    for(m=0;m<mSize;m++)
        for(n=0;n<nSize;n++)
        {
            metatable[ m*nSize + n ] = NULL;
        }
}

void ytable::reallocate_space( int mMax, int nMax, int kMax, int jMax )
{
    int m, n;
    if( metatable != NULL )
    {
        for(m=0;m<mSize;m++)
        {
            for(n=0;n<nSize;n++)
            {
                if( metatable[ m*nSize + n ] != NULL )
                {
                    delete[] metatable[ m*nSize + n ];
                    metatable[ m*nSize + n ] = NULL;		// ADDED 08-05-2008
                }
            }
        }
        delete[] metatable;
    }

    nNumAllocatedInMeta=0;

    if( mMax*nMax*kMax*jMax > HARDLIMIT  || mMax*nMax*kMax*jMax <= 0 )
    {
        cout << "\n\tPre-processor defined HARDLIMIT in your code is set to " << HARDLIMIT;
        cout << "\n\tTable size " << mMax*nMax*kMax*jMax << " is too large .. exiting..\n\n";
        exit(-1);
    }

    mSize = (mMax>0)?mMax:1;
    nSize = (nMax>0)?nMax:1;
    kSize = (kMax>0)?kMax:1;
    jSize = (jMax>0)?jMax:1;

    metatable = new float* [ mSize*nSize ];    
    
    // now populate the array with NULLs, meaning that the table for
    // hypergeometric walk (m,n) has not been built yet.
    for(m=0;m<mSize;m++)
    {
        for(n=0;n<nSize;n++)
        {
            metatable[ m*nSize + n ] = NULL;
        }
    }
}

// this is for p-values, not probabilities
bool ytable::can_compute_exact_pvalue( int m, int n, int k )
{
    // if k > n, the pvalue is always zero (you should never get this though)
    if( k > n ) 
    {
        if( !quiet ) cout << "\n\tCalling ytable::can_compute_exact_pvalue(..) with k > n.  This should never happen.\n";
        return true;
    }
    
    // in this case the p-value will be one
    if( n > 0 && k == 1 ) return true;
    
    // in this case the p-value will be one
    if( n - m == k ) return true;
    
    if( m < mSize && n < nSize && k < kSize && n < kSize && n < jSize ) return true;
    
    return false;
}

// this is for p-values, not probabilities
bool ytable::can_approximate_pvalue( int m, int n, int k )
{
    // if k > n, the pvalue is always zero (you should never get this though)
    if( k > n ) 
    {
        if( !quiet ) cout << "\n\tCalling ytable::can_approximate_pvalue(..) with k > n.  This should never happen.\n";
        return true;
    }
    
    // in this case the p-value will be one (it can be computed exactly)
    if( n > 0 && k == 1 ) return true;
    
    // in this case the p-value will be one (it can be computed exactly)
    if( n - m == k ) return true;
    
    // you should ALWAYS have jSize>=kSize; (usually jSize==kSize); this is optimal
    if( m < mSize && n < nSize && k < kSize && kSize<=jSize ) return true;
    
    return false;
}

// this is for p-values, not probabilities
float ytable::compute_exact_pvalue( int m, int n, int k )
{
    assert( k>=0 && m>=0 && n>=0 );
    
    // if k > n, the pvalue is always zero (you should never get this though)
    if( k > n ) 
    {
        if( !quiet ) cout << "\n\tCalling ytable::compute_exact_pvalue(..) with k > n.  This should never happen.\n";
        return (float(0));
    }
    
    // in these casea the p-value will be one
    if( m == 0 ) return ((float)1);		// here, you must have k<=n, otherwise you would have returned above
    if( n == 0 ) return ((float)1);		// here, you must have k==0, otherwise you would have returned above
    if( k == 0 || k == 1 ) return ((float)1);	// here, you must have n>0,  otherwise you would have returned above

    // in this case the p-value will be one
    //
    // 06-30-2008: double check this; it seems that this if statement
    // should read if( n - m >= k )
    //
    // 07-29-2008: changed this so that it no longer reads if( n - m == k )
    if( n - m >= k ) return ((float)1);
    
    // in this case, we can compute an exact p-value
    if( m < mSize && n < nSize && k < kSize && n < kSize && n < jSize ) 
    {
        float dPValue = ((float)0);
        int ii;
        for(ii = k; ii <= n; ii++)
        {
            dPValue += prob_max_descent( m, n, ii );
        }
        return dPValue;
    }
    
    assert( false ); // should never get here
    return ((float)-1);
}

BOUNDS ytable::approximate_pvalue( int m, int n, int k )
{
    double dPValMin = ((double)0);
    double dLast = ((double)0);
    int ii;
    for(ii = k; ii < kSize; ii++)
    {
        double d = (double) prob_max_descent( m, n, ii );
        dPValMin += d;
        if( ii == kSize-1 ) dLast = d;
    }
    
    int nNumMissing = n - (kSize-1);
    double dPValMax = dPValMin + ((double)nNumMissing)*dLast;

    BOUNDS bnds;
    bnds.min = dPValMin;
    bnds.max = dPValMax;
    return bnds;    
}

float ytable::prob_max_descent(int m, int n, int k)
{
    // this is the return value
    float d;
    
    if( k > n || k < n-m )
    {
        d = ((float)0);
        //cout << "\nxtable::prob( " <<m<< ", " <<n<< ", " <<k<< " ) = " <<d;
        return d;
    }

    // boundary cases
    if( k==0 && n==0 ) return ((float)1);
    if( k==0 && n>0 )  return ((float)0);
    if( m==0 && k==n ) return ((float)1);
    if( m==0 && k!=n ) return ((float)0);
    if( n==0 && k>0 )  return ((float)0);
    
    // k can be bigger than sizeK, this is taken care of above
    if( m<0 || n<0 || k<0 )
    {
        // -2 is an error code
        d = ((float)-2);
        cout << "\n\tERROR: negative values passed in to xtable::prob(..)\n";
        //cout << "\nxtable::prob( " <<m<< ", " <<n<< ", " <<k<< " ) = " <<d;
        return d;
    }
    
    float dSum = ((float)0);
    for(int j=0; j<=k; j++)
    {
        dSum += prob(m,n,k,j);
    }

    return dSum;
}

//
// this is John Zollweg's innovation on keeping the table small 
// and still doing calculations
//
void ytable::prune_metatable( int m )
{
    int n;
    if( metatable != NULL )
    {
        for(n=0;n<nSize;n++)
        {
            if( metatable[ m*nSize + n ] != NULL )
            {
                delete[] metatable[ m*nSize + n ];
                metatable[ m*nSize + n ] = NULL;
                nNumAllocatedInMeta--;
            }
        }
    }
}


// destructor
ytable::~ytable( )
{
    int m, n;
    if( metatable != NULL )
    {
        for(m=0;m<mSize;m++)
        {
            for(n=0;n<nSize;n++)
            {
                if( metatable[ m*nSize + n ] != NULL )
                {
                    delete[] metatable[ m*nSize + n ];
                    metatable[ m*nSize + n ] = NULL;		// ADDED 08-05-2008
                }
            }
        }

        delete[] metatable;
    }

    nNumAllocatedInMeta=0;
    //cout << "\ndesctructor called...\n\n";
}

float ytable::prob(int m, int n, int k, int j)
{
    //cout << "\nytable::prob( " <<m<< ", " <<n<< ", " <<k<< ", " <<j<< " )";
 
    // this is the return value;
    float d = ((float)-1); 
      
    if( j > k )
    {
        d = ((float)0);
        //cout << "\nytable::prob( " <<m<< ", " <<n<< ", " <<k<< ", " <<j<< " ) = " <<d;
        return d;
    }
    if( k > n || k < n-m || j > n || j < n-m )
    {
        d = ((float)0);
        //cout << "\nytable::prob( " <<m<< ", " <<n<< ", " <<k<< ", " <<j<< " ) = " <<d;
        return d;
    }
    if( n == 0 )
    {
        if( k==0 && j==0 )
        {
            d = ((float)1);
            //cout << "\nytable::prob( " <<m<< ", " <<n<< ", " <<k<< ", " <<j<< " ) = " <<d;
            return d;
        }
        else
        {
            d = ((float)0);
            //cout << "\nytable::prob( " <<m<< ", " <<n<< ", " <<k<< ", " <<j<< " ) = " <<d;
            return d;
        }
    }
    if( m == 0 )
    {
        if( k==n && j==n ) 
        {
            d = ((float)1);
            //cout << "\nytable::prob( " <<m<< ", " <<n<< ", " <<k<< ", " <<j<< " ) = " <<d;
            return d;
        }
        else
        {
            d = ((float)0);
            //cout << "\nytable::prob( " <<m<< ", " <<n<< ", " <<k<< ", " <<j<< " ) = " <<d;
            return d;
        }
    }
    if( k == 0 && j == 0 )
    {
        if( n==0 )
        {
            d = ((float)1);
            //cout << "\nytable::prob( " <<m<< ", " <<n<< ", " <<k<< ", " <<j<< " ) = " <<d;
            return d;
        }
        else
        {
            d = ((float)0);
            //cout << "\nytable::prob( " <<m<< ", " <<n<< ", " <<k<< ", " <<j<< " ) = " <<d;
            return d;
        }
    }
    
    float* T = NULL;
    int a,b;
    
    if( metatable[ m*nSize + n ] == NULL )
    {
        metatable[ m*nSize + n ] = new float[ jSize*kSize ];
        T = metatable[ m*nSize + n ];
    
        // now fill it up with (-1)s
        for(a=0; a < kSize; a++)
            for(b=0; b < jSize; b++ )
            {
                T[ jSize*a + b ] = ((float)-1);
            }
        
        // and make sure you record that you have allocated memory for 
        // another pointer in the metatable
        nNumAllocatedInMeta++;
    }
    else
    {
        T = metatable[ m*nSize + n ]; 
    }
    
    // if it's in the table, just return it
    if( T[ jSize*k + j ] >= ((float)0) )
    {
        d = T[ jSize*k + j ];
        //cout << "\nytable::prob( " <<m<< ", " <<n<< ", " <<k<< ", " <<j<< " ) = " <<d;
        return d;
    }
    
    // if we didn't find it in the table, then we need to calculate it
    float dN = ((float)n);
    float dM = ((float)m);
    
    if( j == 0 )
    {
        d = (dM/(dN+dM))*( prob(m-1,n,k,1) + prob(m-1,n,k,0) );
        T[ jSize*k + j ] = d;
        //return d;
    }
    
    if( j > 0 )
    {
        if( k == j )
        {
            d = (dN/(dN+dM))*( prob(m,n-1,j-1,j-1) + prob(m,n-1,j,j-1) );
            T[ jSize*k + j ] = d;
            //return d;
        }
    
        if( k > j )
        {
            d = (dM/(dN+dM))*prob(m-1,n,k,j+1) + (dN/(dN+dM))*prob(m,n-1,k,j-1);
            T[ jSize*k + j ] = d;
            //return d;
        }
    }
    
    //cout << "\nytable::prob( " <<m<< ", " <<n<< ", " <<k<< ", " <<j<< " ) = " <<d;
    return d;    
}






// **************************************************************
//
//
//
//
//           pvaluetable CLASS
//
//
//
//
// **************************************************************






// constructor
pvaluetable::pvaluetable( void )
{
    if( size != -1 )
    {
        cout << "\n\talready constructed an instance of pvaluetable .. do not do this twice .. exiting ..\n";
        exit(-1);
    }

    DIR* localdir = opendir( G_PVALUETABLE_DIR.c_str() );
    if( localdir == NULL )
    {
        cerr << "\n\tCannot open the directory:\n\n\t\t" << G_PVALUETABLE_DIR << "\n\n\tPlease check that there are no typographical errors in the directory name.\n\n";
        return;
    }
    else
        cout << "\n\tOpen directory:" << G_PVALUETABLE_DIR << "\n";
    
    string strFileNameWithPath;
    int nNumMegsRAM;
    
    while( true )
    {
        // read the next file from the list of files in `localdir'
        struct dirent* pSD = readdir( localdir );
        
        if( pSD==NULL )
        {
            cerr << "\n\tA file whose name starts with PVT_BINARY_ could not be found in the directory:\n\n\t\t" << G_PVALUETABLE_DIR << "\n\n";
            break;
        }
        // put this filename into a string
        string strFilename( pSD->d_name );
        //cerr << "\n\tFilename is " << strFilename;
        
        // now check that the filename has at least 12 characters
        // because you want to identify file names like PVT_BINARY_###
        if( strFilename.length() < 12 ) continue;
        
        // if this is true, this is the file we will use
        if( strFilename.substr(0,11) == "PVT_BINARY_" )
        {
            int len = strFilename.length();
            strFileNameWithPath = G_PVALUETABLE_DIR + strFilename;

            // this determines the table size that will be built
            pvaluetable::size = 1 + atoi( strFilename.substr(11,len-11).c_str() );
            float f = (float) size;

            char ans;
            nNumMegsRAM = (int)( (4.0*f*f*f)/(1048576.0) + 1.0);
            if( nNumMegsRAM > 4*(HARDLIMIT/1048576) )
            {
                cout << "\n\tPre-processor defined HARDLIMIT in your code is set to " << HARDLIMIT;
                cout << "\n\tThis means you can use a max " << 4*(HARDLIMIT/1048576) << " megabytes of memory.  Exiting.\n\n";
                exit(-1);    
            }   

            cerr << "\n\tUsing file " << strFilename << " to generate p-values.\n\tThis will require " << nNumMegsRAM << " megabytes of memory.";
            cerr << "\n\n\tIs this OK (y/N)?  ";
	    cin >> ans;
	    if( ans != 'y' )
	    {
	        cerr << "\n\tGoodbye.\n\n";
	        closedir( localdir );
	        exit(-1);
	    }

            break;
        }
    }

    closedir( localdir );

    // only go in this block if a PVALUE_TABLE file was found
    if( pvaluetable::size != -1 )
    {
        assert( table==NULL );
        int M = pvaluetable::size;
        table = new float [ size*size*size ];
    
        cerr << "\n\tReading table.  If you are not using SWAP space, this can take\n\tas long as "<<1+nNumMegsRAM/30<<" seconds on a 2 GHz processor."; fflush(stderr);
        
        fstream binary_file( strFileNameWithPath.c_str() , ios::binary|ios::in );
        binary_file.read( reinterpret_cast<char *>(table) , (M+1)*(M+1)*(M+1)*sizeof(float) );
        binary_file.close();
        cerr << "  Finished.\n";
    }
} 

// destructor
pvaluetable::~pvaluetable( )
{
    if(table != NULL )
    {
        // 08-06-2008 ******* POTENTIAL MEMORY LEAK **********
        // should we comment out below?  are static arrays freed in class destructor?
        delete[] table;
    }

    // 08-06-2008 ******* POTENTIAL MEMORY LEAK **********
    // should we comment out below?  are static arrays freed in class destructor?
    table = NULL;
}


bool pvaluetable::can_get_pvalue(int m, int n, int k)
{
    // if k > n, the pvalue is always zero (you should never get this though)
    if( k > n ) 
    {
        if(!quiet) cout << "\n\tCalling pvaluetable::can_get_pvalue(..) with k > n.  This should never happen.\n";
        return true;
    }
    
    // in this case the p-value will be one
    if( n > 0 && k == 1 ) return true;
    
    // in this case the p-value will be one
    if( n - m >= k ) return true;
    
    if( m < size && n < size && k < size ) return true;
    
    return false;
}

double pvaluetable::get_pvalue(int m, int n, int k)
{
    if( size <= 0 )
    {
        cerr << "\n\tCannot call member function pvaluetable::pvalue because an instance of the class pvaluetable has not yet been created\n\n.";
        exit(-1);
    }
    
    // if k > n, the pvalue is always zero (you should never get this though)
    if( k > n ) 
    {
        if(!quiet) cout << "\n\tCalling pvaluetable::get_pvalue(..) with k > n.  This should never happen.\n";
        return ((double)0);
    }
    
    // in this case the p-value will be one
    if( n > 0 && k == 1 ) return ((double)1);
    
    // in this case the p-value will be one
    if( n - m >= k ) return ((double)1);
    
    if( m < size && n < size && k < size ) return ( (double) table[size*size*m + size*n + k] );
    
    return ((double)-1);

}


// **************************************************************
//
//
//
//
//           pvaluetable_compact CLASS
//
//
//
//
// **************************************************************






// constructor
pvaluetable_compact::pvaluetable_compact( void )
{
    if( size != -1 )
    {
        cout << "\n\talready constructed an instance of pvaluetable_compact .. do not do this twice .. exiting ..\n";
        exit(-1);
    }

    DIR* localdir = opendir( G_PVALUETABLE_DIR.c_str() );
    if( localdir == NULL )
    {
        cerr << "\n\tCannot open the directory:\n\n\t\t" << G_PVALUETABLE_DIR << "\n\n\tPlease check that there are no typographical errors in the directory name.\n\n";
        return;
    }
    
    string strFileNameWithPath;
    int nNumMegsRAM;
    int m,n,k;
    
    while( true )
    {
        // read the next file from the list of files in `localdir'
        struct dirent* pSD = readdir( localdir );
        
        if( pSD==NULL )
        {
            cerr << "\n\tA file whose name starts with PVT_COMPACT_ could not be found in the directory:\n\n\t\t" << G_PVALUETABLE_DIR << "\n\n";
            break;
        }
        // put this filename into a string
        string strFilename( pSD->d_name );
        //cerr << "\n\tFilename is " << strFilename;
        
        // now check that the filename has at least 13 characters
        // because you want to identify file names like PVT_COMPACT_###
        if( strFilename.length() < 13 ) continue;
        
        // if this is true, this is the file we will use
        if( strFilename.substr(0,12) == "PVT_COMPACT_" )
        {
            int len = strFilename.length();
            strFileNameWithPath = G_PVALUETABLE_DIR + strFilename;

            // this determines the table size 
            pvaluetable_compact::size = 1 + atoi( strFilename.substr(12,len-12).c_str() );
            int M = pvaluetable_compact::size;
            index_array = new int [ M*M ];
            for(m=0;m<M;m++)
                for(n=0;n<M;n++)
                    index_array[m*M+n] = -1;

            // now calculate how much space will be needed for this table
            int i = 0;
            //BEGIN "COUNT LOOP"
            for(m=1; m<M; m++)
                for(n=1; n<M; n++)
                {
                    index_array[m*M+n] = i;
                    for(k=1; k<M; k++)
                        if( k > n-m && k <= n ) i++; // this that the pvalue is in the table
                }
            //END "COUNT LOOP"

            // assign this count to table_len
            table_len = i;
            //cout << "\n\t" << M << " " << table_len << "\n";

            char ans;
            nNumMegsRAM = (int)( (4.0*((float)table_len))/(1048576.0) + 1.0);
            if( nNumMegsRAM > 4*(HARDLIMIT/1048576) )
            {
                cout << "\n\tPre-processor defined HARDLIMIT in your code is set to " << HARDLIMIT;
                cout << "\n\tThis means you can use a max " << 4*(HARDLIMIT/1048576) << " megabytes of memory.  Exiting.\n\n";
                exit(-1);    
            }   
            /*
            if( !quiet )
            {
                cerr << "\n\tUsing file " << strFilename << " to generate p-values.\n\tThis will require " << nNumMegsRAM << " megabytes of memory.";
                cerr << "\n\n\tIs this OK (y/N)?  ";
                cin >> ans;
                if( ans != 'y' )
                {
                    cerr << "\n\tGoodbye.\n\n";
                    closedir( localdir );
                    exit(-1);
                }
            }*/
            break;
        }
    }

    closedir( localdir );

    // only go in this block if a PVT_COMPACT_ file was found
    if( pvaluetable_compact::size != -1 )
    {
        assert( table==NULL );
        if( !quiet )
        {
            cerr << "\n\tReading table from "<<strFileNameWithPath.c_str()<<"\n\tThis should not take more than 30 seconds."; fflush(stderr);
        }
        table = new float[table_len];
        fstream binary_file( strFileNameWithPath.c_str() , ios::binary|ios::in );
        binary_file.read( reinterpret_cast<char *>(table) , table_len*sizeof(float) );
        binary_file.close();
        if( !quiet ) { cerr << "  Finished.\n"; fflush(stderr); }
    }
    
}

// destructor
pvaluetable_compact::~pvaluetable_compact( )
{
    if(table != NULL )
    {
        // 08-06-2008 ******* POTENTIAL MEMORY LEAK **********
        // should we comment out below?  are static arrays freed in class destructor?
        delete[] table;
    }
    if(index_array != NULL )
    {
        // 08-06-2008 ******* POTENTIAL MEMORY LEAK **********
        // should we comment out below?  are static arrays freed in class destructor?
        delete[] index_array;
    }

    // 08-06-2008 ******* POTENTIAL MEMORY LEAK **********
    // should we comment out below?  are static arrays freed in class destructor?
    table = NULL;
    index_array = NULL;
}


bool pvaluetable_compact::can_get_pvalue(int m, int n, int k)
{
    if( k<0 || m<0 || n<0 ) return false;

    // if k > n, the pvalue is always zero (you should never get this though)
    if( k > n ) 
    {
        if(!quiet) cout << "\n\tCalling pvaluetable_compact::can_get_pvalue(..) with k > n.  This should never happen.\n";
        return true;
    }
    
    if( m==0 || n==0 || k==0 ) return true;
    if( n-m >= k ) return true;
    if( k == 1 ) return true;
    
    if( m < size && n < size && k < size ) return true;
    
    return false;
}

double pvaluetable_compact::get_pvalue(int m, int n, int k)
{
    assert( k>=0 && m>=0 && n>=0 );
    if( size <= 0 )
    {
        cerr << "\n\tCannot call member function pvaluetable_compact::pvalue because an instance of the class pvaluetable has not yet been created\n\n.";
        exit(-1);
    }
    
    double dOne = ((double)1);
    double dZero = ((double)0);
    
    // if k > n, the pvalue is always zero (you should never get this though)
    if( k > n ) 
    {
        if(!quiet) cout << "\n\tCalling pvaluetable::get_pvalue(..) with k > n.  This should never happen.\n";
        return dZero;
    }
    
    if( m==0 || n==0 || k==0 ) return dOne;
    if( n-m >= k ) return dOne;
    if( k == 1 ) return dOne;

    
    if( m < size && n < size && k < size ) 
    {
        // compute index in the member array `table'
        int mn_index = index_array[m*size+n];
        int k_index=0;
        int num_k_indices;

        assert( mn_index >= 0 );

        if( n-m >= 1 ) 
        {
            num_k_indices = m;
            k_index = k+m-n-1; // this is k - (n-m) - 1
        }
        else 
        {
            num_k_indices = n;
            k_index = k-1;
        }
        
        //fprintf(stderr,"\n\tmn_index=%d, k_index=%d, table_len=%d", mn_index, k_index, table_len);
        assert( mn_index+k_index < table_len );
        double pvalue = table[ mn_index + k_index ];
        assert(pvalue >= 0.0);
        return pvalue;
    }
    
    return ((double)-1);
}


bool pvaluetable_compact::validate( void )
{
    float x1 = -1.0;
    float x2 = -1.0;
    float x3 = -1.0;
    float x4 = -1.0;
    
    bool bValid = true;
    float pv, preal, diff, tol;
    tol = 1e-6;
    
    if( can_get_pvalue(140,140,50) )
    {
        pv = get_pvalue(140,140,50);
	preal = 3.45760355e-7;
	diff = (pv/preal) - 1.0;
	//fprintf( stderr, "\n\tPVT VALIDATION  -  %1.5e \t %1.5e \t %1.5e", pv, preal, diff); fflush(stderr);
	if( fabs(diff) > tol ) bValid = false;
    }
    if( can_get_pvalue(110,120,30) )
    {
        pv = get_pvalue(110,120,30);
	preal = 4.37400043e-2;
	diff = (pv/preal) - 1.0;
	//fprintf( stderr, "\n\tPVT VALIDATION  -  %1.5e \t %1.5e \t %1.5e", pv, preal, diff); fflush(stderr);
	if( fabs(diff) > tol ) bValid = false;
    }
    if( can_get_pvalue(90,90,80) )
    {
        pv = get_pvalue(90,90,80);
	preal = 6.39697368e-36;
	diff = (pv/preal) - 1.0;
	//fprintf( stderr, "\n\tPVT VALIDATION  -  %1.5e \t %1.5e \t %1.5e", pv, preal, diff); fflush(stderr);
	if( fabs(diff) > tol ) bValid = false;
    }
    if( can_get_pvalue(160,160,120) )
    {
        pv = get_pvalue(160,160,120);
	preal = 1.52181013e-42;
	diff = (pv/preal) - 1.0;
	//fprintf( stderr, "\n\tPVT VALIDATION  -  %1.5e \t %1.5e \t %1.5e", pv, preal, diff); fflush(stderr);
	if( fabs(diff) > tol ) bValid = false;
    }
    
    return bValid;
}




//
//
//BEGIN APPROX CLASS
//
//

// constructor
approx::approx( void )
{
    return;
}

// destructor
approx::~approx( void )
{
    return;
}

double approx::hogansiegmund86_thrm2(int m, int n, int k)
{
    // this is the k you actually want to use because the inequality
    // in the Hogan-Siegmund theorem is strict, but we want "greater than or equal to"
    double kk  = (double)(k - 1);
    double mpn = (double)(m + n);
    
    // expressions below are just for shortcuts
    double A = (double)(2*kk - n + m);
    double B = (double)(kk - n + m);
    
    double rho = 0.583;
    
    double pvalue =  (2.0*A*B/mpn) * exp( (-4.0*rho*A - 2.0*kk*B)/mpn );
    
    return pvalue;
}

double approx::siegmund_continuous(int m, int n, int k)
{
    double MM = (double)(m + n);
    double b  = ((double)k) - 0.5;
    double xi = (double)(n - m);
    
    double p1 = exp(-2.0*b*(b-xi)/MM);
    
    double p2 = p1*(2.0*(2.0*b-xi)*(b-xi)/MM + 1.0);
    
    return (1.0-exp(-p2));
}

double approx::siegmund_discrete(int m, int n, int k)
{
    double MM = (double)(m + n);
    double b  = ((double)k) - 0.5;
    double xi = (double)(n - m);
    
    double p1 = exp(-2.0*b*(b-xi)/MM);
    
    double p2 = p1*(2.0*(2.0*b-xi)*(b-xi)/MM + 1.0);

    double NU = approx::nu( 2.0*(2.0*b - xi)/MM );
    
    double p3 = NU*NU*p2;
    return (1.0 - exp(-p3));
}

double approx::normpdf(double x)
{
    return ( 1.0 / sqrt(2.0*PI) )*exp( -0.5*x*x );
}

double approx::nu(double x)
{
    return ( (approx::normcdf(x/2.0)-.5)*2.0 ) / x / ( approx::normpdf(x/2.0) + (x*approx::normcdf(x/2.0)) / 2.0);
}

double approx::normcdf(double x)
{
  //if( x >  6.0 ) return 1.0;
  //if( x < -6.0 ) return 0.0;
  
  const double b1 =  0.319381530;
  const double b2 = -0.356563782;
  const double b3 =  1.781477937;
  const double b4 = -1.821255978;
  const double b5 =  1.330274429;
  const double p  =  0.2316419;
  const double c  =  0.39894228;

  if(x >= 0.0) 
  {
      double t = 1.0 / ( 1.0 + p * x );
      return (1.0 - c * exp( -x * x / 2.0 ) * t *
      ( t *( t * ( t * ( t * b5 + b4 ) + b3 ) + b2 ) + b1 ));
  }
  else 
  {
      double t = 1.0 / ( 1.0 - p * x );
      return ( c * exp( -x * x / 2.0 ) * t * ( t *( t * ( t * ( t * b5 + b4 ) + b3 ) + b2 ) + b1 ));
  }
}

