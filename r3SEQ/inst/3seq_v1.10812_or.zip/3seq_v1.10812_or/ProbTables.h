//------------------------------------------------------
//
// Copyright (c) 2006-08 Maciej F. Boni.  All Rights Reserved.
//
// ProbTables.h -- header file for the classes that maintain
//                 the probability tables for xrun mode
//                 and quickrun mode
//
//------------------------------------------------------
#ifndef PROBTABLES
#define PROBTABLES

#include <assert.h>
#include <math.h>

// this lets program use a max of 2.5GB of RAM + SWAP       
// #define HARDLIMIT 624999000     

// this lets program use a max of 1.6GB of RAM + SWAP       
// #define HARDLIMIT 400000000     

// this lets program use a max of 4.0GB of RAM + SWAP       
#define HARDLIMIT 999999000      

#ifdef PVT
    #define HARD_CODED_PATH_FOR_PVALUETABLES PVT
#else
    #define HARD_CODED_PATH_FOR_PVALUETABLES "/home/lyapunov/PVALUETABLES/"
#endif

using namespace std;

//string G_PVALUETABLE_DIR("/home/lyapunov/PVALUETABLES/");

// a pair of floating point bounds for a p-value
struct bounds
{
    float min;		// 12/07/2008: this was changed from double to float to comply
    float max;		// with other p-value calculations in the ytable class
};
typedef struct bounds BOUNDS;


class ytable
{   
public:
    ytable( );                 // constructor    
    ytable( int mMax, int nMax, int kMax, int jMax );           // constructor
    ~ytable();                 // destructor
    
    static float prob(int m, int n, int k, int j);    

public:    
    static float prob_max_descent(int m, int n, int k); // no bounds checking inside this function
    
public:    
    static void reallocate_space( int mMax, int nMax, int kMax, int jMax ); 
    static void prune_metatable( int m );

    static bool can_compute_exact_pvalue( int m, int n, int k );
    static bool can_approximate_pvalue( int m, int n, int k );

    static float compute_exact_pvalue( int m, int n, int k );
    static BOUNDS approximate_pvalue( int m, int n, int k );

    static int mSize;		// this is the max(+1) you can go in the m-dimension; i.e. 0 <= m < mSize 
    static int nSize; 
    static int kSize; 
    static int jSize; 

    static bool quiet;
    static bool override_hardlimit;

    static int nNumAllocatedInMeta; // counts the number of pointers in the metatable
                                    // that have been allocated , the max being mSize*nSize
				    // --- this is just to help us keep track how much of
				    // the table is actually being used.

    static float** metatable;  // this will be a 2-dim array of pointers to tables
                               // for each (m,n) this will hold a pointer to a table
			       // that has the {j,k} values that together determine
			       // the value of c_{m,n,j,k) which in the hand-written notes
			       // is a_{m,n,j,k}
			       //
			       // in the paper, this is y_{m,n,k,j}
};




class pvaluetable
{
public:
    pvaluetable( );	
    ~pvaluetable( );
    
    static bool can_get_pvalue(int m, int n, int k);    
    static double get_pvalue(int m, int n, int k);    
    static int size; 
    static bool quiet;
    
    static float* table;  // this will be a 3-dim array of floats
                          // that will have size entries in each dimension
};


class pvaluetable_compact
{
public:
    pvaluetable_compact( );	
    ~pvaluetable_compact( );
    
    static bool   can_get_pvalue(int m, int n, int k);    
    static double get_pvalue(int m, int n, int k);
    static bool   validate( void );

    static bool quiet;
    static int size; 
    static int table_len;	// this is the length of the array `table' below
    static float* table;  	// this will be the array that holds the p-values
    static int* index_array;	// this is the m x m array that holds indices into the "table" member
    				// for example, to compute pvalue at (m,n,k), get the integer `index'
    				// located at index_array[m*size+n]; if either m=0 or n=0; a -1 will be
    				// stored there; otherwise the p-values for (m,n,k) with k ranging from
    				// n-m+1 to n (inclusive) or 1 to n (inclusive) will be stored starting 
    				// at table[index]; there will be either m p-values or n p-values stored
    				// stored there, depending on which is larger, m or n
};



class approx
{
   
public:
    approx( );                 				// constructor
    ~approx( );
    // returns p-value that md H_{m,n} >= k
    static double hogansiegmund86_thrm2(int m, int n, int k);
    static double siegmund_continuous(int m, int n, int k);
    static double siegmund_discrete(int m, int n, int k);

private:
    static double normpdf(double x);
    static double normcdf(double x);
    static double nu(double x);
};


#endif // PROBTABLES
