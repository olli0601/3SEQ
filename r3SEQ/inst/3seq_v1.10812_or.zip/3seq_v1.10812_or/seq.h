#ifndef SEQ
#define SEQ


#include <string>
#include "ProbTables.h"		// 12/07/2008: this was addes so that the bounds struct could be used below

using namespace std;

class seq
{   
public:    
    seq();          // constructor
    ~seq();         // destructor
    
    string ntfull;  // full nucleotide sequence
    string nt;      // nucelotide sequence (usually just polymorphic sites)    
    string aa;      // amino acid sequence    
    string accnum;  // accession number    
    string name;    // strain name
    
    int year;       // year    
    int ha;         // haemagglutinin type, must be between 1 and 16
    int na;         // neuraminidase type, must be between 1 and 9
    
    bool recombinant;    		// is set to false initially; can be switched to true by 3SEQ 
    bool recombinant_and_is_long;    	// is set to false initially; can be switched to true by 3SEQ 
    bool marked_for_deletion;		// is set to false initially; can be switched to true by 3SEQ 
    bool had_neighbor_deleted;  	// is set to false initially; can be switched to true by 3SEQ 
    
    int* poly_to_full;	// an array of length seq.nt.length() whose entris are the indices
    			// in seq.ntfull.  This is a map from the position of a polymorphic site
			// in seq.nt to the position of a regular site in nt.full
			
    // the class members below are the indices, max descent, pvalue, etc. for the best recombinant
    // triplet where this sequence is the child sequence;  the "best" means the lowest p-value
    // the member "best_hs" tells you whether this triplet's p-value was computed with a 
    // Hogan-Siegmund approximation
    int best_parent1_index;	
    int best_parent2_index;
    int best_m;
    int best_n;
    int best_md;
    float best_pvalue;
    bool best_hs;
    BOUNDS best_bounds;
    
    int match_distance_to_target;

    // MEMBER FUNCTIONS
    void makeAAfromNT( void );

    // have this member function make sure that all the nt are nt, all the aa are aa, etc.
    // bool assert();
};

#endif // SEQ
